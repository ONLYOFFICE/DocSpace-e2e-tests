/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: nextcloud
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `oc_accounts`
--

DROP TABLE IF EXISTS `oc_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_accounts` (
  `uid` varchar(64) NOT NULL DEFAULT '',
  `data` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts`
--

LOCK TABLES `oc_accounts` WRITE;
/*!40000 ALTER TABLE `oc_accounts` DISABLE KEYS */;
INSERT INTO `oc_accounts` VALUES
('emily','{\"displayname\":{\"value\":\"Emily Carter\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"address\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"website\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"email\":{\"value\":\"emily.carter@example.com\",\"scope\":\"v2-federated\",\"verified\":\"1\"},\"avatar\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"phone\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"twitter\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"fediverse\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"organisation\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"role\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"headline\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"biography\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"birthdate\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"profile_enabled\":{\"value\":\"1\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"pronouns\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"}}'),
('james','{\"displayname\":{\"value\":\"James Walker\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"address\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"website\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"email\":{\"value\":\"james.walker@example.com\",\"scope\":\"v2-federated\",\"verified\":\"1\"},\"avatar\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"phone\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"twitter\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"fediverse\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"organisation\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"role\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"headline\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"biography\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"birthdate\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"profile_enabled\":{\"value\":\"1\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"pronouns\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"}}'),
('ncadmin','{\"displayname\":{\"value\":\"ncadmin\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"address\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"website\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"email\":{\"value\":null,\"scope\":\"v2-federated\",\"verified\":\"0\"},\"avatar\":{\"scope\":\"v2-federated\"},\"phone\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"twitter\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"fediverse\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"organisation\":{\"value\":\"\",\"scope\":\"v2-local\"},\"role\":{\"value\":\"\",\"scope\":\"v2-local\"},\"headline\":{\"value\":\"\",\"scope\":\"v2-local\"},\"biography\":{\"value\":\"\",\"scope\":\"v2-local\"},\"birthdate\":{\"value\":\"\",\"scope\":\"v2-local\"},\"profile_enabled\":{\"value\":\"1\"},\"pronouns\":{\"value\":\"\",\"scope\":\"v2-federated\"}}'),
('olivia','{\"displayname\":{\"value\":\"Olivia Bennett\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"address\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"website\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"email\":{\"value\":\"olivia.bennett@example.com\",\"scope\":\"v2-federated\",\"verified\":\"1\"},\"avatar\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"},\"phone\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"twitter\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"fediverse\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"organisation\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"role\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"headline\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"biography\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"birthdate\":{\"value\":\"\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"profile_enabled\":{\"value\":\"1\",\"scope\":\"v2-local\",\"verified\":\"0\"},\"pronouns\":{\"value\":\"\",\"scope\":\"v2-federated\",\"verified\":\"0\"}}');
/*!40000 ALTER TABLE `oc_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_accounts_data`
--

DROP TABLE IF EXISTS `oc_accounts_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_accounts_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `value` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `accounts_data_uid` (`uid`),
  KEY `accounts_data_name` (`name`),
  KEY `accounts_data_value` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_accounts_data`
--

LOCK TABLES `oc_accounts_data` WRITE;
/*!40000 ALTER TABLE `oc_accounts_data` DISABLE KEYS */;
INSERT INTO `oc_accounts_data` VALUES
(1,'ncadmin','displayname','ncadmin'),
(2,'ncadmin','address',''),
(3,'ncadmin','website',''),
(4,'ncadmin','email',''),
(5,'ncadmin','phone',''),
(6,'ncadmin','twitter',''),
(7,'ncadmin','fediverse',''),
(8,'ncadmin','organisation',''),
(9,'ncadmin','role',''),
(10,'ncadmin','headline',''),
(11,'ncadmin','biography',''),
(12,'ncadmin','birthdate',''),
(13,'ncadmin','profile_enabled','1'),
(14,'ncadmin','pronouns',''),
(43,'emily','displayname','Emily Carter'),
(44,'emily','address',''),
(45,'emily','website',''),
(46,'emily','email','emily.carter@example.com'),
(47,'emily','phone',''),
(48,'emily','twitter',''),
(49,'emily','fediverse',''),
(50,'emily','organisation',''),
(51,'emily','role',''),
(52,'emily','headline',''),
(53,'emily','biography',''),
(54,'emily','birthdate',''),
(55,'emily','profile_enabled','1'),
(56,'emily','pronouns',''),
(85,'james','displayname','James Walker'),
(86,'james','address',''),
(87,'james','website',''),
(88,'james','email','james.walker@example.com'),
(89,'james','phone',''),
(90,'james','twitter',''),
(91,'james','fediverse',''),
(92,'james','organisation',''),
(93,'james','role',''),
(94,'james','headline',''),
(95,'james','biography',''),
(96,'james','birthdate',''),
(97,'james','profile_enabled','1'),
(98,'james','pronouns',''),
(127,'olivia','displayname','Olivia Bennett'),
(128,'olivia','address',''),
(129,'olivia','website',''),
(130,'olivia','email','olivia.bennett@example.com'),
(131,'olivia','phone',''),
(132,'olivia','twitter',''),
(133,'olivia','fediverse',''),
(134,'olivia','organisation',''),
(135,'olivia','role',''),
(136,'olivia','headline',''),
(137,'olivia','biography',''),
(138,'olivia','birthdate',''),
(139,'olivia','profile_enabled','1'),
(140,'olivia','pronouns','');
/*!40000 ALTER TABLE `oc_accounts_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity`
--

DROP TABLE IF EXISTS `oc_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_activity` (
  `activity_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) NOT NULL DEFAULT 0,
  `type` varchar(255) DEFAULT NULL,
  `user` varchar(64) DEFAULT NULL,
  `affecteduser` varchar(64) NOT NULL,
  `app` varchar(32) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subjectparams` longtext NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `messageparams` longtext DEFAULT NULL,
  `file` varchar(4000) DEFAULT NULL,
  `link` varchar(4000) DEFAULT NULL,
  `object_type` varchar(255) DEFAULT NULL,
  `object_id` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`activity_id`),
  KEY `activity_user_time` (`affecteduser`,`timestamp`),
  KEY `activity_filter_by` (`affecteduser`,`user`,`timestamp`),
  KEY `activity_filter` (`affecteduser`,`type`,`app`,`timestamp`),
  KEY `activity_object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity`
--

LOCK TABLES `oc_activity` WRITE;
/*!40000 ALTER TABLE `oc_activity` DISABLE KEYS */;
INSERT INTO `oc_activity` VALUES
(1,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"3\":\"\\/Templates credits.md\"}]','','[]','/Templates credits.md','http://localhost/index.php/apps/files/?dir=/','files',3),
(2,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"3\":\"\\/Templates credits.md\"}]','','[]','/Templates credits.md','http://localhost/index.php/apps/files/?dir=/','files',3),
(3,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"4\":\"\\/Documents\"}]','','[]','/Documents','http://localhost/index.php/apps/files/?dir=/','files',4),
(4,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"5\":\"\\/Documents\\/Example.md\"}]','','[]','/Documents/Example.md','http://localhost/index.php/apps/files/?dir=/Documents','files',5),
(5,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"5\":\"\\/Documents\\/Example.md\"}]','','[]','/Documents/Example.md','http://localhost/index.php/apps/files/?dir=/Documents','files',5),
(6,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"6\":\"\\/Documents\\/Nextcloud flyer.pdf\"}]','','[]','/Documents/Nextcloud flyer.pdf','http://localhost/index.php/apps/files/?dir=/Documents','files',6),
(7,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"6\":\"\\/Documents\\/Nextcloud flyer.pdf\"}]','','[]','/Documents/Nextcloud flyer.pdf','http://localhost/index.php/apps/files/?dir=/Documents','files',6),
(8,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"7\":\"\\/Documents\\/Welcome to Nextcloud Hub.docx\"}]','','[]','/Documents/Welcome to Nextcloud Hub.docx','http://localhost/index.php/apps/files/?dir=/Documents','files',7),
(9,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"7\":\"\\/Documents\\/Welcome to Nextcloud Hub.docx\"}]','','[]','/Documents/Welcome to Nextcloud Hub.docx','http://localhost/index.php/apps/files/?dir=/Documents','files',7),
(10,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"8\":\"\\/Documents\\/Readme.md\"}]','','[]','/Documents/Readme.md','http://localhost/index.php/apps/files/?dir=/Documents','files',8),
(11,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"8\":\"\\/Documents\\/Readme.md\"}]','','[]','/Documents/Readme.md','http://localhost/index.php/apps/files/?dir=/Documents','files',8),
(12,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"9\":\"\\/Nextcloud intro.mp4\"}]','','[]','/Nextcloud intro.mp4','http://localhost/index.php/apps/files/?dir=/','files',9),
(13,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"9\":\"\\/Nextcloud intro.mp4\"}]','','[]','/Nextcloud intro.mp4','http://localhost/index.php/apps/files/?dir=/','files',9),
(14,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"10\":\"\\/Templates\"}]','','[]','/Templates','http://localhost/index.php/apps/files/?dir=/','files',10),
(15,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"11\":\"\\/Templates\\/Brainstorming.whiteboard\"}]','','[]','/Templates/Brainstorming.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',11),
(16,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"11\":\"\\/Templates\\/Brainstorming.whiteboard\"}]','','[]','/Templates/Brainstorming.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',11),
(17,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"12\":\"\\/Templates\\/Mind map.whiteboard\"}]','','[]','/Templates/Mind map.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',12),
(18,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"12\":\"\\/Templates\\/Mind map.whiteboard\"}]','','[]','/Templates/Mind map.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',12),
(19,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"13\":\"\\/Templates\\/Flowchart.whiteboard\"}]','','[]','/Templates/Flowchart.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',13),
(20,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"13\":\"\\/Templates\\/Flowchart.whiteboard\"}]','','[]','/Templates/Flowchart.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',13),
(21,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"14\":\"\\/Templates\\/Modern company.odp\"}]','','[]','/Templates/Modern company.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',14),
(22,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"14\":\"\\/Templates\\/Modern company.odp\"}]','','[]','/Templates/Modern company.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',14),
(23,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"15\":\"\\/Templates\\/Timesheet.ods\"}]','','[]','/Templates/Timesheet.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',15),
(24,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"15\":\"\\/Templates\\/Timesheet.ods\"}]','','[]','/Templates/Timesheet.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',15),
(25,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"16\":\"\\/Templates\\/Mother\'s day.odt\"}]','','[]','/Templates/Mother\'s day.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',16),
(26,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"16\":\"\\/Templates\\/Mother\'s day.odt\"}]','','[]','/Templates/Mother\'s day.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',16),
(27,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"17\":\"\\/Templates\\/Business model canvas.whiteboard\"}]','','[]','/Templates/Business model canvas.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',17),
(28,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"17\":\"\\/Templates\\/Business model canvas.whiteboard\"}]','','[]','/Templates/Business model canvas.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',17),
(29,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"18\":\"\\/Templates\\/Letter.odt\"}]','','[]','/Templates/Letter.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',18),
(30,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"18\":\"\\/Templates\\/Letter.odt\"}]','','[]','/Templates/Letter.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',18),
(31,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"19\":\"\\/Templates\\/Business model canvas.ods\"}]','','[]','/Templates/Business model canvas.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',19),
(32,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"19\":\"\\/Templates\\/Business model canvas.ods\"}]','','[]','/Templates/Business model canvas.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',19),
(33,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"20\":\"\\/Templates\\/Gotong royong.odp\"}]','','[]','/Templates/Gotong royong.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',20),
(34,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"20\":\"\\/Templates\\/Gotong royong.odp\"}]','','[]','/Templates/Gotong royong.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',20),
(35,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"21\":\"\\/Templates\\/Business model canvas.odg\"}]','','[]','/Templates/Business model canvas.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',21),
(36,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"21\":\"\\/Templates\\/Business model canvas.odg\"}]','','[]','/Templates/Business model canvas.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',21),
(37,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"22\":\"\\/Templates\\/Photo book.odt\"}]','','[]','/Templates/Photo book.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',22),
(38,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"22\":\"\\/Templates\\/Photo book.odt\"}]','','[]','/Templates/Photo book.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',22),
(39,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"23\":\"\\/Templates\\/Meeting agenda.whiteboard\"}]','','[]','/Templates/Meeting agenda.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',23),
(40,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"23\":\"\\/Templates\\/Meeting agenda.whiteboard\"}]','','[]','/Templates/Meeting agenda.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',23),
(41,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"24\":\"\\/Templates\\/Org chart.odg\"}]','','[]','/Templates/Org chart.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',24),
(42,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"24\":\"\\/Templates\\/Org chart.odg\"}]','','[]','/Templates/Org chart.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',24),
(43,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"25\":\"\\/Templates\\/Resume.odt\"}]','','[]','/Templates/Resume.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',25),
(44,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"25\":\"\\/Templates\\/Resume.odt\"}]','','[]','/Templates/Resume.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',25),
(45,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"26\":\"\\/Templates\\/Mindmap.odg\"}]','','[]','/Templates/Mindmap.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',26),
(46,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"26\":\"\\/Templates\\/Mindmap.odg\"}]','','[]','/Templates/Mindmap.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',26),
(47,1795099322,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"27\":\"\\/Templates\\/Syllabus.odt\"}]','','[]','/Templates/Syllabus.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',27),
(48,1795099322,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"27\":\"\\/Templates\\/Syllabus.odt\"}]','','[]','/Templates/Syllabus.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',27),
(49,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"28\":\"\\/Templates\\/Flowchart.odg\"}]','','[]','/Templates/Flowchart.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',28),
(50,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"28\":\"\\/Templates\\/Flowchart.odg\"}]','','[]','/Templates/Flowchart.odg','http://localhost/index.php/apps/files/?dir=/Templates','files',28),
(51,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"29\":\"\\/Templates\\/Impact effort.whiteboard\"}]','','[]','/Templates/Impact effort.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',29),
(52,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"29\":\"\\/Templates\\/Impact effort.whiteboard\"}]','','[]','/Templates/Impact effort.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',29),
(53,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"30\":\"\\/Templates\\/Product plan.md\"}]','','[]','/Templates/Product plan.md','http://localhost/index.php/apps/files/?dir=/Templates','files',30),
(54,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"30\":\"\\/Templates\\/Product plan.md\"}]','','[]','/Templates/Product plan.md','http://localhost/index.php/apps/files/?dir=/Templates','files',30),
(55,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"31\":\"\\/Templates\\/Timeline.whiteboard\"}]','','[]','/Templates/Timeline.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',31),
(56,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"31\":\"\\/Templates\\/Timeline.whiteboard\"}]','','[]','/Templates/Timeline.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',31),
(57,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"32\":\"\\/Templates\\/Party invitation.odt\"}]','','[]','/Templates/Party invitation.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',32),
(58,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"32\":\"\\/Templates\\/Party invitation.odt\"}]','','[]','/Templates/Party invitation.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',32),
(59,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"33\":\"\\/Templates\\/Yellow idea.odp\"}]','','[]','/Templates/Yellow idea.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',33),
(60,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"33\":\"\\/Templates\\/Yellow idea.odp\"}]','','[]','/Templates/Yellow idea.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',33),
(61,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"34\":\"\\/Templates\\/Diagram & table.ods\"}]','','[]','/Templates/Diagram & table.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',34),
(62,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"34\":\"\\/Templates\\/Diagram & table.ods\"}]','','[]','/Templates/Diagram & table.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',34),
(63,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"35\":\"\\/Templates\\/Venn diagram.whiteboard\"}]','','[]','/Templates/Venn diagram.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',35),
(64,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"35\":\"\\/Templates\\/Venn diagram.whiteboard\"}]','','[]','/Templates/Venn diagram.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',35),
(65,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"36\":\"\\/Templates\\/Elegant.odp\"}]','','[]','/Templates/Elegant.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',36),
(66,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"36\":\"\\/Templates\\/Elegant.odp\"}]','','[]','/Templates/Elegant.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',36),
(67,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"37\":\"\\/Templates\\/Simple.odp\"}]','','[]','/Templates/Simple.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',37),
(68,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"37\":\"\\/Templates\\/Simple.odp\"}]','','[]','/Templates/Simple.odp','http://localhost/index.php/apps/files/?dir=/Templates','files',37),
(69,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"38\":\"\\/Templates\\/Sticky notes.whiteboard\"}]','','[]','/Templates/Sticky notes.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',38),
(70,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"38\":\"\\/Templates\\/Sticky notes.whiteboard\"}]','','[]','/Templates/Sticky notes.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',38),
(71,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"39\":\"\\/Templates\\/Kanban board.whiteboard\"}]','','[]','/Templates/Kanban board.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',39),
(72,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"39\":\"\\/Templates\\/Kanban board.whiteboard\"}]','','[]','/Templates/Kanban board.whiteboard','http://localhost/index.php/apps/files/?dir=/Templates','files',39),
(73,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"40\":\"\\/Templates\\/Expense report.ods\"}]','','[]','/Templates/Expense report.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',40),
(74,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"40\":\"\\/Templates\\/Expense report.ods\"}]','','[]','/Templates/Expense report.ods','http://localhost/index.php/apps/files/?dir=/Templates','files',40),
(75,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"41\":\"\\/Templates\\/Readme.md\"}]','','[]','/Templates/Readme.md','http://localhost/index.php/apps/files/?dir=/Templates','files',41),
(76,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"41\":\"\\/Templates\\/Readme.md\"}]','','[]','/Templates/Readme.md','http://localhost/index.php/apps/files/?dir=/Templates','files',41),
(77,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"42\":\"\\/Templates\\/Meeting notes.md\"}]','','[]','/Templates/Meeting notes.md','http://localhost/index.php/apps/files/?dir=/Templates','files',42),
(78,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"42\":\"\\/Templates\\/Meeting notes.md\"}]','','[]','/Templates/Meeting notes.md','http://localhost/index.php/apps/files/?dir=/Templates','files',42),
(79,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"43\":\"\\/Templates\\/Invoice.odt\"}]','','[]','/Templates/Invoice.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',43),
(80,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"43\":\"\\/Templates\\/Invoice.odt\"}]','','[]','/Templates/Invoice.odt','http://localhost/index.php/apps/files/?dir=/Templates','files',43),
(81,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"44\":\"\\/Nextcloud Manual.pdf\"}]','','[]','/Nextcloud Manual.pdf','http://localhost/index.php/apps/files/?dir=/','files',44),
(82,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"44\":\"\\/Nextcloud Manual.pdf\"}]','','[]','/Nextcloud Manual.pdf','http://localhost/index.php/apps/files/?dir=/','files',44),
(83,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"45\":\"\\/Reasons to use Nextcloud.pdf\"}]','','[]','/Reasons to use Nextcloud.pdf','http://localhost/index.php/apps/files/?dir=/','files',45),
(84,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"45\":\"\\/Reasons to use Nextcloud.pdf\"}]','','[]','/Reasons to use Nextcloud.pdf','http://localhost/index.php/apps/files/?dir=/','files',45),
(85,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"46\":\"\\/Photos\"}]','','[]','/Photos','http://localhost/index.php/apps/files/?dir=/','files',46),
(86,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"47\":\"\\/Photos\\/Birdie.jpg\"}]','','[]','/Photos/Birdie.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',47),
(87,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"47\":\"\\/Photos\\/Birdie.jpg\"}]','','[]','/Photos/Birdie.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',47),
(88,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"48\":\"\\/Photos\\/Nextcloud community.jpg\"}]','','[]','/Photos/Nextcloud community.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',48),
(89,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"48\":\"\\/Photos\\/Nextcloud community.jpg\"}]','','[]','/Photos/Nextcloud community.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',48),
(90,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"49\":\"\\/Photos\\/Vineyard.jpg\"}]','','[]','/Photos/Vineyard.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',49),
(91,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"49\":\"\\/Photos\\/Vineyard.jpg\"}]','','[]','/Photos/Vineyard.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',49),
(92,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"50\":\"\\/Photos\\/Steps.jpg\"}]','','[]','/Photos/Steps.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',50),
(93,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"50\":\"\\/Photos\\/Steps.jpg\"}]','','[]','/Photos/Steps.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',50),
(94,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"51\":\"\\/Photos\\/Library.jpg\"}]','','[]','/Photos/Library.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',51),
(95,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"51\":\"\\/Photos\\/Library.jpg\"}]','','[]','/Photos/Library.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',51),
(96,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"52\":\"\\/Photos\\/Frog.jpg\"}]','','[]','/Photos/Frog.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',52),
(97,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"52\":\"\\/Photos\\/Frog.jpg\"}]','','[]','/Photos/Frog.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',52),
(98,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"53\":\"\\/Photos\\/Toucan.jpg\"}]','','[]','/Photos/Toucan.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',53),
(99,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"53\":\"\\/Photos\\/Toucan.jpg\"}]','','[]','/Photos/Toucan.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',53),
(100,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"54\":\"\\/Photos\\/Gorilla.jpg\"}]','','[]','/Photos/Gorilla.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',54),
(101,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"54\":\"\\/Photos\\/Gorilla.jpg\"}]','','[]','/Photos/Gorilla.jpg','http://localhost/index.php/apps/files/?dir=/Photos','files',54),
(102,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"55\":\"\\/Photos\\/Readme.md\"}]','','[]','/Photos/Readme.md','http://localhost/index.php/apps/files/?dir=/Photos','files',55),
(103,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"55\":\"\\/Photos\\/Readme.md\"}]','','[]','/Photos/Readme.md','http://localhost/index.php/apps/files/?dir=/Photos','files',55),
(104,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"56\":\"\\/Readme.md\"}]','','[]','/Readme.md','http://localhost/index.php/apps/files/?dir=/','files',56),
(105,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"56\":\"\\/Readme.md\"}]','','[]','/Readme.md','http://localhost/index.php/apps/files/?dir=/','files',56),
(106,1795099323,30,'file_created','ncadmin','ncadmin','files','created_self','[{\"57\":\"\\/Nextcloud.png\"}]','','[]','/Nextcloud.png','http://localhost/index.php/apps/files/?dir=/','files',57),
(107,1795099323,30,'file_changed','ncadmin','ncadmin','files','changed_self','[{\"57\":\"\\/Nextcloud.png\"}]','','[]','/Nextcloud.png','http://localhost/index.php/apps/files/?dir=/','files',57),
(108,1795099323,30,'calendar','ncadmin','ncadmin','dav','calendar_add_self','{\"actor\":\"ncadmin\",\"calendar\":{\"id\":1,\"uri\":\"personal\",\"name\":\"Personal\"}}','','[]','','','calendar',1),
(109,1795099323,30,'contacts','ncadmin','ncadmin','dav','addressbook_add_self','{\"actor\":\"ncadmin\",\"addressbook\":{\"id\":2,\"uri\":\"contacts\",\"name\":\"Contacts\"}}','','[]','','','addressbook',2),
(110,1795099338,30,'calendar','system','system','dav','calendar_add_self','{\"actor\":\"system\",\"calendar\":{\"id\":2,\"uri\":\"contact_birthdays\",\"name\":\"Contact birthdays\"}}','','[]','','','calendar',2),
(111,1795099338,30,'circles_as_member','','emily','circles','member_added','{\"ver\":2,\"circle\":{\"singleId\":\"CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb\",\"name\":\"group:Marketing Team\",\"config\":1540,\"url\":\"\"},\"initiator\":{\"userId\":\"circles\",\"displayName\":\"Circles\",\"type\":10000,\"level\":9,\"status\":\"Member\"},\"member\":{\"userId\":\"emily\",\"displayName\":\"Emily Carter\",\"type\":1,\"level\":1,\"status\":\"Member\"}}','','[]','','','',0),
(112,1795099338,30,'group_settings','','emily','settings','group_added','{\"user\":\"emily\",\"group\":\"Marketing Team\"}','','[]','','','',0),
(113,1795099340,30,'circles_as_member','','james','circles','member_added','{\"ver\":2,\"circle\":{\"singleId\":\"CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb\",\"name\":\"group:Marketing Team\",\"config\":1540,\"url\":\"\"},\"initiator\":{\"userId\":\"circles\",\"displayName\":\"Circles\",\"type\":10000,\"level\":9,\"status\":\"Member\"},\"member\":{\"userId\":\"james\",\"displayName\":\"James Walker\",\"type\":1,\"level\":1,\"status\":\"Member\"}}','','[]','','','',0),
(114,1795099340,30,'group_settings','','james','settings','group_added','{\"user\":\"james\",\"group\":\"Marketing Team\"}','','[]','','','',0),
(115,1795099341,30,'circles_as_member','','olivia','circles','member_added','{\"ver\":2,\"circle\":{\"singleId\":\"CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb\",\"name\":\"group:Marketing Team\",\"config\":1540,\"url\":\"\"},\"initiator\":{\"userId\":\"circles\",\"displayName\":\"Circles\",\"type\":10000,\"level\":9,\"status\":\"Member\"},\"member\":{\"userId\":\"olivia\",\"displayName\":\"Olivia Bennett\",\"type\":1,\"level\":1,\"status\":\"Member\"}}','','[]','','','',0),
(116,1795099341,30,'group_settings','','olivia','settings','group_added','{\"user\":\"olivia\",\"group\":\"Marketing Team\"}','','[]','','','',0),
(117,1795099362,30,'calendar','emily','emily','dav','calendar_add_self','{\"actor\":\"emily\",\"calendar\":{\"id\":3,\"uri\":\"personal\",\"name\":\"Personal\"}}','','[]','','','calendar',3),
(118,1795099362,30,'contacts','emily','emily','dav','addressbook_add_self','{\"actor\":\"emily\",\"addressbook\":{\"id\":3,\"uri\":\"contacts\",\"name\":\"Contacts\"}}','','[]','','','addressbook',3),
(119,1795099362,30,'shared','emily','emily','files_sharing','shared_user_self','[{\"88\":\"\\/Campaigns\\/Marketing-plan.txt\"},\"james\"]','','[]','/Campaigns/Marketing-plan.txt','http://localhost/apps/files/?dir=/Campaigns','files',88),
(120,1795099362,30,'shared','emily','james','files_sharing','shared_with_by','[{\"88\":\"\\/Marketing-plan.txt\"},\"emily\"]','','[]','/Marketing-plan.txt','http://localhost/apps/files/?dir=/','files',88);
/*!40000 ALTER TABLE `oc_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_activity_mq`
--

DROP TABLE IF EXISTS `oc_activity_mq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_activity_mq` (
  `mail_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amq_timestamp` int(11) NOT NULL DEFAULT 0,
  `amq_latest_send` int(11) NOT NULL DEFAULT 0,
  `amq_type` varchar(255) NOT NULL,
  `amq_affecteduser` varchar(64) NOT NULL,
  `amq_appid` varchar(32) NOT NULL,
  `amq_subject` varchar(255) NOT NULL,
  `amq_subjectparams` longtext DEFAULT NULL,
  `object_type` varchar(255) DEFAULT NULL,
  `object_id` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`mail_id`),
  KEY `amp_user` (`amq_affecteduser`),
  KEY `amp_latest_send_time` (`amq_latest_send`),
  KEY `amp_timestamp_time` (`amq_timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_activity_mq`
--

LOCK TABLES `oc_activity_mq` WRITE;
/*!40000 ALTER TABLE `oc_activity_mq` DISABLE KEYS */;
INSERT INTO `oc_activity_mq` VALUES
(1,1795099338,1795102938,'group_settings','emily','settings','group_added','{\"user\":\"emily\",\"group\":\"Marketing Team\"}','',0),
(2,1795099340,1795102940,'group_settings','james','settings','group_added','{\"user\":\"james\",\"group\":\"Marketing Team\"}','',0),
(3,1795099341,1795102941,'group_settings','olivia','settings','group_added','{\"user\":\"olivia\",\"group\":\"Marketing Team\"}','',0);
/*!40000 ALTER TABLE `oc_activity_mq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbookchanges`
--

DROP TABLE IF EXISTS `oc_addressbookchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_addressbookchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT 1,
  `addressbookid` bigint(20) NOT NULL,
  `operation` smallint(6) NOT NULL,
  `created_at` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `addressbookid_synctoken` (`addressbookid`,`synctoken`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbookchanges`
--

LOCK TABLES `oc_addressbookchanges` WRITE;
/*!40000 ALTER TABLE `oc_addressbookchanges` DISABLE KEYS */;
INSERT INTO `oc_addressbookchanges` VALUES
(1,'Database:emily.vcf',1,1,1,1795099338),
(2,'Database:emily.vcf',2,1,2,1795099338),
(3,'Database:emily.vcf',3,1,2,1795099338),
(4,'Database:emily.vcf',4,1,2,1795099338),
(5,'Database:james.vcf',5,1,1,1795099339),
(6,'Database:james.vcf',6,1,2,1795099339),
(7,'Database:james.vcf',7,1,2,1795099340),
(8,'Database:james.vcf',8,1,2,1795099340),
(9,'Database:olivia.vcf',9,1,1,1795099341),
(10,'Database:olivia.vcf',10,1,2,1795099341),
(11,'Database:olivia.vcf',11,1,2,1795099341),
(12,'Database:olivia.vcf',12,1,2,1795099341);
/*!40000 ALTER TABLE `oc_addressbookchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_addressbooks`
--

DROP TABLE IF EXISTS `oc_addressbooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_addressbooks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) DEFAULT NULL,
  `displayname` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `addressbook_index` (`principaluri`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_addressbooks`
--

LOCK TABLES `oc_addressbooks` WRITE;
/*!40000 ALTER TABLE `oc_addressbooks` DISABLE KEYS */;
INSERT INTO `oc_addressbooks` VALUES
(1,'principals/system/system','system','system','System addressbook which holds all users of this instance',13),
(2,'principals/users/ncadmin','Contacts','contacts',NULL,1),
(3,'principals/users/emily','Contacts','contacts',NULL,1);
/*!40000 ALTER TABLE `oc_addressbooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_appconfig`
--

DROP TABLE IF EXISTS `oc_appconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_appconfig` (
  `appid` varchar(32) NOT NULL DEFAULT '',
  `configkey` varchar(64) NOT NULL DEFAULT '',
  `configvalue` longtext DEFAULT NULL,
  `type` int(10) unsigned NOT NULL DEFAULT 2,
  `lazy` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`appid`,`configkey`),
  KEY `ac_lazy_i` (`lazy`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_appconfig`
--

LOCK TABLES `oc_appconfig` WRITE;
/*!40000 ALTER TABLE `oc_appconfig` DISABLE KEYS */;
INSERT INTO `oc_appconfig` VALUES
('activity','enabled','yes',2,0),
('activity','installed_version','4.0.0',2,0),
('activity','types','filesystem',2,0),
('app_api','enabled','yes',2,0),
('app_api','installed_version','5.0.2',2,0),
('app_api','types','',2,0),
('bruteforcesettings','enabled','yes',2,0),
('bruteforcesettings','installed_version','4.0.0',2,0),
('bruteforcesettings','types','',2,0),
('circles','enabled','yes',2,0),
('circles','installed_version','31.0.0',2,0),
('circles','loopback_tmp_scheme','http',2,0),
('circles','types','filesystem,dav',2,0),
('cloud_federation_api','enabled','yes',2,0),
('cloud_federation_api','installed_version','1.14.0',2,0),
('cloud_federation_api','types','filesystem',2,0),
('comments','enabled','yes',2,0),
('comments','installed_version','1.21.0',2,0),
('comments','types','logging',2,0),
('contactsinteraction','enabled','yes',2,0),
('contactsinteraction','installed_version','1.12.1',2,0),
('contactsinteraction','types','dav',2,0),
('core','files_metadata','{\"photos-original_date_time\":{\"value\":null,\"type\":\"int\",\"etag\":\"\",\"indexed\":true,\"editPermission\":0},\"photos-exif\":{\"value\":null,\"type\":\"array\",\"etag\":\"\",\"indexed\":false,\"editPermission\":0},\"photos-ifd0\":{\"value\":null,\"type\":\"array\",\"etag\":\"\",\"indexed\":false,\"editPermission\":0},\"photos-size\":{\"value\":null,\"type\":\"array\",\"etag\":\"\",\"indexed\":false,\"editPermission\":0}}',64,1),
('core','installedat','1795099320.7176',2,0),
('core','lastupdatedat','1795099320',8,0),
('core','public_files','files_sharing/public.php',2,0),
('core','vendor','nextcloud',2,0),
('dashboard','enabled','yes',2,0),
('dashboard','installed_version','7.11.0',2,0),
('dashboard','types','',2,0),
('dav','enabled','yes',2,0),
('dav','installed_version','1.33.0',2,0),
('dav','types','filesystem',2,0),
('federatedfilesharing','enabled','yes',2,0),
('federatedfilesharing','installed_version','1.21.0',2,0),
('federatedfilesharing','types','',2,0),
('federation','enabled','yes',2,0),
('federation','installed_version','1.21.0',2,0),
('federation','types','authentication',2,0),
('files','enabled','yes',2,0),
('files','installed_version','2.3.1',2,0),
('files','types','filesystem',2,0),
('files_downloadlimit','enabled','yes',2,0),
('files_downloadlimit','installed_version','4.0.0',2,0),
('files_downloadlimit','types','',2,0),
('files_pdfviewer','enabled','yes',2,0),
('files_pdfviewer','installed_version','4.0.0',2,0),
('files_pdfviewer','types','',2,0),
('files_reminders','enabled','yes',2,0),
('files_reminders','installed_version','1.4.0',2,0),
('files_reminders','types','',2,0),
('files_sharing','enabled','yes',2,0),
('files_sharing','installed_version','1.23.2',2,0),
('files_sharing','types','filesystem',2,0),
('files_trashbin','enabled','yes',2,0),
('files_trashbin','installed_version','1.21.0',2,0),
('files_trashbin','types','filesystem,dav',2,0),
('files_versions','enabled','yes',2,0),
('files_versions','installed_version','1.24.0',2,0),
('files_versions','types','filesystem,dav',2,0),
('firstrunwizard','enabled','yes',2,0),
('firstrunwizard','installed_version','4.0.0',2,0),
('firstrunwizard','types','',2,0),
('logreader','enabled','yes',2,0),
('logreader','installed_version','4.0.0',2,0),
('logreader','types','logging',2,0),
('lookup_server_connector','enabled','yes',2,0),
('lookup_server_connector','installed_version','1.19.0',2,0),
('lookup_server_connector','types','authentication',2,0),
('nextcloud_announcements','enabled','yes',2,0),
('nextcloud_announcements','installed_version','3.0.0',2,0),
('nextcloud_announcements','types','logging',2,0),
('notifications','enabled','yes',2,0),
('notifications','installed_version','4.0.0',2,0),
('notifications','types','logging',2,0),
('oauth2','enabled','yes',2,0),
('oauth2','installed_version','1.19.1',2,0),
('oauth2','types','authentication',2,0),
('password_policy','enabled','yes',2,0),
('password_policy','installed_version','3.0.0',2,0),
('password_policy','types','authentication',2,0),
('photos','enabled','yes',2,0),
('photos','installed_version','4.0.0',2,0),
('photos','types','dav,authentication',2,0),
('privacy','enabled','yes',2,0),
('privacy','installed_version','3.0.0',2,0),
('privacy','types','',2,0),
('profile','enabled','yes',2,0),
('profile','installed_version','1.0.0',2,0),
('profile','types','',2,0),
('provisioning_api','enabled','yes',2,0),
('provisioning_api','installed_version','1.21.0',2,0),
('provisioning_api','types','prevent_group_restriction',2,0),
('recommendations','enabled','yes',2,0),
('recommendations','installed_version','4.0.0',2,0),
('recommendations','types','',2,0),
('related_resources','enabled','yes',2,0),
('related_resources','installed_version','2.0.0',2,0),
('related_resources','types','',2,0),
('serverinfo','enabled','yes',2,0),
('serverinfo','installed_version','3.0.0',2,0),
('serverinfo','types','',2,0),
('settings','enabled','yes',2,0),
('settings','installed_version','1.14.0',2,0),
('settings','types','',2,0),
('sharebymail','enabled','yes',2,0),
('sharebymail','installed_version','1.21.0',2,0),
('sharebymail','types','filesystem',2,0),
('support','enabled','yes',2,0),
('support','installed_version','3.0.0',2,0),
('support','types','session',2,0),
('survey_client','enabled','yes',2,0),
('survey_client','installed_version','3.0.0',2,0),
('survey_client','types','',2,0),
('systemtags','enabled','yes',2,0),
('systemtags','installed_version','1.21.1',2,0),
('systemtags','types','logging',2,0),
('text','enabled','yes',2,0),
('text','installed_version','5.0.2',2,0),
('text','types','dav',2,0),
('theming','enabled','yes',2,0),
('theming','installed_version','2.6.1',2,0),
('theming','types','logging',2,0),
('twofactor_backupcodes','enabled','yes',2,0),
('twofactor_backupcodes','installed_version','1.20.0',2,0),
('twofactor_backupcodes','types','',2,0),
('updatenotification','enabled','yes',2,0),
('updatenotification','installed_version','1.21.0',2,0),
('updatenotification','types','',2,0),
('user_status','enabled','yes',2,0),
('user_status','installed_version','1.11.0',2,0),
('user_status','types','',2,0),
('viewer','enabled','yes',2,0),
('viewer','installed_version','4.0.0',2,0),
('viewer','types','',2,0),
('weather_status','enabled','yes',2,0),
('weather_status','installed_version','1.11.0',2,0),
('weather_status','types','',2,0),
('webhook_listeners','enabled','yes',2,0),
('webhook_listeners','installed_version','1.2.0',2,0),
('webhook_listeners','types','filesystem',2,0),
('workflowengine','enabled','yes',2,0),
('workflowengine','installed_version','2.13.0',2,0),
('workflowengine','types','filesystem',2,0);
/*!40000 ALTER TABLE `oc_appconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_appconfig_ex`
--

DROP TABLE IF EXISTS `oc_appconfig_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_appconfig_ex` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `configkey` varchar(64) NOT NULL,
  `configvalue` longtext DEFAULT NULL,
  `sensitive` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appconfig_ex__idx` (`appid`,`configkey`),
  KEY `appconfig_ex__configkey` (`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_appconfig_ex`
--

LOCK TABLES `oc_appconfig_ex` WRITE;
/*!40000 ALTER TABLE `oc_appconfig_ex` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_appconfig_ex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authorized_groups`
--

DROP TABLE IF EXISTS `oc_authorized_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_authorized_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(200) NOT NULL,
  `class` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admindel_groupid_idx` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authorized_groups`
--

LOCK TABLES `oc_authorized_groups` WRITE;
/*!40000 ALTER TABLE `oc_authorized_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_authorized_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_authtoken`
--

DROP TABLE IF EXISTS `oc_authtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_authtoken` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL DEFAULT '',
  `login_name` varchar(255) NOT NULL DEFAULT '',
  `password` longtext DEFAULT NULL,
  `name` longtext NOT NULL DEFAULT '',
  `token` varchar(200) NOT NULL DEFAULT '',
  `type` smallint(5) unsigned DEFAULT 0,
  `remember` smallint(5) unsigned DEFAULT 0,
  `last_activity` int(10) unsigned DEFAULT 0,
  `last_check` int(10) unsigned DEFAULT 0,
  `scope` longtext DEFAULT NULL,
  `expires` int(10) unsigned DEFAULT NULL,
  `private_key` longtext DEFAULT NULL,
  `public_key` longtext DEFAULT NULL,
  `version` smallint(5) unsigned NOT NULL DEFAULT 1,
  `password_invalid` tinyint(1) DEFAULT 0,
  `password_hash` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authtoken_token_index` (`token`),
  KEY `authtoken_last_activity_idx` (`last_activity`),
  KEY `authtoken_uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_authtoken`
--

LOCK TABLES `oc_authtoken` WRITE;
/*!40000 ALTER TABLE `oc_authtoken` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_authtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_bruteforce_attempts`
--

DROP TABLE IF EXISTS `oc_bruteforce_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_bruteforce_attempts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(64) NOT NULL DEFAULT '',
  `occurred` int(10) unsigned NOT NULL DEFAULT 0,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `subnet` varchar(255) NOT NULL DEFAULT '',
  `metadata` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `bruteforce_attempts_ip` (`ip`),
  KEY `bruteforce_attempts_subnet` (`subnet`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_bruteforce_attempts`
--

LOCK TABLES `oc_bruteforce_attempts` WRITE;
/*!40000 ALTER TABLE `oc_bruteforce_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_bruteforce_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_invitations`
--

DROP TABLE IF EXISTS `oc_calendar_invitations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(255) NOT NULL,
  `recurrenceid` varchar(255) DEFAULT NULL,
  `attendee` varchar(255) NOT NULL,
  `organizer` varchar(255) NOT NULL,
  `sequence` bigint(20) unsigned DEFAULT NULL,
  `token` varchar(60) NOT NULL,
  `expiration` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_invitation_tokens` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_invitations`
--

LOCK TABLES `oc_calendar_invitations` WRITE;
/*!40000 ALTER TABLE `oc_calendar_invitations` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_invitations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_reminders`
--

DROP TABLE IF EXISTS `oc_calendar_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calendar_id` bigint(20) NOT NULL,
  `object_id` bigint(20) NOT NULL,
  `is_recurring` smallint(6) DEFAULT NULL,
  `uid` varchar(255) NOT NULL,
  `recurrence_id` bigint(20) unsigned DEFAULT NULL,
  `is_recurrence_exception` smallint(6) NOT NULL,
  `event_hash` varchar(255) NOT NULL,
  `alarm_hash` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `is_relative` smallint(6) NOT NULL,
  `notification_date` bigint(20) unsigned NOT NULL,
  `is_repeat_based` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_reminder_objid` (`object_id`),
  KEY `calendar_reminder_uidrec` (`uid`,`recurrence_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_reminders`
--

LOCK TABLES `oc_calendar_reminders` WRITE;
/*!40000 ALTER TABLE `oc_calendar_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_resources`
--

DROP TABLE IF EXISTS `oc_calendar_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_resources` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `backend_id` varchar(64) DEFAULT NULL,
  `resource_id` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `displayname` varchar(255) DEFAULT NULL,
  `group_restrictions` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_resources_bkdrsc` (`backend_id`,`resource_id`),
  KEY `calendar_resources_email` (`email`),
  KEY `calendar_resources_name` (`displayname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_resources`
--

LOCK TABLES `oc_calendar_resources` WRITE;
/*!40000 ALTER TABLE `oc_calendar_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_resources_md`
--

DROP TABLE IF EXISTS `oc_calendar_resources_md`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_resources_md` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `resource_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_resources_md_idk` (`resource_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_resources_md`
--

LOCK TABLES `oc_calendar_resources_md` WRITE;
/*!40000 ALTER TABLE `oc_calendar_resources_md` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_resources_md` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_rooms`
--

DROP TABLE IF EXISTS `oc_calendar_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_rooms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `backend_id` varchar(64) DEFAULT NULL,
  `resource_id` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `displayname` varchar(255) DEFAULT NULL,
  `group_restrictions` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_rooms_bkdrsc` (`backend_id`,`resource_id`),
  KEY `calendar_rooms_email` (`email`),
  KEY `calendar_rooms_name` (`displayname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_rooms`
--

LOCK TABLES `oc_calendar_rooms` WRITE;
/*!40000 ALTER TABLE `oc_calendar_rooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendar_rooms_md`
--

DROP TABLE IF EXISTS `oc_calendar_rooms_md`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendar_rooms_md` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `room_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_rooms_md_idk` (`room_id`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendar_rooms_md`
--

LOCK TABLES `oc_calendar_rooms_md` WRITE;
/*!40000 ALTER TABLE `oc_calendar_rooms_md` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendar_rooms_md` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarchanges`
--

DROP TABLE IF EXISTS `oc_calendarchanges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarchanges` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT 1,
  `calendarid` bigint(20) NOT NULL,
  `operation` smallint(6) NOT NULL,
  `calendartype` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `calid_type_synctoken` (`calendarid`,`calendartype`,`synctoken`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarchanges`
--

LOCK TABLES `oc_calendarchanges` WRITE;
/*!40000 ALTER TABLE `oc_calendarchanges` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarchanges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects`
--

DROP TABLE IF EXISTS `oc_calendarobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calendardata` longblob DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `calendarid` bigint(20) unsigned NOT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `componenttype` varchar(8) DEFAULT NULL,
  `firstoccurence` bigint(20) unsigned DEFAULT NULL,
  `lastoccurence` bigint(20) unsigned DEFAULT NULL,
  `uid` varchar(255) DEFAULT NULL,
  `classification` int(11) DEFAULT 0,
  `calendartype` int(11) NOT NULL DEFAULT 0,
  `deleted_at` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calobjects_index` (`calendarid`,`calendartype`,`uri`),
  KEY `calobj_clssfction_index` (`classification`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects`
--

LOCK TABLES `oc_calendarobjects` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarobjects_props`
--

DROP TABLE IF EXISTS `oc_calendarobjects_props`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarobjects_props` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calendarid` bigint(20) NOT NULL DEFAULT 0,
  `objectid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) DEFAULT NULL,
  `parameter` varchar(64) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `calendartype` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `calendarobject_index` (`objectid`,`calendartype`),
  KEY `calendarobject_name_index` (`name`,`calendartype`),
  KEY `calendarobject_value_index` (`value`,`calendartype`),
  KEY `calendarobject_calid_index` (`calendarid`,`calendartype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarobjects_props`
--

LOCK TABLES `oc_calendarobjects_props` WRITE;
/*!40000 ALTER TABLE `oc_calendarobjects_props` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarobjects_props` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendars`
--

DROP TABLE IF EXISTS `oc_calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) DEFAULT NULL,
  `displayname` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT 1,
  `description` varchar(255) DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT 0,
  `calendarcolor` varchar(255) DEFAULT NULL,
  `timezone` longtext DEFAULT NULL,
  `components` varchar(64) DEFAULT NULL,
  `transparent` smallint(6) NOT NULL DEFAULT 0,
  `deleted_at` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calendars_index` (`principaluri`,`uri`),
  KEY `cals_princ_del_idx` (`principaluri`,`deleted_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendars`
--

LOCK TABLES `oc_calendars` WRITE;
/*!40000 ALTER TABLE `oc_calendars` DISABLE KEYS */;
INSERT INTO `oc_calendars` VALUES
(1,'principals/users/ncadmin','Personal','personal',1,NULL,0,'#00679e',NULL,'VEVENT',0,NULL),
(2,'principals/system/system','Contact birthdays','contact_birthdays',1,NULL,0,'#E9D859',NULL,'VEVENT',0,NULL),
(3,'principals/users/emily','Personal','personal',1,NULL,0,'#00679e',NULL,'VEVENT',0,NULL);
/*!40000 ALTER TABLE `oc_calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_calendarsubscriptions`
--

DROP TABLE IF EXISTS `oc_calendarsubscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_calendarsubscriptions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) DEFAULT NULL,
  `principaluri` varchar(255) DEFAULT NULL,
  `displayname` varchar(100) DEFAULT NULL,
  `refreshrate` varchar(10) DEFAULT NULL,
  `calendarorder` int(10) unsigned NOT NULL DEFAULT 0,
  `calendarcolor` varchar(255) DEFAULT NULL,
  `striptodos` smallint(6) DEFAULT NULL,
  `stripalarms` smallint(6) DEFAULT NULL,
  `stripattachments` smallint(6) DEFAULT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `synctoken` int(10) unsigned NOT NULL DEFAULT 1,
  `source` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calsub_index` (`principaluri`,`uri`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_calendarsubscriptions`
--

LOCK TABLES `oc_calendarsubscriptions` WRITE;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_calendarsubscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards`
--

DROP TABLE IF EXISTS `oc_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_cards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint(20) NOT NULL DEFAULT 0,
  `carddata` longblob DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `lastmodified` bigint(20) unsigned DEFAULT NULL,
  `etag` varchar(32) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `uid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cards_abiduri` (`addressbookid`,`uri`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards`
--

LOCK TABLES `oc_cards` WRITE;
/*!40000 ALTER TABLE `oc_cards` DISABLE KEYS */;
INSERT INTO `oc_cards` VALUES
(1,1,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.6//EN\r\nUID:emily\r\nFN;X-NC-SCOPE=v2-federated:Emily Carter\r\nN;X-NC-SCOPE=v2-federated:Carter;Emily;;;\r\nEMAIL;TYPE=OTHER;X-NC-SCOPE=v2-federated:emily.carter@example.com\r\nPHOTO;ENCODING=b;TYPE=image/png;0=v2-federated:iVBORw0KGgoAAAANSUhEUgAAAgAA\r\n AAIACAYAAAD0eNT6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAfyUlEQVR4nO3deZDed33Y8c+z++\r\n x9Siut7suWZMmWhWWDjW1siG1CJpg4JIYQCEdIMk2bhqalaUJJZ0rS0JJMkoYwCUknzUHTBALk\r\n AOKAIQYcML6xZUu2LkvWtavVHtr7fLZ/yFACK2kl7f5+z+739ZrxrGbs8eczsrX7fn5noXNgZD\r\n oAgKRU5L0AAJA9AQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAg\r\n AQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQ\r\n AACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAA\r\n CRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACR\r\n IAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIA\r\n AJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJ\r\n AgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAg\r\n AQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQ\r\n AACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAA\r\n CRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACR\r\n IAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIA\r\n AJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJAgAQAACRIAAJ\r\n AgAQAACRIAAJCgYt4LACx2Y5Ol6BkZj77R8egZmYi+0fHo/fbX8RiemIqJqVJMlKZf+lqK8alS\r\n TExNx0SpFBWFQlRVFKKqsiKqKiqiqrIQxYqKqKooRHWxMpqqi9FcWxUtNVXRXFOMlm/9urYqlt\r\n RVx5Laqrx/CyhDAgBgDoxNleJ4/0gcPTMcR8986+twHO0fjp7h8Vx3qylWxsrG2ljVVBurm+pi\r\n VVNtrHzp1xtbG6K26GBwigqdAyPTeS8BsJBMTU/HwZ6h2HPqTOzp6o9nT/XHkb7hmJ5eeN9OC4\r\n VCrGmuiy1LG2NzW2NsaWuMzW1NsaKhJu/VmGcCYBE41DsUP/fZJ/Jegznwe6/fFZuXNua9Bt9l\r\n ojQdT57sjUeO9cQzp/pj3+mBGJucynutedVYXYxrVrTErpWtcd2q1rh6eXNUVhTyXos55BTAIj\r\n BVmo7+0Ym812AOTJb0eLk4OTAaDx3tjm8c7Y7HTvQu+h/4321wfDIePtodDx/tjoizpxF2tDfH\r\n rlVLYteq1rh2RYsgWOAEAMBLjvQNx337T8ZXD5+OI31Dea9TVsYmp+LxE73x+IneiIhoqC7GLe\r\n va4raNy+PmdW1RX1WZ84ZcLAEAJK1vdCK+eLAz7tvfEc919ee9zoIxND4Z9x/sjPsPdkaxoiJu\r\n WL0kbtu4LG7bsDyW1VfnvR6zIACA5ExHxINHTsdnnz8RDx/ticlSKe+VFrTJUikePtYdDx/rjt\r\n /62r64cc3SuPuqVXHbxuVR5TRB2RIAQDLGpkrxD/tOxl89fTSO9Q/nvc6iND09/e0YaK6piu/f\r\n vDLuvmpVbGlzcWu5EQDAotc3OhGf2nMsPvXssTjjgtnM9I9NxCefPRqffPZobGlrijftWBuv27\r\n wyio4KlAUBACxafaMT8SdPHI7PPH8iuav4y83+7oH44Ff2xh8+eijevGNdvHH7mmioduFgngQA\r\n sOiMTZXiE7uPxseeOhJD45N5r8N36B4eiz945ED82ZOH457tq+PHdqyL5R46lAsBACwa0xHx+f\r\n 0d8dFHD0bX0Fje63AewxOT8ZdPvxgPHDoVn/zxW8JJgewJAGBR2N15Jn7ra/tif/dA3qtwEd60\r\n Y50f/jkRAMCCNjZZio8+ejD++tljC/JZ/ClrrqmKe7avznuNZAkAYMF6/ERv/I8Hn4sT/SN5r8\r\n IluHfH2qgruhAwLwIAWHCGJ6biIw8fiL/bezzvVbhEtcXKeNM16/JeI2kCAFhQnj89EO//4jNx\r\n csCn/oXsnu1rornGj6A8+d0HFoy/3Xs8/udD+2NiyqN7F7JiRUX8+LU+/edNAABlb3SyFB968L\r\n n4woGOvFdhDvzAlpXu/S8DAgAoa0f6huN99+/2et5FolAoxE+8bEPeaxACAChj3zzZF7/0hadj\r\n 0NP8Fo3v27Q81rXU5b0GIQCAMvWlQ6fi1768J5nz/YVCIRqqKqOhuhjFikIUKyqiWFGIyopCjE\r\n 2WYmyqFONTUzH+0q8X6u/L26/z6b9cCACg7Hz8maPx4Yf2573GnFreUBMbWhtiQ2t9rGysjfaG\r\n 2ljRWBPL6muisaYYjdXFi34i3tD4VHQNj8Xp4bE4PTQW3SPjcXpoLLqGxuJQ71Ac6x+OqVL5PB\r\n zpprVtsbWtKe81eIkAAMrKh79xID6++8W817gsq5rq4pr25rimvTm2L2+OK5c2Rn3V3D/wpqG6\r\n Mhqq62Nja/2Mf3+yNB2H+4biYM9QHOwZjIM9g/FM55ncTqm8w6f/siIAmLVl9TWxcUlD3mssag\r\n 1Vaf+R/NCDz8XfP3ci7zUuWkttVbx8zdK4cc3SuHHt0mgvkyvcixWF2Ly0MTYvbYyIFRFx9oVJ\r\n z58eiCdO9MbjJ3rjqY6+GJmY/1cl71jREtetap33Ocxe2t9tuCivXNcW77t9W95rsEj99tf3La\r\n gf/kvqquPVG5fHHVe0x65VS6JigbzRphAR25Y1xbZlTfHWnetjano69nYNxD8f6YqvHj49b3db\r\n +PRffgQAkLuPPHwgPvXssbzXuKDKikLcun5Z3LNtddy0rm1RvMWuslCIHe3NsaO9OX72FVfGi2\r\n eG4yuHu+Krh7tiz6n+OZlxxdLGuHX9sjn5dzF3BACQqz967FD85dPlfc6/tbY67t2xNn542+pY\r\n Uled9zrzan1Lfbz9ZRvi7S/bEF1DY3H/wc64/2Bn7Dt96a9Zfrv7/suSAABy87GnjsSfPXk47z\r\n XOaVVTXbx15/p4/VWroqayIu91Mre8oSbeunN9vHXn+jh6ZiTuP9gR9x/sjBf7hmf971jVVBd3\r\n XbliHrfkUgkAIBdffqErPvrIwbzXmNGSuur4yes3xQ9vWx2VC+Xk/jxb11IX775+U7z7+k3xzK\r\n n++MxzJ+JLhzoveAHh2162fsFcH5EaAQBkbl/3YPzql/fkvcb3qK6siJ+4bkO8beeGqC2m94l/\r\n tr51zcAv3LIlvnTwVHzm+RPxTOeZ7/nnltZXx+u3rsphQ2ZDAACZ6h4Zj//0+adibHL+bz27GD\r\n eta4v33ro11jR5TO1s1RUr4+6rVsXdV62K/d2D8YlnjsYXD3bG+EtPKXzLteujOsFTJwuFAAAy\r\n Mz5Vil/+wtPRNTSW9yrf1lxTFe+99aq468r2vFdZ0La0Ncb7X709/u1Nm+NvnzsR9x/oiDduX5\r\n P3WpyHAAAy85v//Pyc3Vo2F25cuzTe/+qrY1n94r6yP0sttVXxzus2xDvd91/2BACQiS8dOhX/\r\n sO9k3mtExNn7+f/NjZvjLdeuy3sVyI0AAOZdx+BofOjB5/JeIyLOXuH/3+7c4bG0JE8AAPOqNB\r\n 3xgQf2xFBOL6D5TluXNcVvvG5nLK8vj2f1Q54EADCv/vTJF+Lpjr6814ib1rXFr9+1I+qKc/9W\r\n PliIBAAwb547PRB/8sThvNeIH9y6Kn759m1RWfBEGvgWAQDMi+mI+I0Hn4vS9HSue/zw9jXxi6\r\n +6KtcdoBwJAGBefHrPsXj+Ml4gMxd+5Oq18d5bt+a6A5Qrj2gC5lzPyHj84aOHct3hh7at9sMf\r\n zkMAAHPuww/tz/Wq/9s2LI9ffNW23ObDQiAAgDn1+IneuP9gZ27zr13ZGh+48xpvoIMLEADAnP\r\n rIwwdym72yqS4+9Npro8YLaOCC/CkB5swDL3TFvpwu/KstVsZvfP/OaKmtymU+LDQCAJgT0xHx\r\n vx7L78K/979me1y5tCG3+bDQCABgTnx+f0cc6RvKZfaPXL027tjkdb5wMQQAcNmmStPxx0+8kM\r\n vsK5Y2xs+/cnMus2EhEwDAZfvsvpNxon8k87nVlRXxq3dcE9Uu+oOL5k8NcNn+aveLucx99w2b\r\n YtMS5/3hUggA4LI8dLQ7Xuwbznzu1mVN8dad6zOfC4uFAAAuy1/tPpr5zIpCId53+3Zv94PLIA\r\n CAS/ZC71A8drwn87lvvHpNbG1rzHwuLCYCALhkeXz6b6qpip++4YrM58JiIwCAS9I/NhlfONCR\r\n +dyfvmFTNNd4kzlcLgEAXJIvHOiI8alSpjNXN9fFG7evyXQmLFYCALgk/7g/+0//P7lrU1R6zR\r\n /MCQEAXLQjZ4Zjb1d/pjPXttTHD2xZmelMWMwEAHDR7tuX/af/d+3aGD78w9wRAMBFy/riv7b6\r\n mnjtlSsynQmLnQAALsoTJ/uic3A005lvumZtFH38hzklAICL8sChU5nOqylWxj2u/Ic5JwCAi/\r\n K1F09nOu+uK9vd9w/zQAAAs3agZzDzw/9vuGp1pvMgFQIAmLWvvdid6bwNrQ1x7YqWTGdCKgQA\r\n MGv/fKQr03l3X7Uq03mQEgEAzErvyHjsOZXtw3/udOsfzBsBAMzKw8eyfe3vjhUtsaKhJtOZkB\r\n IBAMzKkyf7Mp135xXtmc6D1AgAYFae6sg2AG7fuDzTeZAaAQBcUO/oRBw9M5zZvE1LGmJlY21m\r\n 8yBFAgC4oKcz/vR/87q2TOdBigQAcEFPdZzJdN7N65dlOg9SJACAC8ry/H9NsTJ2evgPzDsBAJ\r\n zXZGk6DnQPZjbv6vZmb/6DDAgA4LwO9w3FZKmU2bzrVrZmNgtSJgCA88ry03+EAICsCADgvA72\r\n ZBsAV7c3ZzoPUiUAgPM62DOU2ax1LfVRX1WZ2TxImQAAzutAhkcAti1rymwWpE4AAOfUPzYZ3c\r\n Njmc3bKgAgMwIAOKcjfdkd/o+I2NImACArAgA4p47B0UznbWitz3QepEwAAOd0ciC7AKirqoz2\r\n hprM5kHqBABwTlkeAVjf4tM/ZEkAAOd0cmAks1kCALIlAIBzyvIIwMqm2sxmARHFvBdg4XjyZG\r\n 984IE9ea+xaPzybduipljeDd45mN0tgCsaBQBkSQAwa8f7R+J4f3aHhBe79966NWrK+CBc/9hk\r\n jE1OZTZvpQCATJXvdx8gV2dGJzKd5wgAZEsAADM6M5ZtACytq850HqROAAAz6s8wAAqFQrTUVm\r\n U2DxAAwDn0Z3gKoKWmKgqZTQMiBABwDlkeAWit8+kfsiYAgBn1j01mNqu5RgBA1gQAMKMsjwDU\r\n VVVmNgs4SwAAMxqbLGU2q0EAQOYEADCjyVJ2AeAIAGRPAAAzmihNZzarruihpJA1AQDMaGIquy\r\n MA1ZVuAoSsCQBgRpMZHgGorBAAkDUBAMwoyyMAlQUBAFkTAMCMsjwCUOEIAGROAAAzKk1neArA\r\n EQDInAAAZpTlefksYwM4SwAAMypmGgCZjQJeIgCAGRUrsvv2kOX1BsBZAgCYUbZHAAQAZE0AAD\r\n PK9ghAdrccAmd5/iaztrS+Oja0NOS9xqJR7g+/yfIIwMjEVGazgLMEALN2y7pl8b7bt+W9BhnJ\r\n NAAyfPMgcJZTAMCMaorZfXsYmZjMbBZwlgAAZtRYXZXZLKcAIHsCAJhRU012ZwgHxh0BgKwJAG\r\n BGTdXZBcCZ0YnMZgFnCQBgRo0ZHgEQAJA9AQDMqCnDawBGJ6diPMPXDwMCADiHLK8BiIjocxQA\r\n MiUAgBllHQCnhsYynQepEwDAjNrqajKdd2pwNNN5kDoBAMyotlgRDRneCeAIAGRLAADn1N6Q3V\r\n GAU0OOAECWBABwTu2NtZnNOtY/ktksQAAA55HlEYBjZwQAZEkAAOeUZQAc7x+J0nRm4yB5AgA4\r\n p/aG7E4BTJZK0eFOAMiMAADOaVVTdgEQEfFC72Cm8yBlAgA4pw2tDZnO29ctACArAgA4p2X11Z\r\n k+C+CAAIDMCADgvDa01mc2SwBAdgQAcF6blmR3GuBY/3AMjE9mNg9SJgCA89qY8XUAz3aeyXQe\r\n pEoAAOeV9YWAuwUAZEIAAOd15dJsA+CZU/2ZzoNUCQDgvFY21kZrbXVm83Z3nolJjwSEeScAgA\r\n u6ur05s1ljk1NOA0AGBABwQVcvzy4AIiIeOd6T6TxIkQAALijLIwAREY8eEwAw3wQAcEFZB8De\r\n rv7oGRnPdCakRgAAF9RUXYy1Ldk9ETAi4sHDpzOdB6kRAMCs7FzRkum8rxzpynQepEYAALNy49\r\n qlmc57/HhvDI1PZToTUiIAgFl5+ZpsA2CyVIoHXjiV6UxIiQAAZmVJbVVsaWvKdOY/7u/IdB6k\r\n RAAAs5b1aYAnT/ZGx+BopjMhFQIAmLUbMz4NEBHxD/tOZj4TUiAAgFl72arWqClWZjrz7/aeiK\r\n lp7waAuSYAgFmrqijETRmfBjg9PBZf9UwAmHMCALgod1zRnvnMTz17LPOZsNgJAOCivGrDsqiu\r\n zPZbx5Mne2Nv10CmM2GxEwDARakrVsYr17VlPvfPv3k485mwmAkA4KLdecWKzGd+9XBXHO4bzn\r\n wuLFYCALhot25oy/xugIiIP378hcxnwmIlAICLVlesjFdtWJb53H861BnPn3YtAMwFAQBcknu2\r\n rc5l7h88cjCXubDYCADgktywekmsa6nPfO6jx3vi4WM9mc+FxUYAAJfsnu1rcpn721/fF5MlTw\r\n eEyyEAgEv2+q2roirjZwJERBw7Mxx/8fSLmc+FxUQAAJesuaYYr9mU/ZMBIyL+7MnDcXxgJJfZ\r\n sBgIAOCy3HvN2lzmjk1OxQe/sjeX2bAYCADgsuxob45dq5bkMvubJ/viE894TwBcCgEAXLZ37N\r\n qQ2+yPPnrQEwLhEggA4LLduGZpbF/enMvsscmpeP8Xd8fYZCmX+bBQCQBgTrxj18bcZh/uHYrf\r\n /Nrzuc2HhUgAAHPi9g3LYtOShtzm37fvZPzN3uO5zYeFRgAAc+ZnXn5FrvN/5+v74rHjvbnuAA\r\n uFAADmzKs3Ls/tjoCIiKnSdLz/i7vjiIsC4YIEADCn3nPzligUCrnNHxyfjF+475vRMTia2w6w\r\n EAgAYE5tbWuM129dlesOpwZH4z2fezJOD4/nugeUMwEAzLl/9Yoror6qmOsOx/tH4j2fezK6hs\r\n dy3QPKlQAA5tzSuup4Z463BX7Lkb6h+Nm/ezyO9XtnAHw3AQDMix/fuS625fRwoO/UMTgaP/v3\r\n j8fzpwfyXgXKigAA5kVloRC/8urtubwu+Lv1jozHv/7ME3H/wc68V4Gykf+fTGDR2rSkIX7qhk\r\n 15rxERZx8Z/F//6dn4/UcORmk6720gfwIAmFdv27khrm7P/1TAt/zFU0fi5z77hNsESZ4AAOZV\r\n RSHiV15zddQUK/Ne5due7uiLd3zqkfj8AacESJcAAObdhpb6+KXbtuW9xr8wND4Zv/rAs/Ef//\r\n GpODngaADpEQBAJl63eUX86DVr817jezx0tDve9smH48+/eSQmXBxAQgQAkJl/98otsXNla95r\r\n fI+xyan4w0cPxps//lB8bt9JFwnOkQM9g/Gxp47E1LTf0HKU76O6gKRUVhTi1+/aEe/69KPRXY\r\n ZP6Ds1OBof/Mre+L9PvxjvvG5j3Hlle1Tm+F6DhWZ4YioePd4TX3+xO75xtDtOv/Tf+Md2rIvK\r\n Sr+P5UYAAJlaWlcdH3zttfGezz0ZY5NTea8zo8O9Q/GBB56Njz56MN68Y1380LbVUV9VPhcxlo\r\n uJ0nTs7jwTjx/vicdP9Maerv6YcvhkwRAAQOZ2tDfHr915Tbzv/t1l/QOjc3A0fu8b++OPHjsU\r\n d1zRHj+0bXXsXNGS91q5GZsqxd5T/fHUSz/0d3eeifGpUt5rcYkEAJCLW9cvi/98+/b4tS/vyX\r\n uVCxqbnIr79p2M+/adjLXN9fF9VyyP12xqj23LmvJebV71jIzH7s4z8XTHmXi6sy/2nR6MyZIf\r\n +ItFoXNgpHzzm1nZ3z0Y7/r0I/M+Z2VT3aL/hpe3n7tpc6xuqs17jUx94pmj8bsP7c97jUuyor\r\n E2blnfFi9fvTSuX70kmmsW7meq/rHJ2NvVH8+dHojnuvpjb1d/dA3NzXUaD7z7NVFdBo+E5l9a\r\n uP+3krmOgZHoGPBWtfn09us2JBcAb96xLs6MTsSfPnk471UuWufgaPzNnuPxN3uOR6FQiC1tjb\r\n GjvSW2L2+O7cubYuOShii3S9+GJ6biSN9QvNA7HC/0DcXh3qE41DPoyYgJEgBA7n7m5VdERUUh\r\n /vfjL+S9yiWbnp6OfacHYt93vHWwplgZ61vqY0NrfaxvrY/1LfXR3lAbyxtqYll99Zx/Kh6bLE\r\n X/+ET0jkzEqcHR6Bwa+/bXzsHR6BgcjVN+0PMSAQCUhZ+6flO01FTF73x9X96rzJmxyanY3z0Q\r\n +7tnfhVxc01VNNUUo7G6GE01VdFQXYzqyoooVhS+/VdExGRpOianpmOyVIqJ0v//OjQ+GQNjk9\r\n E/NhEDY5POz3NRBABQNu69Zm001VTFr39lT1nfHTBX+scmon9sIu81SJSrMoCy8rrNK+K/v3an\r\n i8ZgnvkTBpSdW9e3xe+/4YZob0zrgkjIkgAAytL25U3xJ298RVy/ekneq8CiJACAstVaWxW/+4\r\n O74i3Xrs97FVh0BABQ1ioKET//ys3xgTt2RJ3n8cOcEQDAgnDXle3xf+69KW5wSgDmhAAAFoyV\r\n jbXx4dfviv9w61VRW3Q0AC6HAAAWnB+9ek187N6bYtcqRwPgUgkAYEFa3VQbH7l7V7zv9u3RVl\r\n +T9zqw4AgAYEG7+6pV8YkfuznetWtj1DgtALMmAIAFr7ZYET/z8ivi429+ZfzAlpV5rwMLggAA\r\n Fo3lDTXxX15zdfzpj9wYd125IioK5fYyXigfAgBYdLa0NcYH7rgm/votN8e916xzx0COWmqrhF\r\n iZ8jZAYNFa2Vgb//6WLfFTN2yKT+05Fp/ecyx6hsfzXmvRq68qxu0bl8Vrr1wRr1i7NCoFQFkS\r\n AMCi11xTjJ/ctTHeed3GePhYd9y3vyMePNwV41OlvFdbNGqLlXHTura468r2eNX6Zd7muAAIAC\r\n AZFYWIm9e1xc3r2mJ4Yiq+dKgz7tvXEU919OW92oK0qqkublnfFreuXxbXr14SVRU+6S8kAgBI\r\n Un1VZbzhqtXxhqtWR9fwWHzjaHc8dLQnHjveE0Pjk3mvV5Yaq4uxc2VrXL96Sdyyri02tNbnvR\r\n KXQQAAyVteX/PtGJiano7dHWfioaPd8fCxnjjQMxjT09N5r5iLJXXV8bKVrXHdqta4bmVrbG5r\r\n DJ/xF49C58BImv9nA8zCyORUPNc1EHu6+mPPqf7Y09UfpwZH815rzq1urostbU2xta3x7Ndljb\r\n HcExYXNQEAcJF6Rsbj+dMDcfTMcBw9M3L2a/9InBocjVKZHi0oFAqxrL46VjbVxcrG2ljbXBfr\r\n WupjfUtdbGhtiHqvWk6OAACYI5Ol6Tg+MBIn+0eid3QiekfGo3d0IvpGxqNvdCL6Rs9+HZ2cio\r\n mp6ZiYKsVEqRRTpdl9Gy5WVERVZSFqi5VRU6yM2mJF1FdVRkNVMRqri9FQXYzm2qpora2Klpqq\r\n WFJXFUvramJZQ3W01dWEa/T4TgIAoAyMT5ViYmo6pl46glBRiKgoFKKiUIhixdm/YC65CBCgDF\r\n RXVkS1o/BkyJMaACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQA\r\n ACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAAC\r\n BBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBB\r\n AgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAg\r\n AAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAA\r\n EiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEi\r\n QAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQA\r\n ACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAAC\r\n BBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBB\r\n AgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAg\r\n AAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAA\r\n EiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEiQAACBBAgAAEi\r\n QAACBBAgAAEiQAACBB/w+riVzUlZIqmwAAAABJRU5ErkJggg==\r\nX-SOCIALPROFILE;TYPE=NEXTCLOUD;X-NC-SCOPE=v2-published:http://localhost/ind\r\n ex.php/u/emily\r\nCLOUD:emily@http://localhost\r\nEND:VCARD\r\n','Database:emily.vcf',1795099338,'aba31735cb3fdb1b911e0437d78072d2',11814,'emily'),
(2,1,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.6//EN\r\nUID:james\r\nFN;X-NC-SCOPE=v2-federated:James Walker\r\nN;X-NC-SCOPE=v2-federated:Walker;James;;;\r\nEMAIL;TYPE=OTHER;X-NC-SCOPE=v2-federated:james.walker@example.com\r\nPHOTO;ENCODING=b;TYPE=image/png;0=v2-federated:iVBORw0KGgoAAAANSUhEUgAAAgAA\r\n AAIACAYAAAD0eNT6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR4nO3dyY9d13bf8bVPfz\r\n u2YiOKlERSJNU8N4ENwwFiOBkFCBA7mSXIJJ4lQLr/IP9BECCTDDNJACPIKKMgcCbOAzII4NiW\r\n xKdHUaIkSqRIil1V3Xv6k0GpJDbV11n7NPv7AQw8vyeddd4r6tbv7rX32qbIHjcCAACc4nX9Ag\r\n AAwD4CAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAA\r\n AOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAA\r\n DgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA\r\n 4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAO\r\n AgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADg\r\n IAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4C\r\n ACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAg\r\n AgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIA\r\n IAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CAC\r\n AAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAg\r\n AAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIA\r\n AAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAA\r\n AADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAA\r\n AA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAA\r\n AOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4KCg6xfA\r\n 4RTpXSnzR+p1kvkHYrxYvQ4AwC4CwECtPfpfsv74l+p13rzxbyWML6jXedGz7/+7rNb+2kqtE+\r\n f/oSTzD6zUclG+vC2Pv/tTK7Wmx39Hjp35u1ZquSzbuCVP7v1XK7Umi1/I8XN/ZKWWiwgA6J0g\r\n PCn58isrtVbP/5oAoGj57C+s/SybakUAsGC19rG1n+n81N+yUsdV7AFA7yQLe7+Qs43PrNVy0e\r\n r5X1mrVWQPpMzuW6vnqmz9V9ZqEc51EQDQO354WoLoDSu18tVdqat1K7VcU+YPpci+t1pz9fwv\r\n rdZzTVNnkq++tlIriE5LEJ2xUstVBAD0ktVVgPVfW6vlElv7OF60tLji4KJs45Y0TW2lFt/+9R\r\n EA0Es2/+FPaQOoSJ/bDwD58gupqw3rdV2Rrtv7Z8XmlwBXEQDQS8n8fWu1bH6ouaKpc0k37K+s\r\n NE0tqw6ChytshmWbnwGuIgCglzx/JtHkkpVaRXpP6nLNSi1XpOs3panLTmqv1tgHoKGpV1Ksvr\r\n FSK5pcEs+fW6nlMgIAeos2wHB10f/fkq59KtJUndUfq5T+/+gQANBbNnuAqcWjTS5In3/cWe26\r\n Sgl0CjL6/6NDAEBvxbNrYjw7s6psfriNXZHelbJ40uk72Jw/4Apbe2WMF0g8u2allusIAOgtY0\r\n KJp1es1CqyB1KVT63UGrs+bMIjALSrrpZSpHet1IqnV8WY0Eot1xEA0Gs2e4GsArSjy/7/ljL/\r\n QYr0265fYzSyjV9L0zRWatH/t4cAgF6zuhGQAHBkdbWUfPll168hIkwFbFNqcVgW/X97CADotW\r\n j6rnj+xEotAsDRpWsfW9spvhfaAO2xdWeG508kmrxjpRYIAOg9I8n8upVKZf5IquKxlVpj1Yfl\r\n /y3Z8kvmO7SgrjYkX9np/28O/zFWaoEAgAGgDTAUjaRrn3T9Ei9ZrbEKcFRWj//R/7eKAIDesx\r\n sAmAdwWPnyC6nKfs3hZx/A0dkc6Uz/3y4CAHoviM9LEJ6wUouTAIfXh+N/r0rXboo03YwkHgtb\r\n q2JBdFKC6KyVWthEAMAgxJYuBimLJ1LmD63UGps+9f+31HXOqs4R1NW6FOl3Vmqx/G8fAQCDwD\r\n yAfquKp9Y2ih0UbYDDs3r9LwHAOgIABoF7Afqtj9/+t3Ac8PDYADhuBAAMgh8clzB500otLpI5\r\n uLSH/f8tZfFUitXXXb/GINn6ZyGaXBQvWFiphZ8RADAYiaV9AFXxXMrsvpVao9CUkq7f7Potdr\r\n VkFeDA6nJNitTOPwd8++8GAQCDwTyAfko3fi11nXf9GrtiH8DBpRv2WmG2wj1eRgDAYCTzG2KM\r\n nT+yNj/8hm4IPfZ89TW3PR6Qtet/jS/xzM60T7yMAIDBMF4i0eRdK7Uyi5efDN1q7eOuX2Ffhh\r\n BU+sTWPwPx7IoYL7JSCy8jAGBQbJ0GqMp1rpPdhzL7XspsGHMTaAPsX1U+kyL73kot+v/dIQBg\r\n UGz2CjkNsLc+H/97Vbr+mTRNv/cq9AXH/9xAAMCgxNOr4llaLmQg0N76OP53J01dbI4Gxp5szc\r\n Lw/ESi6WUrtfA6AgCGxfgSz65ZKZWu/1pEGiu1hqipM8k2brX+XGN88fyk9eeK0AbYL1sXACWz\r\n G8L1v90hAGBwbC0Z1tVSirSf4237IF37RJqmav25fnhSbbPnkFYsulIVT6zt6+D2v24RADA4yc\r\n LiPgDaADvS2v0fRG9IPLui8uyqfC756kuVZ48F8//dQQDA4ITJJfGDuZVa3AuwM60AECZvSjy9\r\n qvJsEY4D7iWztPk1CE9IEJ+3UgvbIwBgkGydBtjscbMP4FX56mupimcqzw6TC6obw1bP2AewG1\r\n srAHz77x4BAIMUWwoAdZVKvvrKSq0hSRWP/0XJW+L5MwnjsyrPz9NvpSoeqzx76KrisZT5D1Zq\r\n 0f/vHgEAgzSZf2itFvsAXqe5jB4mF0VEJJrq7AMQ4TTATuz2/5n/3zUCAAbJj05LEL1hpRbzAF\r\n 5Wl2tqqyJhfE6MF4uISKwaANgHsB1be17C5IJ4wXErtbAzAgAGy9YS4uY+gPaPuw3Vau1jaRqd\r\n fRHR5O2f/nU809sImK5/Jk2dqT1/qDJb5//p//cCAQCDZWsJsa5zyZd3rNQaglTx8p9o+u5P/z\r\n pM3hLvx9WAtjVNJenaJyrPHqoyfyhlbmdvxIT+fy8QADBYVu8FoA3wo1pWir84Xx4AZFRPAyzZ\r\n B/ASW9/+jfG4/rcnCAAYLM+fSzS5ZKUWAWBTtvG51NVK5dnGeC+1AERE4tl7KrVEtlYyOOK5xd\r\n af8Wh6+ad9HugWAQCDZquXmC1vizSllVp9pjlKN0wuvHYvvOY+gKpc3/y5QkTsbXal/98fBAAM\r\n mq02QFMXki2/sFKrzzSv/91uuT+eXhVj9D6mOA2wqcwfSFk8tVKL8//9QQDAoMXza2KMb6WW62\r\n 2AqngsRXpP7fnbHfszXvxaW6BNBIBNtv5se36ierwTB0MAwKAZE6kuE7/I1oz0vtK+SW+nXwzx\r\n /IZazSK9J2Vu5+a7PrO1/L+5+Y9fO33BTwKDZ20fwMYX0jSFlVp9tFrT+7bs+dMdL4ZJlHeMMx\r\n VQJOX8v5MIABg8a/sAmkryDTc3jTVNobpMvNsqTjzTbfO43gYos/tqFzu9iv5/vxAAMHjR9LJ4\r\n /sRKLVevB87WfyVNrbf6sdtxP+PFLw0Ialu2cUuaWudo4xDY6v/74XEJ4zet1ML+EAAwAkZ9mX\r\n hL6ug+APX+/x7n/TVXeZqmltVzvemGfWfrzzSX//QPAQCjYGtpMV/ecXKG/Epx/K/xAolfmgD4\r\n Ou1fHi7vA8jW6f+7igCAUbC3D6CWbONzK7X6osi+U70jPpq8I2KCXf+aeHZV7V4Aka2AU6s9v6\r\n +K7J5U5ZqVWvT/+4cAgFEI4jfFD+1cL+paGyBVXv7fX/vGl3iu1+apq9WPtz66JbN2/e958YMT\r\n Vmph/wgAGA1rxwEdGwikOf1PZP/n/JP5h6rv4eJpgJTlf6cRADAattoA+eprZ3aNN/VKMsWjj8\r\n b4+x7kNFkQANpm6wZAAkA/EQAwGrZ6jC7tA1itfSJNo9cbj6aXxZho779QRIL4vATRKbV3KbIH\r\n Umb31Z7fN0X6rVTlunodYzxJFKc54vAIABgNPzghYbL9NLm2uTIPQPv430F/Mei3Adw5DWBrL0\r\n s0fVeMl1iphYMhAGBUbC01unExUCOp4vE/kYO3bRLlNsDSoTYA1/+CAIBRsbcP4Bupq6WVWl3J\r\n l3dUl4iNFx74Zrhk/oHq9cD58gupqw215/dHI6mlUw8EgP4iAGBUkvkN1V8QL7K1gaor2rv/k9\r\n m1Pc//v8rzp5tzA5RsTgXU/e/dB0V6V+pSP+h4XiTxjOt/+4oAgFEx3kT1F8SLxr4PQL3/f8jl\r\n /GTxUctv8rLV2vj3AdhqYW3ObtC7yAlHQwDA6Ng6DTDmeQB1+Uzy1deqNQ77i1z7OGC69qlIU6\r\n nW6JqtAMDyf78RADA61vYBpN9JXekfo+qC5ux/ka2b4S4c6u+NpldUb3+sq1TSUbd3GmtTDwkA\r\n /UYAwOjE06viefs7W35UYz0NoL38PznSMr7hcqAj2NzAqj/Iyg8WEiZvqdfB4REAMD4m2PN62b\r\n bYmqVuVyXp+k3VCkc9z699HHDMUwHtHf/j+t++IwBglJgHcHjZ+i2pq1Tt+caYI/8CP9oKwt7K\r\n /Acp0m9Va3Ql3bATWrn9r/8IABglW98+iux7qctnVmrZon38b7OHPzvSM/zwtITxuZbeaHvjXA\r\n VorI2xpv/ffwQAjFI4eVv8YG6l1thWAdT7/8d+s5Xn6LcBxrcPIF99pbq6syWMz4kf6t3bgHYQ\r\n ADBa+71m9qjGFADK/KEU2feqNSaL32jpObptgGz5pdTlmmoN2zj+hxcRADBattoAti5VsUH723\r\n 8QnWxtZ3g8uyHG6A6ZWa2Nqw1gbQMg/f9BIABgtGx9Cymzh1IVT6zU0pYq/8Jr69u/iIjxIoln\r\n V1t73nbG1Qawc4011/8OBwEAoxVEZySI3rBSawxtgKbO1S+Iaav//9PzWgwU20nXboo0pWoNW/\r\n LlHanrTL1ONHlbjKc3qAntIQBg1Gy1AcYwDyBdvylNrffLznhh6/sy2g4Ur6rrfDR3PtD/x6sI\r\n ABi1ZME+gP3Sv/3vuhjT7oTGID4vQXym1We+aixtgMzSn1H6/8NBAMCoWdsHkD+WMn9kpZaWVP\r\n 34n85yvXYbYBzzACrJNm6rVzFeKPFUd18G2kMAwKh5/lyiyUUrtWx9w9JQpHelLJ6q1kgWv1B5\r\n rnYboCyeSqF8M6K2bPml1HWuXieZXRMxgXodtIMAgNFjLPDetL/lhvE5CSKdpfpkdl08P1F59p\r\n blwFcBsnU7txvS/x8WAgBGz9o8gAFvFtPu/2st/4uIiPHVf/EMfR+AtQ2A9P8HhQCA0Ytn19UH\r\n xoiIVMUzKfMH6nXaVlcbki+/VK2htfy/RbsNkK++lqrUbZGoaSrJlvr9fz+YS5hcUq+D9hAAMH\r\n qbA2OuWKk1xFWAdO0TaZpG7fmeF0syu672fBH9jYAiw90MmC2/kKYu1Otw/e/wEADgBFu9SVuj\r\n Vtuk/YstWXwgorwC4wULiafvqtYYagDg/D92QgCAE+ztAxhaAGhktf6pagUb385F9NsA6fqvpG\r\n n0d9K3jfP/2AkBAE6IppfVd4qLiFTlmhTZPfU6bcmWt6UuN1RrJMd0+/9bJsd+S/X5TV1sjgYe\r\n kqaUbPmFepkgPiN+eFq9DtpFAIAjPImV+9BbhjQWWHv4TzS5KH5wQrXGljC5KEF4UrXG0E4DZM\r\n vbquOdt0xY/h8kAgCcYWuJckhtAO3rf20t//9UT/O4oej/79U2+v/YDQEAzrC2EXDDztCVo6qK\r\n p5Kn36rWsLX8v0V7H0BVPpd8pXtksk02AoAxRmJOAAwSAQDOCOM3xQ+Pq9epyg0p0rvqdY5qta\r\n a7q93zp9bnwsfz98V4oWqNoZwGaJpCfb6DiEg4eVs8f6peB+0jAMApnAb4mf7y/0ciYlRrvMqY\r\n UP1nPJQAkG18Lk1Tqddh+X+4CABwir17AXq+EbAp1Tcr2l7+36I/FfCuVMVj1RptsDWTggFAw0\r\n UAgFPs7QO4JSJ60/WOKl3/TPV2OGOMTJTH/+5kstANACLDOA2QWtiLYrxw8wZADBIBAE7xwxMS\r\n xufU69TVSvIeXyGrfflPNHlXPH+uWmMnfnhC/QrovrcBmjqXfHlHvU48e4/rfweMAADn2DoO2O\r\n exwOr9f+XjeHvX154K+Jk0daZa4yiyJf1/7I0AAOdY2wdgaQTrQZXZfSnzR6o1tG//24t2G6Bp\r\n KknXPlGtcRSc/8d+EADgnGR+Q4zR/6Ofrd8SkVq9zkFpL//7wTGJJu+o1thLNH1X/GChWmPZ43\r\n 0ANlafvGAm0YTrf4eMAADnGG8i0eRt9Tp1nUm+/Eq9zkHpL/93++1/k/4mxHTtY+njRs+mziRf\r\n 6f+5S+Y3xPYxT7SLAAAnuXocsKlTyTY+V63R9fL/Fv2pgOuSLW+r1jiMbOOWNI3+yhPL/8NHAI\r\n CTrN0L0LN9AOnap6qbw4zxZLL4UO35B5EsPhJjfNUafTwNQP8f+0UAgJPi6VX1kbEim9PYxMJu\r\n 7P3S7v/Hs/fEeBPVGvtlvFhi5TPqfQwAmYXQGUSnJYjOqNeBLgIA3GQCSWbvqZdp6kIyC/PY92\r\n u19rHq87sa/rMT7TZAkd6TMn+oWuMgmjqVfPWNeh2+/Y8DAQDOsjcVsB9tgHz1lVTFc9UaScfn\r\n /1+lHQBE+jUV0Fr/31ILDboIAHBW7NhGQO3d/0F0SsL4gmqNgwqiM+qTH/vUBrDX/2f+/xgQAO\r\n CsaHJJ/GCmXidbfiHSlOp19pIq9//7tvy/RXsVINu4JU29Uq2xXzbCZjS51NmYZ7SLAACHGYnn\r\n N9SrNHXZ+XGxulyTTHk2fN+W/7doB4CmqWX1XHdvxb7eo15Jkd5Vr0P/fzwIAHCavXkA3e4D0N\r\n 78Z7ygt8vC8ew98Xzdkwl92AeQrv9amkZ/MBH9//EgAMBprgwEWq3p9qmT2Q0xJlKtcXieTBYf\r\n qVbYDFjdjn22ETKNF6gfrYQ9BAA4LYjOSBCdVq+TL+9IU+fqdbZXS7p2U7VC0ovxvzvTbgPU1U\r\n p9wuJebJw2iadXxRj9+RmwgwAA59lYum6aSrJlN78gso3Ppa50N6lNFv3s/29JFr9QvwCqyzZA\r\n XW1IvqL/j4MhAMB51uYBdLQPQPv4Xxif6/1UOM+fSTS9rFqjy+OA2cavrdSh/z8uBAA4z9bmta\r\n 42AmqP/+3H7X97U58KmD2QMruvWmMnNv5sef6k82ue0S4CAJznBQuJJhfV6+Srr6SpM/U6L6ry\r\n H6RI76nWSHq+/L/FzlTAblYBbKwubQZlrv8dEwIAIHbaAE1TS7ZxS73Oi7R3/3teJMlAdoWH8Q\r\n X1DZ/LDvYB1NW65Ol36nXo/48PAQAQm20Au8cBtfv/yeIDEROo1mjTRHlYUb78QupqQ7XGq6yN\r\n /6X/PzoEAEBE4tl19bvjRezuA2iaXFLlzWFDWf7fMllYmAqovOfiVdm6/gbAIDopQXRWvQ7sIg\r\n AAImK8SOLpFfU6RfqNtbnx2fpn0tSFao2+H/97VTK/IZ6nO7DI9nHA1ML5/2T+oXoN2EcAAH5k\r\n Y4mzaRpJLXxjE9HfkBYlb4kfnlCt0ToTqP+c07VPRZpKtcaWulxT3+QpQv9/rAgAwI/GdhxQe/\r\n 6/dj9di3YboK5S9dbLlnTDzp6Svt7zgKMhAAA/iqaXxfMT9To2RrYW6bdS5o9Vawyt/7/FRnCx\r\n 1Qaw0f+PJhfFCxbqdWAfAQD4iSfx7Lp6lXx1V+pqXbWG9kY0z59IPLuqWkOLFxyXaKo70MbWPA\r\n Abq0ks/48XAQB4gb2xwLrf3FLl++k3b9cb7lAY7c2LZf6DFOm3qjXq8pkU2feqNURY/h8zAgDw\r\n gmQx/H0AdbWUbHlb7fkiw13+3zKGqYBWrv81vpVVMXSDAAC8IIwviB8eU6+jeXQrXf9Emkb3bv\r\n rNFYDhiibviB8eV62hvQ/ARgCIZ1fEKB+bRHcIAMArbLQBivSe1OVzlWdrT/+Lp++OYlPYZKF7\r\n iVG2/FLqck3t+XbO/9P/HzMCAPAKa8cBVT7AG0nXPlF47s+Gvvy/xUobQOkuhqp4KmX2UOXZLy\r\n IAjBsBAHiFrQ89jSXcfHlHqlL3hMFQz/+/Kpl/KMbTvcdAax+AjfP/np9INL2sXgfdIQAAr/DD\r\n kxLG59TraFzhqj38xw8Wo7kT3niRJLMbqjU2pwKWrT/XzvW/N2TIJz2wNwIAsA0r+wCyB1IVT1\r\n t9Zrr2aavPe5V239w27dWMus5VVnpsjJNm+X/8CADANmwdB2xzKmBTryRf3WntedtJRrL8v2Vy\r\n 7LfUa7Q9lKkqn0qZP2r1mdshAIwfAQDYRjJ/X4zRX/5s89thunZT9fifMZ5MFuO6Fc4PT0mYXF\r\n Ct0fapDCvX/4YnJIjPq9dBtwgAwDaMN7HS624zAKzWdZf/4+lVMd5EtUYXtE8DlPkjKbP2buyz\r\n cdEQ3/7dQAAAdmDjQ7DMH0lVtHNpj3b/f2zL/1vsXA7U3ipAtnGrtWftxMbV2OgeAQDYwZCuBy\r\n 7zB1LmP7TwNjsb2wbALfH0qvjBTLVGW/sA6nJNivR+K8/aDfP/3UAAAHYQz94T44XqddL1o5/p\r\n 1h7+E0QnJUzeUq3RHSOJ9lTAjc+lqdMWnqP/7T9MLogX6I5JRj8QAICdmEDi2XvqZdr4UF9pL/\r\n +P9Nv/Fu02QNPU7QQ9+v9oEQEA2IWdfQA/HHEeQKU+GEb7+tyuTRa/EGN0Pw7b2KNhYwVgQv/f\r\n GQQAYBe2eqFH+WDPNm5LXWctvs3LjBeM/luh8Sbqqz1HPaVRV0sp0m9bepvtGeNx/a9DCADALq\r\n LJ2+IpbxATOVoAUN/9P7vmxJWwk4XyccDs4ZEG+GQbt6Rpmhbf6HXR9LIYL1atgf4gAAC7Murz\r\n 4kWOGADWb7b4Jq9LlH8x9oWN44DpEVYBrBz/m49r0BN2RwAA9mCjDZCn30ldLQ/89zV1Jvnqa4\r\n U3+tnk2Lg3AG4J4vMSxmdVaxxltYb+P9pGAAD2YGsoSr68feC/J1veVh3/G8ZnJYh0fyn2SaK8\r\n 2XFz5sPBl/GbJlcPelz/6x4CALCHIDorQXRavU62cYgAsPG5wpv8bOzH/16lfjvgITfy5cs7qk\r\n FPRH7c/MevBJfw0wb2wUYbIFt+efC/R3lZ2EZfvE+S+XXx/ES1xmEmP2bLLxTe5GVjP+mB1xEA\r\n gH2wsg9g+aUcbHm4knx5R+ltRDwvksS5I2G++ka4w8xsyG0EAPr/ziEAAPtg49tRXWcHWh7OV1\r\n 9LXedq7xPP3xcxgdrz+0r7dsB045YcdB9AtnHw1aGD8MPjEsZvqtZA/xAAgH3wgoVEFmbhH2Sp\r\n N1vX7f+7tvy/ZXLsN8QYo/b8zX0Ad/f911f5D1KVz9XeR4TLf1xFAAD2ycYSab5xgACwVO7/j3\r\n z87048fy7RRHc3fLq+/5n+9P+hhQAA7JOVjYCrO/v/aw9xamC/ouSC+OFJtef3nfbqR7bc/+pN\r\n dojjoQdF/99NBABgn+LZdTHGV61RZvel2cdc/zK7L1W5rvYeiaPL/1u09wEcJLzlhzgdchBhcl\r\n 784IRqDfQTAQDYJ+PF6oNSmqbZ18CXVPv4n6PL/1vC5KIEkd4KSFU8kyr/Ye+/sCklX32j9h4i\r\n LP+7jAAAHICND8t8H20AzQFAnj+ReHZV7flDoR2C9tMGyFdfSdNUqu9BAHAXAQA4gGRhYx7AV3\r\n v+NZoBIFl8KHw02GgD7P0z1N4AaIwnyVz/siv0E/+UAwcQT6+oT4rbayNgXa0f6VrZvbi+/L8l\r\n nr8vxgvVnr+ffQDaASCavivG0/3zjP4iAAAH4kk8u6ZaocweSlOnO/7nmtP/REQmjs3/34kxoe\r\n ryeJF9t+eGT+2fNcv/biMAAAdkZx/Azhu/MsVfCvH0HfGChdrzh0bzOODmhs87O/7nmys9j9Xq\r\n ixAAXEcAAA7Iyr0AuwSA/WwSPCzt63CHRn0fwC5hTv36Xy+SeHZFtQb6jQAAHFCYvCV+eEy1Rp\r\n HuEgAUVwBcHf+7Ez84IdHkktrzdzvjv5/NoEcRz6+LiO5cC/QbAQA4BO1VgJ2+/VXFY6nKNZWa\r\n fjCXaPKOyrOHTHMVYLcwl690AwDL/yAAAIegHQCK9J7INue/NX8pJItfiIjeJThDpbkqUhZPpC\r\n 6fbfufabcACAAgAACHoP3h2TSVFNm91/59zalwk2Ps/t9ONLksvuLGyO32AdTVUsr9TAo8JD9Y\r\n SGjhdkv0GwEAOAQ/PCVhfFa1RpF++9q/pxUANgfCfKTy7DHQXAXY7pv+Qa4LPgyu/4UIAQA4NO\r\n 1VgHybALDb5sCjiKZXxPOnKs8eA83hSNsFgFw7ACw+VH0+hoEAAByS/j6AlwPA5rLwE5Va7P7f\r\n XbL4SO0myO32dRQr7RUA+v8gAACHFs/fF2P0Ns29GgC0vv2LMP53L8aLfzw2176qeCb1Kyc7NF\r\n sAYXxO/FDvpkMMBwEAOCTPn0o0eVvt+WX+RJp69dP/n69ebwm0IQhPsiFsHyYLxeOAL60CNJKn\r\n 36nV4ts/thAAgCPQ/jAt0p9PAuPGfx8AAAyjSURBVBSZzi+FhN3/+6I6D+CFzZ1l/lCaulCrlS\r\n wIANhEAACOINbeB5Dd//lfK30r5PKf/QmiNyRMzqs8+8V2j9bPWYTrf/EyAgBwBMnsmuqVsS+t\r\n AKSvzwU4KmN8loQPQKsNkL8UANr/OW+JJm+L8SZqz8ewEACAozCBxNOrao/fWgGoy2dSV8vWnx\r\n /Pr4vx4tafO1ZapyXK7P5Pkx+3GwDVFsIeXkQAAI5Is6da/hgAtDaFsfx/MPHsPZV5CU1T//SL\r\n X7MFQP8fLyIAAEek+a2qzB+JNNVPQaBtHP87KE8mC52JiVv7AMrse5XnGy9UXa3C8BAAgCOKJm\r\n +rTdFrmlrK/KEU2YPWnx3EZySIz7X+3LHTOg1QpPekKp5IXecqz09m10RMoPJsDBMBADgyo7qz\r\n uswfSpm3HwBY/j+cZPELMab9j84iu6/yc96SzBn/i5cRAIAWaLYBiuyBlNnD1p/L8v/heP5Uou\r\n mV1p9bZPelUFr+F6H/j9cRAIAWaG8ELPNHrT7T8yLOgx+BRhugzB5Ikers9fCDuYTJRZVnY7gI\r\n AEALguisBNEplWen659J8+MRsbbE8/fpBx+BRgBomkrS9U9bf64I1/9iewQAoCVaH7Iay8L0/4\r\n 8mjN+UIHqj9edqDQHi/D+2QwAAWjKkD1mu/z26If1vSP8f2yEAAC0ZSgAIkwvihzrtCpdoXg7U\r\n piA+I354uuvXQA8RAICWeMFCouRC16+xJ5b/25HMros3gDHKk4EEU9hHAABaNISl1iEtXfeaCQ\r\n bx8x7KyhTsIwAALer7h63nTySevdf1a4xG39sAxhj1K6sxXAQAoEXx7LoY43f9Gjva/MbKP/Zt\r\n 6fswpVBxTDWGj08CoEXGiyWavtv1a+yo77+whsYLjkk8fafr19hR31ek0C0CANCyPn/osgGwfc\r\n miv20ANgBiNwQAoGV9DQDR9B3xgmNdv8bo9HUfgPFC9ntgVwQAoGXx7HIvj4fx7V9HNHlb/PB4\r\n 16/xmnj2HuOesSsCANA6X+L5ta5f4jX0//X08X/bvq5EoT8IAICCvn34+sG815sTh66PbYC+/R\r\n lE/xAAAAV9+/BNFh+JiOn6NUYrWXwgxgu7fo2feMFMosmlrl8DPUcAABSEyVvi92jDXR+XqMfE\r\n mEiS2fWuX+MnyfyGEPiwFwIAoGTzQ7h7xng/rgBAU5/aAH1bgUI/EQAAJX2ZEx9NLzMNzgICAI\r\n aGAAAo6cuHMMv/dvjhqV7cBhlEpyWIznT9GhgAAgCgxA9PSRif7fo1uP3Poj6sAvQleKL/CACA\r\n oqTjm9j88LiEycVO38ElvQgAiw+7fgUMBAEAUNT1tzGW/+2KplfED+advkNfNp+i/wgAgKJ4/r\r\n 4Y091xLJb/bTOdnriIJpfE87sNIBgOAgCgyPOnEk7e7qS2MX7nKxAu6rINwM8bB0EAAJR19aEc\r\n z66J6eGlRGM3WXwkxnTz0dqXo6cYBgIAoKyrjYAs/3fDeJNOruE1XiDxrH+XUKG/CACAsmR2rZ\r\n M58Vz/250u2gDx9KoY05/7CNB/BABAmwkknl61WjKI3pAgPm+1Jn42WdgPAPT/cVAEAOyBC0Xa\r\n YLs3y/J/t4L4nPUhUPT/cVAEAOzKmKDrVxgF2/sAWP7vns0Q5vkTiSbvWKuHcSAAYFd9uuN8yK\r\n LJO9Yu5DFe2PkEQthtA2z+vFmtw8EQAAaqaSorddhU1BZjbUJbMr8hwspN5+L5NfH8iZVa9P9x\r\n GHxKDBUBYHDeeOefdf0KsMqXix/9+65fAtgRKwADZW0FgBYAAIwSAWCgmnqlXsMYX+grAsA4EQ\r\n AGqq4sBAC+/QPAaBEABqquluo1vGChXgMA0A0CwEBVxVP1GkF4Qr0GAKAbBIABqqul1HWuXscP\r\n CAAAMFYEgAGqisdW6visAADAaBEABqhIv7NSxw+PW6kDALCPADBA9gIAKwAAMFYEgAHKV19bqR\r\n OEp6zUAQDYRwAYnEay5W0rlcLkopU6AAD7CAADU6y+kbpK1esE0RtivFi9DgCgGwSAgVk+/ysr\r\n daLJJSt1AADdIAAMzOr5/7NShwAAAONGABiQIv1W8tU3VmrR/weAcSMADMj64z+3ViuavG2tFg\r\n DAPgLAQNTVumw8/qWVWmF8TvzwpJVaAIBuEAAG4vmD/2Fl/r+ISLL4yEodAEB3CAADUOYPZO3R\r\n n1mrNyEAAMDoEQAG4PHd/yxNU1mpZbxQ4vkNK7UAAN0hAPTc2qM/k3T9V9bqJbP3xJjQWj0AQD\r\n cIAD2WL2/L03v/zWrNybG/YbUeAKAbBICeKvNH8vDOf7S29C+yufw/O/l71uoBALpDAOihqngi\r\n D774d1KVz63WnR3/XTHexGpNAEA3gq5fAC8r0m/l4Zf/QcriifXa89N/YL0mAKAbBIAe2Xj6f+\r\n TJ3f8idZ1Zrx0mb0o0vWq9LgCgGwSAHqiKJ/Lkuz+V5bO/6OwdFqf/sLPaAAD7nAwAdbUuIp54\r\n /rTT96iKx/L84f+U9cd/Lk1ddPYeQXRK5qdY/gcAlzgZAFbP/1p++OY/SZi8KfH0qsSzqxJPr0\r\n gQnxMRo1u8KWX57C9k/ckvJV27qVtrn46f+yMR4+QfBQBwltOf+kV6T4r0nqw//t8iIuJ5kYTJ\r\n WxJOLkqUXJJw8pYE4WnxwxNy+GBQSZHek3T9pqRrNyXbuGVtpv9+hMmbMjv5+12/BgDAMqcDwK\r\n vqOpds+aVkyy9f+veN8cQPT0oQnRI/PCWeNxHjhWK8aPP/TCTGeFLXmTR1KnWVSlX8IEV6X8r8\r\n oTRN3dF/o72dOP8PRH3VAwDQOwSAfWiaWsr8BynzH7p+lVZNFh/I5Nhvd/0aAIAOMAjIUV4wk1\r\n OX/qTr1wAAdIQA4KhTb/0T8YPjXb8GAKAjBAAHzU7+vkyP/07XrwEA6BABwDFhcl5OvfWPu34N\r\n AEDHCAAOCcITcvbyvxbjJV2/CgCgYwQAR3j+VM5c+Tfih6e6fhUAQA8QABzgeZGcvfwvJYzf7P\r\n pVAAA9wRyAkfP8iZx5959LNL3S9asAAHqEADBiQXRKzlz+V3zzBwC8hgAwUtHkbTl7+V+Ix1l/\r\n AMA2CAAjND3xO3L64j8V40VdvwoAoKcIACPi+YmcvPCPZHbyb3b9KgCAniMAjEQyvy6nL/0Jx/\r\n wAAPtCABg4P5jJ8XN/X+an/7ZwrS8AYL8IAANlvFAWp/+OHD/398R4k65fBwAwMASAgTHGk+mJ\r\n 35MT5/+Y5X4AwKERAAbCDxYyP/0HMj/9h+IHJ7p+HQDAwDkZAML4rATRKSnzx12/yq6MMRJP35\r\n P56T+Q6fHfFTF+168EABgJU2SPm65fohuNpGufyvLZ/5Xl87+Uutzo+oVEZLO3n8w/kOnx35bJ\r\n 4jfFCxZdvxIAYIQcDgAvqiXbuC3p+k1J138l+epraerCSmUvmEk8eUei6WWJp5clnt8QYxjgAw\r\n DQRQDYViX56lsp0m+kSO9Lkd2XqngsVfFEqkOsFHheJH50WoLwlPjRKQnCUxLEZyWavCNBdEbh\r\n /QEA2B0B4MAqqauV1NVSmiqVpimlaSoRqUXEE+NFYrxIPBOJ8UIxXizGi7t+aQAAXkIAAADAQV\r\n 7XLwAAAOwjAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADg\r\n IAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4C\r\n ACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAg\r\n AgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIA\r\n IAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CAC\r\n AAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAg\r\n AAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIA\r\n AAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAA\r\n AADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAA\r\n AA4iAAAA4CACAAAADiIAAADgIAIAAAAOIgAAAOAgAgAAAA4iAAAA4KD/D+vKiDe3wm5jAAAAAE\r\n lFTkSuQmCC\r\nX-SOCIALPROFILE;TYPE=NEXTCLOUD;X-NC-SCOPE=v2-published:http://localhost/ind\r\n ex.php/u/james\r\nCLOUD:james@http://localhost\r\nEND:VCARD\r\n','Database:james.vcf',1795099340,'d28dba003ce5f343e4b747579afa3b28',16394,'james'),
(3,1,'BEGIN:VCARD\r\nVERSION:3.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.6//EN\r\nUID:olivia\r\nFN;X-NC-SCOPE=v2-federated:Olivia Bennett\r\nN;X-NC-SCOPE=v2-federated:Bennett;Olivia;;;\r\nEMAIL;TYPE=OTHER;X-NC-SCOPE=v2-federated:olivia.bennett@example.com\r\nPHOTO;ENCODING=b;TYPE=image/png;0=v2-federated:iVBORw0KGgoAAAANSUhEUgAAAgAA\r\n AAIACAYAAAD0eNT6AAAACXBIWXMAAA7EAAAOxAGVKw4bAAAgAElEQVR4nO3dd3Cd933n+8/pBx\r\n 0HvQMECIK9d1KiRDXLsuOaG9txNuv4bpzE9r1xvMlMNpnNzu4kjtO8u9fJ7mZ915ltcUlcEsfq\r\n thpJFZISxSoSJEiQBIleD04/Z/+gKEsQSIIU8Hueg9/7NYOBpPHM92vgwXM+z+/5Fc/UcDQnAA\r\n BgFa/TDQAAAPMIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgA\r\n AABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAA\r\n AAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAA\r\n AFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAA\r\n BYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAA\r\n WIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAF\r\n iIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABY\r\n iAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWI\r\n gAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiI\r\n AAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiA\r\n AAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgA\r\n AACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAA\r\n AAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAA\r\n AICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAA\r\n CAhQgAAABYiAAAAICFCAAAAFiIAAAAgIUIAAAAWIgAAACAhQgAAABYiAAAAICF/E43gMUlMZlU\r\n fDKh+GRCiamk4hOJd/x7JplRJp1VNp299j2VUTaTVSaVVS6bk9fvldfvlc/vlTfgk+/6P/u9Ch\r\n YGFC4JKVQSUrj0za+Sa18FpSF5fB6n/+8DQN4gAOC2xcbimuif0uRA9Nr3/qm3/j2TyjjSk9fr\r\n UVFVkUrrilVaW/yO74WRAkd6AgA380wNR3NONwH3ik8kNNQzqqFzIxo6N6rh86NKTqecbuu2hI\r\n qCqlwSUXV7haraI6pqr1CwKOB0WwDgKAIA3mFqaFp9R/t19dSghs6NKjoy7XRLC6K0tlhV7RVq\r\n WF2jhjW1ChUFnW4Jt+nJP3lBqXh+hdE74vHI45E8Xo88Hs+17z7Pm6/GfPIFvPIFvPIH/QqE/f\r\n KHr30PhAMKFQcULAoqVBRUqDioUElIHt6U4U28ArBcNp1V/+khXT7ar76j/Rq/Mul0S0ZMvPna\r\n 4tyBXnk8HlV1VKhpbZ0a19Yq0lzmdHuYg5HeMSVjFgSAeeTxeBQuDamgLKyC8rCKIgUqqipUcW\r\n WhiqoKVVJTpHBJyOk2YQgjABbKZnK6fOSqzh3oVd/xAaUTaadbcpXCSIFaNzeqY1cLYcDFvv2F\r\n HxEAFkCwMPDm/JkSlTeWKtJcqkhTmQrKw063hnlGALDI8Pkxnd13QedfuqRENOl0O3mhorlMHb\r\n tbtWR7s0LFvCZwEwKAWeGSkCqXRK7No1kSUXVHpQIFDCLnMwLAIpeKpXT6mfM6u++CNcP7C8Hr\r\n 86pxba2W39+huuXVTrcDEQCc5vF4FGkpU11XleqWV6t2RbX8QZ/TbeE2EAAWqenRuE4+2a0zz/\r\n YoFWeIfz5VLolo9cPL1LKxQWJClWMIAO7i83tVs6xKjWtr1bKxUUWVLL91OwLAIjPeN6njj51R\r\n z4sXlc1knW5nUSutLdaqh5epfWeLvGxCZBwBwN0q2yJq3dyoJdubVRhh/oAbEQAWianBqA5955\r\n h6D/c53Yp1CiMF2vDRlWrf2eJ0K1YhAOQHj8ejuhXVWrq7VS2bGwnLLkIAyHOpWFpHf3RKJ586\r\n q2yaJ34nVbZFtOWTa1W9tMLpVqxAAMg/4ZKQOvcsUde9S1hV4AIEgDyVy0lnnu3RkR+cVHwy4X\r\n Q7eJu2LU3a+POrVFRZ6HQrixoBIH95/V517GzR6vcvU3F1kdPtWIsAkIeGz49p/387pLHLE063\r\n ghvwBXxa+3PLterhZey8tkAIAPnP4/WofUeL1n9kBWd2OIAAkEdymZyO/MMpHf/xG8pm+bXlg6\r\n r2Cu367CaV1hU73cqiQwBYPHwBn5bf36G1P7ecpYQGEQDyxNilCb3wjYMavTjudCu4Tb6ATxs+\r\n tlIr7l/KssF5RABYfIoqCrX1F9epaX2d061YgQDgdjnp2I9P68g/nGSSX56rWVal3f9is4oqGO\r\n qcDwSAxatjZ4u2fnq9/CFGAxYSAcDFktMpPf9fXlHfsX6nW8E8CRWHdPevbVHdCnYTfK8IAItb\r\n SU2x9vz6VkVaOI9joXidbgCzG7s0oR//25/y4b/IJKYSeuov9unEY2ecbgVwtcmBKT32x8/p4u\r\n ErTreyaBEAXOj8S5f06B8+o8nBqNOtYAHksjkd+u4xPf+fX1E6mXG6HcC10om0nvnLF3XyybNO\r\n t7IocZSTyxz+7jEd5+nQCudfuaSxvgnd96WdLIECbuLgt15XNp3Vqoc7nW5lUWEEwCVy2Zz2fe\r\n MgH/6WGbs8ocf+6FlNXJ1yuhXA1Q7/3TGdfKLb6TYWFUYAXCCTyuq5//SSLh256nQrRni9HgUK\r\n AvKH/fL6vPL6PPL6vPL4PMplsspmcsqmr31PxVJKxdPK5RbvXNXoSEyP//Fzuu9LO1XRWu50O4\r\n BrHfz2URVGCtS6pdHpVhYFAoDDUvG0fvofDqj/9JDTrcwLf9CnktpildWXqKS6SIWRgmtfFQUK\r\n l4QULPDLH779yy4VSyk5nVZsPK7p0ZiiIzHFxmKa6J/SeN+kpgajeb05UnwyoSf+5Hnd+8Udql\r\n 1e5XQ7gGvt+8ZBldQUEZbnAcsAHZSYSuqpP9+nkd4xp1u5I8HCgCrbIqpcElFVW0QVrWWO7X+f\r\n y+Q00T+l4QtjGu4Z1VDPqEZ7x5TJs70TfH6v9nx+uxrX1jrdiuuxDNBeJdVFeuQP7lWgIOB0K3\r\n mNAOCQdCKjJ/70eQ33jDrdypx5/V7VdFaqfmWN6lfWqLK13NU722VSWQ2cHtKVEwO6cnxAI3my\r\n i6Iv4NN9X9qp2i5GAm7GRAAoKAtrxy9vWNAac5XN5pTNZJXLXPueffN7JpVRajqtZCz15khZSq\r\n lYWvHJuKZH40pEk063viDatjTprl/b4nQbeY1XAA7IprP66f93IC8+/H0BnxpW16p1c4Oa1tcr\r\n cAfD907xBbyqX1Wj+lU10s9L0eGYLhy8rN6DlzV4bsTp9m4ok8rop//xRT34O7sZ5nSYP+hT47\r\n r83pY2m8pqeiym6dG4poanNX5lUuN9kxq/Mqmpgam8fXV2/pVLatvWpOYN9U63krcYATAsl5Oe\r\n +6uX1Hu4z+lWbqqytVxL727Tku3NefWhP1dTQ9Pqfu68ul+4oNh43Ol2ZhUqDul9v3s3BwndgI\r\n kRgJLqIn34jx9c0BpOymVyGuub0ODZEQ12D2uweySv9h8pLA/rQ3/4wB3NKwIBwLgDf/Oqup8/\r\n 73Qbs/J6PWrd2qRVD3Vas/1mLpvTxVev6PijpzXkwhGZwkiB3ve7e1RUyT4BMxEAFkZ8IqHLR/\r\n t18dUrunJiQOlE2umWbmrNB7q0/iMrnW4jLxEADDr6j2/otR+ccLqNd/H5vercs0QrH+q0+oPm\r\n 6slBHf2nN3T15KDTrbxDpKlMD//eHvk4JvUdCAALL5vK6sqJAZ3d36uLh/tc+brAH/Tpw195UA\r\n XlYadbyTuMmxjSd7RfR3540uk23qV9R7PWf3QVJ9RJqltRrboV1eo71q/D3z2m0UsTTrckSRq9\r\n NK793zysuz7HhCeY5Q141biuTo3r6hSfSOjMc+d15tkeRUdiTrf2lnQyo+OPntHmT65xupW8Qw\r\n AwYGpwWs//9UFXbWZTvbRS2z69TpFmO4b6b0fD6lo1rKrVmefO6/DfHVNy2vmlZudfvqTKtnKt\r\n fIitUOGMcGlIaz7QpVUPL9OZZ3r0+j+eUnwy4XRbkqQzz5/Xug8vZ1ngbWIr4AWWSWb0zNdfVH\r\n LaHUtxAuGAtn16vd73u3fz4X8zHqlzT5s+9IcPqGWTO3YdO/x3x3X1hLteT8A+Xp9HXfe16yNf\r\n fUjrfm6FvH7nP0bSibROP3Pe6TbyjvO/uUXuwN+8qtFL7lh/XtdVrQ/94f1adu8Sp1vJG+HSkP\r\n b8xlbd/WtbFXT46SKXzem5//Kyq4ZfYS9/yKe1H1qu9//ePSqrL3G6HXW/cMHpFvIOAWABndvf\r\n q56XLjrdhjxej9Z/eKUe+O3dTJS5Q61bGvXIH+xVZVvE0T4SU0nt//8POdoD8HaRljI98gd7tX\r\n R3q6N9TFyd1NBZ9+7v4UYEgAUSG4vrlb993ek2FCoK6oEv79aaD3a5ete+fFBcXaj3/as9jt/o\r\n rp4a1KmnOB8d7uELeLXjMxu1+v3LHO2j56VLjtbPNwSABXLgbw47PnmsrL5ED//+PRwuM4+8Po\r\n 92fGajNnxslaN9HP674xwhDNfZ8LFV2vjx1Y7Vv/jaFcdq5yMCwALofv6CLh/td7SHms5KPfx7\r\n e1RSU+RoH4vV6vcv012f2yKv15lhlUwqo33fOKicC9dlw26rHu5U1952R2pHh6c15pLlu/mAAD\r\n DPoiMxHfzWUUd7qF9Ro/t/axdLYhZY29Ym3fXrW+X1OfNnNNQzqmM/Pu1IbeBmtnxirWqWOTPy\r\n eOXEgCN18xEBYJ4d/NvXlYo7N/TfuLZOe39zB7vGGdKysUF7Pr/NsZGAoz96Q1ND047UBm7E4/\r\n Noz69vVbAwaLx2/+lh4zXzFQFgHvW/MeToIT81Syu15ze2uWJdrk2a1tVpx2c2OlI7k8ro0Led\r\n HXECZhMuDWn9R1YYrztwhgAwV3xSzJecHJ31H2kqvfbkH+BX6oT2nS2OTQzsPdzHBkFwpWX3ti\r\n vSVGq0ZmIqoegwe2XMBZ8W8+TM8+c1etGZDX/CJSHt/U3e+Ttt9fuXqWOXM0sEX/7b15kQCNfx\r\n eKQNHzO/KmDMJZuvuR0BYB6k4mkd+b4zp/x5fV7t+fw2FUbY4McNtv/SelW0lBuvO943oTd+cs\r\n 54XeBWGtfUqriq0GhNtxzk5XYEgHlw/NHTik04cyjG5k+sUU1npSO18W7ewLVA5sTkpyM/PKVU\r\n 3N1nt8NCHmnZHrPbj0/0s0fGXBAA3qNULK1TTznz5NW8ocGx9ba4seKqQm3/Z+uN101OJ9khEK\r\n 7UsbtVHo+5lTLRYVbGzAUB4D069fRZR5b9FZaHteMzG4zXxdy0bmlU29Ym43VPPtGtdCJjvC5w\r\n M+HSkCIt5k4fJQDMDQHgPUgnMzr5pDNPXDs/u0mhIvPDzJi7bb+0XgVlZudmJKJJvfE0owBwn4\r\n aVNcZqTY/FjdXKZwSA9+DMMz1KTJl/99+xq1X1Bv+YcGeChQFt+eRa43WPP96tdJJRALhL/Spz\r\n 96xMKqNMKmusXr4iANyhbDqrE4+fMV43XBLS5l9YY7wu7kzrlkY1rK41WjMxldAbT7MiAO5S0W\r\n p2dUwymjRaLx8RAO7Q+ZcvOTLMtPkTaxQsYr1/Ptn26XXyGd6d8dTTZ9kXAK4SLAwoVBwyVs/p\r\n 01jzAQHgDp1+psd4zar2Ci3Z3my8Lt6b4uoidd3XYbTm9GhMF1/laFS4S2ldsbFamTSvAG6FAH\r\n AHxi5PaPDsiPG6Wz7B0H++WvOBLuOTNtkYCG5TWmvuePIsAeCWCAB3wImn/7YtTarqqDBeF/Mj\r\n WBjQ6ke6jNa8empQ41cmjdYEbsbkBlnZDAHgVggAtymTzKjnwEWjNT0ej9Z92PypWphfXXvbFS\r\n 4x9w5Ukk7/1HxYBW7EH/Ibq+XUEd35hABwm86/fEnJmNnJJW3bmoy+O8PC8AW8WvlQp9GaZ/f1\r\n sjEQXCMQNhcAfEGfsVr5igBwm7r39Rqt5/F4tPaDy43WxMLp2tuuULG5YdBUPKXeQ5eN1QNuxh\r\n 8y96HsCxAAboUAcBtiY3ENnhk2WrN5Qz1P/4uIP+QzfjBKz0uXjNYDbiSbMbc0lRGAWyMA3IYL\r\n By8rlzO7tnrFg0uN1sPC69rbbvT95NUTA0pMsikKnJdJmXsdFSww97ohXxEAbsOFg2aHUivbIh\r\n z1uwgVlIfVsrnRWL1sNqcLvAaAC5iaj+IP+RUoYMO0WyEAzFFsLK4Bw8P/y+/jqN/Fqutes79b\r\n XgPADTLJtJE6hZECI3XyHQFgjkw//QfCAbUafEqEWTXLKlVSbW5TlIHTQ5oejRmrB8wmNm7m8L\r\n SiCgLAXBAA5qj3cJ/Reku2NzGJZZHr2N1qtN6Fg2avYWCm6PC0kTpFlYVG6uQ7AsAcpBMZDXab\r\n 3fp36V1tRuvBvI5dLUbr9R29arQeMNOUoQAQaSo1UiffEQDm4OqpQaPbSpbUFKuyzezRmTCvMF\r\n Kg6qXmJnn2nx7mjHQ4JpvOKmboBFXTRw/nKwLAHFw5PmC0XttW3v3bwuQ8j0wqo/5Tg8bqAW83\r\n cmHMyDJqj8ejihYCwFwQAOag71i/0XptW5uM1oNzTE/0vHzU7LUMXDd4zsxr1NK6YqM7DuYzAs\r\n AtREdimuifMlavtLZY5Y28v7JFYSSsyiURY/VMh1nguqFzo0bqNKyqNVJnMSAA3ILp4f/GtXVG\r\n 68F5jWvM3bAm+qc0NWhmIhbwlpx09aSZ108NawkAc0UAuIWBM0NG6zWtIwDYpnGN2d95/2mz1z\r\n TQf3pI8cmF3wPAF/CpblnVgtdZLAgAt2Bq2Eq6dlRmDRevdaqWRBQqDhmrN3jW7JJWwNRGag2r\r\n a+QN8LE2V/ykbiIVS2v8yqSxerXLquT1mTskBi7hkeqWmwt+Q2fNbmkNu2UzOfUaCgBLDW+ule\r\n 8IADcx1GP2SanW4IcA3KXW4MjP2OVJpeJm9mQHeg70Kjax8MP/BWVh5lDdJgLATZgc/pek2q5q\r\n o/XgHjXLzG0IlMvlNGz42oa9jj/ebaROx84WeQwes70YEABuYsjQulXp2uE/7F5lr0hTmYKFQW\r\n P1mAcAEy4cvKzxvokFr+P1e7VsL6en3i4CwE0M95h7Sqpqj8hDeLWXR0a3fza1KQvslU5kdPBb\r\n R43UWrqrlRMA7wAB4AYSU0kj762uqzK4GQzcyeQ1MHZp3Fgt2OnID08aOYLa6/dq9Qe6FrzOYk\r\n QAuIHxPnOz/yUZ3Q0O7lTZZu4aiI7EmAiIBdP/xpBOPWnm3X/n3W08/d8hAsANmFz+JzECAPMh\r\n 0HTIhR2mR+N67j+9rGx24Q/+KSgLa8NHVy54ncWKAHADJm+OoeKgCsrDxurBnQojYQULA8bqmZ\r\n icBbukExk98/UXjez6J0mbP7FGgQJzfzOLDQHgBsavmLs5cvgPritvMHctjF0mAGD+pOJpPfUX\r\n +zR83tChP6trOTn1PSIA3IDJVwAEAFxXZvBaGOMVAOZJcjqlp/7sBQ12m9llsqAsrF2f3WSk1m\r\n Lmd7oBN0onM4qOLPzs1esIALiuvKHEWC3mAGA+jF2a0DNff1GTg1Ej9bxej+7+9a0Kl5o7P2Ox\r\n IgDMIjpk9rjUsjpzN324W2ltsbFa06Mx5TI5eTh/Ancgl83pxOPdOvKDE8qks8bqbvj4KtV0mt\r\n s5czEjAMzCxNrVtyuuKTJaD+5VXG3uWsjlcpoei6uokiVUuD19R/t18DvHjE8kXX5fh1Y+1Gm0\r\n 5mJGAJiFyeF/r9+rogg3YFxTXF0kj8ejXG7hl1BJUnRkmgCAOcllc7r46hUde/S00V1Sr1uyvV\r\n lbPrXWeN3FjAAwC5MjAMVVRRIjsHiT1+dRQXnY2DU4bTDsIj+N903q3IsXdW5/r/HR0euaNzQw\r\n 6W8BEABmYTQA8PSFGYqrCo1dg9Fhs/Nd4H6ZZEYD3cO6cnxAF1+9oon+KUf76dyzRNt+aT1npS\r\n wAAsAsTL4CKGT4HzMUlJnbFMrktQ73yWZymrgyqdFL4xrqGdXwuVENXxhTNmNuUt/NbPjoKq1+\r\n ZJnTbSxaBIBZmBwBYAdAzGTymiAALF7ZdFbJ6ZTikwnFJxKKjcc1PRJTdDSmyYGoJgeiig5FjW\r\n zZe7uChQHt+Ocb1bKpwelWFjUCwCziBk8BLCxnBADvZPKaiE3EjdXKR9NjcT3+leecbmNWOV2b\r\n mJfL5ZRNZ5VJZZVJZZROZJSKp5Q1uDRvPtV0Vmr3r27hgB8DCACzSMZSxmqZHO5FfigoM7fBST\r\n Jq7lrPR5nUtffhWHi+gE9rHunS6g908b7fEALADJlkxmhyDpUEjdVCfggVmbsmktNJY7WAG2ne\r\n UK/Nn1ir4qpCp1uxCgFghuS02Scikzd75IdgsckAwAgAnFPRUq6NH1+l+lU1TrdiJQLADMYDgM\r\n GbPfKDyVCYy+aUiqcVCHMrgDk1nZVa80iXGtbUOt2K1firnyERNTskGmQEADMEC82eb56MpggA\r\n WHD+oE/NGxvUdW+7qpdWON0ORAB4l5TBEQBfwCcvB7FghmCB4QAwnWQ7YCyYmqWVat/VoratTQ\r\n RNl+G3MUMqnjZWyx/0GauF/OENeI2eB8A8AMynQDig+lU1alpbq8a1dRzb62IEgBkyKXMrAPwh\r\n AgBm5wv6lE6YCaOZVMZIHSxORZWFqm6vUFV7RFUdFapqi3DEdJ4gAMxgcgtMX5AfP2bnNxgAsm\r\n n37QSH/HDvF7eraX29023gDnmdbsBtTAYAXgHgRkyODrll33fkn8HuEY30jiubIUTmIx5BZzB5\r\n M/T6yV+Ynddn7trI1y1j4bxjj57WsUdPy+v3qryhVBWt5apsLb/2fUmEHf1cjgAwg8nhUI+Xvw\r\n 7MzuS1wQgA3qtsOquR3jGN9I6p+/lr/y1YGFDd8mo1rK5Vw+paVpq4EAFgBpM3QwIAbsRsAGD4\r\n FvMvOZ1S7+E+9R7ukySV1harcU2dlmxvUuWSiMPdQSIAvIvRVwAEANyA0QDAKwAYMNE/pYn+bp\r\n 18qltl9SVq39Gi9p3NKowwMuAUAsBMBh+GPLwgww3wCgCL2fiVSb36veN67fsnVLu8Sp13t6l1\r\n SxNzBgwjAMxgcvJVLsvQK2Zn8tpgMiqcksvldPXkoK6eHNRr3zuhle/r1NJdrfIGuCZN4Kc8g8\r\n mtebOGdnpD/skZfC9vMvQCNzI5GNVL/+M1/f1vP6Zj/3RaqRg7VC40/vJn8DACABcwtQ2wZDb0\r\n ArcSn0zo1e8d1/d++3GdeOwMc1QWEAFgBp/B4dAc715xAyZn5jMCADdKxlI69N1j+offf0qXj1\r\n x1up1Fib/8GUzuYc3yK9wIG1IB10wORvWT/3hAL/zXg8aPa1/smAQ4g8mnIVN7vSP/ZJLmDugh\r\n ANyYL+BTZWu5023cUE7XXiVe/8qkMte+khml4mmlDV5HC63nxYu6enJQd31ui2q7qpxuZ1EgAM\r\n xg8n3oYvrjxPwyGQ6ZA3BjheVhPfS7dzvdxh3LZXNKTqeUnE4pNh5XfDKh2Fhc0ZGYosPTmhqa\r\n 1sTVybw5Ejo2HteTf/aC1n9kpVa/f5nT7eQ9AsAM/pC5H0k6QQDA7EyGQ1+AQ6kWK4/Xo1BxUK\r\n HioEpqim74v4tPJjR2eUKjveMa6R3TYPeIJgejBjudu1w2p1f//rjG+ya04zObCLDvAQFghmBh\r\n wFitTJJXAHi3TMrs5NBQUdBoPbhPuCSkuuXVqlte/dZ/i08mNHB6WH3H+tV3bEDRkWkHO3y3cw\r\n cuano0rnu/uF3+MB9ld4Kf2gxGA0A6q2wqy6YXeAfT65+DReaueeSPcElILZsa1LKpQZI0cmFM\r\n Fw71qefFi4oOuyMMXD01qKe/tl/3/dYuo0doLxZ88swQLDT7NJSYZlYr3ikxZfaaMH3NIz9VtJ\r\n Zrw0dX6qNffUgPfHm3mjfUu2I784HuYT39tX3GR84WAwLADCZHACQpGc2PyTcwx+RSJ6/Xw5MT\r\n bo9HqltZrXu+sF0f+qMH1LGrxfGTTQfODOuFv37F6FkuiwEBYAbTAYB1rZjJ5IzsIO//8R6U1B\r\n Rp569s0s/9u/tVv7LG0V56D/fp0HePOdpDviEAzOSRAmFzIcD0cC/cz+Q1YTrwYnEqrSvW/V/e\r\n pbs+t8XRV0onHj+jCwcvO1Y/3xAAZhEqNndTjI3FjdVCfoiNm7smGAHAfGrb2qQP/tv7VLO00r\r\n EeDnzzVU25dAmj2xAAZlFQFjZWa3osZqwW8oPJUFhQFjJWC3YojIT1wO/cpY6dLY7UT8VTeuG/\r\n HmQ+wBwQAGZRGCkwVosRAMw0bfCaKKooNFYL9vD6PNr52U3qvLvNkfqDZ0d06umzjtTOJwSAWR\r\n RWmAsA06OMAOCdTL4CKDJ4rcM+2395gzr3LHGk9qvfO8H99RYIALMoMjgCMDXMBYp3ig6Ze39p\r\n MuzCTtv/2Xot2dZsvG46kdZr3z9pvG4+IQDMwuQrgKmhKO+q8JZsKmv2FUAlrwCw8HZ8ZqMjpy\r\n qe29+r8b5J43XzBQFgFiafirLpLBMB8ZZJg0//Eq8AYIYv4NU9X9yucInZSae5XE6v/8MpozXz\r\n CQFgFqZvipMDLFnBNVOD5vZY9yI0/5EAABalSURBVHg9KignAMCMwkiBdv7KJuN1Lxy6rOgID1\r\n mzIQDMorC8wOgRqRNXp4zVgrtN9JsbriyqKJQLtnKHRRrX1qpta5PRmrlsTm+wImBWBIDZeKTS\r\n 2mJj5cb6JozVgruNXTYXAMobSozVAq7b8qm1xo+gPruvVznmWr0LAeAGyurN3RzHLhMAcM24wT\r\n BY1lhqrBZwXbgkpNWPdBmtGZ9M6OqJAaM18wEB4AZMBoBxAgDeZHLGMiMAcErXvUuMTwjseemS\r\n 0Xr5gABwA2UGb46xiYTiEwlj9eBO0eGYkjFzJwGWNTACAGf4gj6tfKjTaM3Lr181Wi8fEABuwO\r\n QIgCQNnx8zWg/uM3x+1Gg9kyEXmGnZvUuMTraOTyY0enHcWL18QAC4gdLaYnkMTpEe6hkxVgvu\r\n NNxjLgAUVxXKHzR38wVmCoT9al5fb7TmlePMA3g7AsANeANeldaZWwlg8uYPdzI5ChRpKjNWC7\r\n iRJTvMbhHcf3rYaD23IwDcRFV7xFitoXMEAKvlzL4CqO6oMFYLuJHG1bUKFgaM1Rvp5VXr2xEA\r\n bqJqibmbZCKaZDmgxUYvjhudAFhFAIALeHwe1XRWGqs3PRpTfJIJ19cRAG6icom5EQBJ6n9jyG\r\n g9uEf/aXO/e6/XY/zaBm6ktqvKaD0mAv4MAeAmKprLjM5SvXqKAGArk+GvvLmMCYBwjdplZgMA\r\n Z6/8DAHgJjw+jyqazU2W6j81yNHANsqZHQHg/T/cJNJSbnTF1dQgAeA6AsAtVLWbnQcwdI7lgL\r\n YZ6hlVYipprB4BAG7i9XlUGDF3KiUjAD9DALgF0++nLr3eb7QenHf5qNkdykxf08CtlNQUGasV\r\n G4sbq+V2BIBbqFtRLY/X3PCU6Q8DOO/yUXOhr7yh1OjTFjAXJgNA3OBom9sRAG4hUOBXVZu5Gd\r\n MjF8YUHZ42Vg/Omh6NG90EqmFNrbFawFwFDR4PbPJ1m9sRAOagflWN0XoXXrlstB6c03vI7O+6\r\n cTUBAO4TCPmN1UpOJ5VjsrUkAsCcmA4A5w8SAGxhMuz5Q37VLDO36QowV/6Q2WWpmVTGaD23Ig\r\n DMQXV7hfwGE+pwzyhLVSwQG4tr8Ky5VR91y6vk9fMnD/cxeX+VpGw6a7SeW3E3mAOPz6P6FdVG\r\n a3a/0Gu0Hsw7u79XOYNjkY1r6ozVAm6H6Q9kAsA1BIA5atnUYLTeuf0X2BRokTv7wgVjtTxej/\r\n FrGJirdNLskHw2QwCQCABz1ryhwejwaXQkpr4TnF29WA2eHdFE/5SxenVd1QqXhozVA25HOpk2\r\n Ws/kzoNuRgCYo0CBX/UrzU4GPP2Tc0brwZzTP+0xWq9tW5PResDtyBgeAfD6+OiTCAC3pXVzo9\r\n F6l45cZTLgIhSfTOjCK5eM1fP6vQz/w9Vi42Z352My7DX8FG5D84Z6o8kxl8vp5FNnjdWDGaef\r\n 6VHG4CSkxtW1ChYGjNUDbtfUcMxoPU7DvIYAcBuChQHVrzS7GuDsCxeUnE4ZrYmFk01nGf4HZo\r\n gOmRvp9If88viYAyARAG5bx65Wo/VS8bROPtFttCYWzpnnzhsd7gwVBdWygeF/uFcum9O0wQN6\r\n QkWMhl1HALhNLRsbFC4xO5v61FNnlYqZnSWL+ZfL5HT80TNGay69q1XeAH/mcK+xyxPKZc2teT\r\n Z57oDbcWe4TR6fRx27WozWTMZSjAIsAmf39yo6Yvagp2X3LDFaD7hdJnfDlKQiTsN8CwHgDnTu\r\n MX9TPf74GcUnEsbrYn5kUlkd+eFJozUb19SquNrcMavAnRg6ZzgAVBYaredmBIA7UFJTpLous5\r\n MB04m0Xvv+CaM1MX9OPH5G06NmZzp37e0wWg+4E4PdhgNABSMA1xEA7lDnPW3Ga3a/cEFjlyeM\r\n 18V7E59MGH/3X1xVqMY1HP0Ld5sciBrdEVOSSutKjNZzMwLAHWrd1KiiCrNDSblsTi/999eM1s\r\n R7d/g7x5SKm13KufKhTomVTnC5XgeOPi9rIABcRwC4Qx6fR6ve12m87kD3sLqfN3eIDN6bgdPD\r\n Orvf7MmOheVhdd7VZrQmcCcuHOozWs/n96qktthoTTcjALwHS+9uM74kUJIOf/cYEwLzQDaT00\r\n v/w/yIzaqHl7H0D6432T+l4fOjRmtGWsrFOUA/w13iPfAFvFrxwFLjdRPRpA78zavG6+L2HPnB\r\n CY31mZ2zUVAWdmSVCnC7Tj5pfpvz6vYK4zXdjADwHnXtbVewwPzOUpeOXNGZ584br4u5GTo3qu\r\n OPmZ34J0mrHu6Uj6d/uFxyOmX81ZgkVS8lALwdd4r3KFDgV9d97Y7UPvito5q4anYGLW4tHU9r\r\n 3zcOGt3dTJIKSkNaxtM/8sDpZ3qUTpjf3bS2q8p4TTcjAMyDVQ8vc2QuQDqR1jN/+ZLSCbNnae\r\n Pm9n/zsPGlTZK0/qOr5OOUM7hcYiqp4z8+bbxuRUu5wqXm79NuRgCYB4GwX+s+vMKR2uN9Ezrw\r\n zcOO1Ma7nXyyWxccWNpU2VqupbvNHlQF3InXvndCyZj5E04b2BfjXQgA86RzzxKVN5Y6Uvv8K5\r\n d09B/fcKQ2fubKiQEd/s4xR2pv+cV1rPuH641dmtCZ5887UrtlI6dizkQAmCcej7T5F9Y4Vv+1\r\n H5xgfwAHjV4c17N/+ZKyht/7S1L7jmZVdzC5Ce6WTWf1ggNzYySppLpIlW3lxuu6HQFgHtWvqn\r\n F0+9WX/vurunTkqmP1bRUdntbTX9uvVNz8pCZ/yK+NH19tvC5wuw5955hGL447UrttW5Mjdd2O\r\n ADDPtnxqnXwBZyZiZbM5PftXL+nSa1ccqW+jqaFpPf7V5xUbjztSf/1HVqigPOxIbWCuLh25ql\r\n NPm1/3f93S3W2O1XYzAsA8K6kp0oaPrXKsfjad1bN/9bJ6DW+xaaOpwaie+Opzig5PO1K/tqvK\r\n kY2ogNsx0juuF/76FcfqN6yuVXE1RwDPhgCwAFbc36GazkrH6mczWT33n1/WGz8551gPi93w+T\r\n E99pXnFB0xe8TvdYGwXzt/ZZMjtYG5mhqc1k++ts+R12PXLd/rzD4t+YAAsBA80s5f2SS/g2uy\r\n c9mcXv5fR3Twb49K5ufcLGqXXruiJ776nGPD/pK0+RNrVVzFUw3cKzYW11N/sU8xB88tiTSVqn\r\n FdnWP13Y4AsECcfhVw3cmnuvX0v9+vxGTS6VbyX046+o9v6Jmvv6R00rnNlxrX1mnpXaz5h3tN\r\n DkT12Fee1eSAszuVrn6ky9H6bkcAWEDL7+9Qw6oap9tQ37F+/ejfPK3+N4acbiVvxScSeurP9+\r\n m1H5xQLufckEpBWVg7P7PRsfrArfQd69eP/90zmhpyZm7MdZGmMrVtYfb/zRAAFtjuz21RUaXz\r\n Q7XTY3E9+acv6PB3jymTyjrdTl7pPdSnH/3B07pycsDRPrw+r/b8xja2M4UrZVNZHfrOMf3k3x\r\n 9Qctr5EcdN/9dqNse6Bb/TDSx2oaKg7vnCdj32R88qk3J2z/5cLqfjj51R76E+7fjnG1W7nIMx\r\n biY2HtfL//OIeg+7Y0XFlk+t5TQzuFLf8QG98r9f18TVSadbkSQ1rqlVvQtGX92OAGBARUuZtn\r\n 16vfZ/85DTrUiSJgejeuJPn1fbliZt+PgqJpPNkE1ldfLJbh39p9NKxc3vWT6bpbtbteweTvqD\r\n uwz3jOrID0/q8tF+p1t5iz/o09ZPr3e6jbxAADCkY3eLhs6N6PSzPU638pbzr1xS76t9Wr63Xa\r\n vf36VQSdDplhyVy0k9B3r12vdPKjri7PvLt6tcEtG2X+KGBpfISZdfv6qTT53VlRPOvhabzboP\r\n r+ShZo4IAAZt/cV1mhqKqu+4e/5osumsTjzRrTd+2qPOu9u08qFOFVUWON2WUdlUVt37Luj4o2\r\n c0NRR1up13KKku0r1f3C6vn+k6cNZ436R6Xryocwcuuiogv13tsiqteJDNseaKAGCQx+fRni9s\r\n 15N/8ryGekadbucdMqmMTj19Vqd/ek7NGxu0bM8S1a2sdrqtBTU1OK0zz59X93PnFZ90bq3yjR\r\n SUhXX/l3epoIytfmFeOpnRwJlhXTk+oEuvXdFEv7NL+m4lVBTU7l/dIg8T/+aMAGCYP+jT3i/t\r\n 1ONfeU7jV9wxYebtstmcLhy8rAsHL6ukukgdu1vVurlRpXXFTrc2L1KxlC6+ekXnDlx05fDldc\r\n HCgO7/8i4VVxc53QoskM3kNHF1UqMXxzXUM6rhc6MavjCmbCY/Vgx5PB7t+uwmFUYIy7eDAOCA\r\n UFFQ9395lx77o2cd20p2LiYHo3rt+yf02vdPKNJUqpbNjWpcU6fK1vK8Wl4THYnpyvEBXTzcp7\r\n 4TA8qm3X1T8wd92vubO1XeWOp0K1gEsumsktMpJaaSik8mFBuLa3ospuhwTJODUU0ORDU1MOXI\r\n UdbzZcNHV7Lj3x3wTA1H8/e3nucmrk7piT9x7iS5OxUsDKp+ZbVqu6pU1V6hSHOZvD73JIKpwa\r\n iGzo1qoPva8KXbhy7fzhfw6Z4vbnfFBlJu9+0v/EjJ2MKu0vD6vSqrL1nQGvMll8299ZVOZpRJ\r\n Zq59d3j58UJr39GiXf8352LcCQKAw6YGo3ryz/a5bvLZ7fD5vYq0lCvSVKqy+hKV1ZeotL5ERR\r\n UF8ngXLhjEJxKa6J/S+JVJTVyZ1FjfpIbPjyox5fwmJHciEA5o7/+7QzXLnDtIKp+YCABwt6Z1\r\n dbrnC9sX9D6zmBEAXCA2FtdTf75PY30TTrcyrzwej8KlIRVWFKgoUqBQcVDBwoACBQEFCwPyB3\r\n 3y+Lzy+b3y+DzyyKNsJvvmV06ZVEapWFrJ6aSS0yklp1OaHotreiSm2FhMGZcP5d+OcElI9//W\r\n LkVaypxuJW8QAOxW11Wt+760U94AK2TuFAHAJZLRlJ7+2j7XrQ7AwiuqKNQD/3KXSmoXx0RLUw\r\n gA9mpYVaN7vrBdPgdPXF0MiE4uESwK6IHfvot3v5YpbyjV+/7V3Xz4A3PUvKFB9/4/O/jwnwcE\r\n ABfxh3za+6VdWvW+TqdbgQEtmxr18O/fo8KIXRsvAXdqxf1Ldc/nt7Ex1jxhGaDLeDzSxp9frc\r\n q2iPb/t0OOnjuPheHxeLT+Iyu1+pFlTrcC5AWvz6stn1rLeRjzjADgUq1bGlVWX6Jnvv6iJgfz\r\n d4UA3ilYGNRdn9ushtW1TrcC5IXS2mLt/tUtqmwrd7qVRYcA4GLlTaV6/7++Vwe+edg1R9Lizl\r\n Utieiuz21hdz9gjpbubtWWT62TP8T7/oVAAHC5YGFAez6/TecOXNQr//uIktPMes43Xp9Xaz+4\r\n XKsfWcZ6ZWAOgoVBbf/l9Wrd3Oh0K4saASBPtO9oVv2Kau3/5mH1HXPP2du4ufLGUu3+F5sVaW\r\n Z9PzAXzRsatPUX1zI51gACQB4pKA/rvi/t1Jlnz+vQd44qFU873RJuwOP1aOVDnVr/4RXMWAbm\r\n INJcpi2fXKvariqnW7EGASAPde5pU/OGer3698d1dl+vcjn2cnKT+hU12vzJNRzmA8xBQWlI6z\r\n 6yUp13teXVIWOLAQEgT4VLQ9rxmY1afl+HXvnW6+p/Y8jplqxXUl2kTb+wRs0b6p1uBXC9UHFQ\r\n XXvbteqhTvnDfBQ5gZ96nou0lOnB37lLvYf6dPi7x1gy6IBAOKA1H+jSigeXuupURMCNSmuLte\r\n LBperY1Sof+/g7igCwSLRsalDz+nr1vHRRxx89s+gOFnKjUHFQy+/r0PL7OhQsCjjdDuBqtV1V\r\n Wvlgp5rW1zndCt5EAFhEPD6P2ne2qH1niy4duarjPz6tge5hp9tadIoqCrTiwU4t29PGfuTATZ\r\n TWlahta6PatjaprL7E6XYwAwFgkWpaV6emdXUaPDuiE4+d0aUjV5XNLJ7jc51Q0VKu5fd3qH17\r\n szwM9QOzKqkuUuvWJrVtaWT5q8sRABa56o4K7fn8NiWmkjr/0iV177ugkQtjTreVN0LFIbVvb1\r\n bH7hZuZsAsgoUB1XRWqrarWvUrqhVp4e8kXxAALBEqDqrrvnZ13deuscsTOre/V+cOXFRsPO50\r\n a67j9XnVsLpWS3e3qmldHU/7wNuES0Kq7qhQ7fIq1XZVq6K5jOV7ecozNRxlEbnFhs+P6fLRq7\r\n r8er+Ge0at3VMgXBJS49paNa6tU8OqWgUKyMZu9+0v/EjJGFtjL5RwSUjljaUqayi59r3+2vdQ\r\n cdDp1jBPuMtZrrKtXJVt5Vr7weVKRJPqO9qvy0f71f/GkKZHY063t2C8Pq8qWsrUsKZWTWvrVL\r\n kk4nRLwLzyeD3y+b3y+n3yBbxvfvnk9V/7HizwK1waVkF5WAVlIRWUhlVQFla4LKTC8gJCsAUY\r\n AcANxcbiGjo3qqFzIxrqGdXw+dG83X64qKJQVe0RVXdUqKqjQpUt5fKyBhmAxQgAmLucNH5lUm\r\n N9E5rsj2qif0qT/VOa6J9SfDLhdHeSrn3Ql9YVq7S2+Nr3umJFmstUUBZ2ujUAcBUCAOZFKp7W\r\n ZP+Upkdjik8mFZ9MKD6RUHwyocSb/5yYTimbyiiTziqbziqTziqXnf3y83g8bw5Veq8NYwZ8Ch\r\n UGFC4NXfsqCSlcGn7ze0hFlQUqrSnmqR4A5ogAAGfl9GYgyCiX07UPfb9XHi/TigFgITHLA87y\r\n 6K0JSgAAc7jrAgBgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAG\r\n AhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABg\r\n IQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYC\r\n ECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAh\r\n AgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQ\r\n IAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCEC\r\n AAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAg\r\n AAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIA\r\n AAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAA\r\n AAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAA\r\n ABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAA\r\n AWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAA\r\n FiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAAB\r\n YiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAW\r\n IgAAAGAhAgAAABYiAAAAYCECAAAAFiIAAABgIQIAAAAWIgAAAGAhAgAAABYiAAAAYKH/AwnE/J\r\n td0uFEAAAAAElFTkSuQmCC\r\nX-SOCIALPROFILE;TYPE=NEXTCLOUD;X-NC-SCOPE=v2-published:http://localhost/ind\r\n ex.php/u/olivia\r\nCLOUD:olivia@http://localhost\r\nEND:VCARD\r\n','Database:olivia.vcf',1795099341,'21bded73899d56f87b6c00b4ddc59d4f',19957,'olivia');
/*!40000 ALTER TABLE `oc_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_cards_properties`
--

DROP TABLE IF EXISTS `oc_cards_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_cards_properties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `addressbookid` bigint(20) NOT NULL DEFAULT 0,
  `cardid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `name` varchar(64) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `preferred` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `card_contactid_index` (`cardid`),
  KEY `card_name_index` (`name`),
  KEY `card_value_index` (`value`),
  KEY `cards_prop_abid_name_value` (`addressbookid`,`name`,`value`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_cards_properties`
--

LOCK TABLES `oc_cards_properties` WRITE;
/*!40000 ALTER TABLE `oc_cards_properties` DISABLE KEYS */;
INSERT INTO `oc_cards_properties` VALUES
(16,1,1,'UID','emily',0),
(17,1,1,'FN','Emily Carter',0),
(18,1,1,'N','Carter;Emily;;;',0),
(19,1,1,'EMAIL','emily.carter@example.com',0),
(20,1,1,'X-SOCIALPROFILE','http://localhost/index.php/u/emily',0),
(21,1,1,'CLOUD','emily@http://localhost',0),
(37,1,2,'UID','james',0),
(38,1,2,'FN','James Walker',0),
(39,1,2,'N','Walker;James;;;',0),
(40,1,2,'EMAIL','james.walker@example.com',0),
(41,1,2,'X-SOCIALPROFILE','http://localhost/index.php/u/james',0),
(42,1,2,'CLOUD','james@http://localhost',0),
(58,1,3,'UID','olivia',0),
(59,1,3,'FN','Olivia Bennett',0),
(60,1,3,'N','Bennett;Olivia;;;',0),
(61,1,3,'EMAIL','olivia.bennett@example.com',0),
(62,1,3,'X-SOCIALPROFILE','http://localhost/index.php/u/olivia',0),
(63,1,3,'CLOUD','olivia@http://localhost',0);
/*!40000 ALTER TABLE `oc_cards_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_circle`
--

DROP TABLE IF EXISTS `oc_circles_circle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_circle` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `unique_id` varchar(31) NOT NULL,
  `name` varchar(127) NOT NULL,
  `display_name` varchar(255) DEFAULT '',
  `sanitized_name` varchar(127) DEFAULT '',
  `instance` varchar(255) DEFAULT '',
  `config` int(10) unsigned DEFAULT NULL,
  `source` int(10) unsigned DEFAULT NULL,
  `settings` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `creation` datetime DEFAULT NULL,
  `contact_addressbook` int(10) unsigned DEFAULT NULL,
  `contact_groupname` varchar(127) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8195F548E3C68343` (`unique_id`),
  KEY `IDX_8195F548D48A2F7C` (`config`),
  KEY `IDX_8195F5484230B1DE` (`instance`),
  KEY `IDX_8195F5485F8A7F73` (`source`),
  KEY `IDX_8195F548C317B362` (`sanitized_name`),
  KEY `dname` (`display_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_circle`
--

LOCK TABLES `oc_circles_circle` WRITE;
/*!40000 ALTER TABLE `oc_circles_circle` DISABLE KEYS */;
INSERT INTO `oc_circles_circle` VALUES
(1,'91Srey6Chgdpp3HOrex4oxgog5QDMZY','user:ncadmin:91Srey6Chgdpp3HOrex4oxgog5QDMZY','ncadmin','','',1,1,'[]','','2026-11-19 14:42:02',0,''),
(2,'yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','app:circles:yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','Circles','','',8193,10001,'[]','','2026-11-19 14:42:02',0,''),
(3,'CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','group:Marketing Team','Marketing Team','','',1540,2,'{\"population\":3,\"populationInherited\":3}','','2026-11-19 14:42:16',0,''),
(4,'sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','user:emily:sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','Emily Carter','','',1,1,'[]','','2026-11-19 14:42:18',0,''),
(5,'76Of87R9IhcsG13gWzckePLHHAgxVIE','user:james:76Of87R9IhcsG13gWzckePLHHAgxVIE','James Walker','','',1,1,'[]','','2026-11-19 14:42:19',0,''),
(6,'iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','user:olivia:iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','Olivia Bennett','','',1,1,'[]','','2026-11-19 14:42:21',0,'');
/*!40000 ALTER TABLE `oc_circles_circle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_event`
--

DROP TABLE IF EXISTS `oc_circles_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_event` (
  `token` varchar(63) NOT NULL,
  `instance` varchar(255) NOT NULL,
  `event` longtext DEFAULT NULL,
  `result` longtext DEFAULT NULL,
  `interface` int(11) NOT NULL DEFAULT 0,
  `severity` int(11) DEFAULT NULL,
  `retry` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `creation` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`token`,`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_event`
--

LOCK TABLES `oc_circles_event` WRITE;
/*!40000 ALTER TABLE `oc_circles_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_member`
--

DROP TABLE IF EXISTS `oc_circles_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `single_id` varchar(31) DEFAULT NULL,
  `circle_id` varchar(31) NOT NULL,
  `member_id` varchar(31) DEFAULT NULL,
  `user_id` varchar(127) NOT NULL,
  `user_type` smallint(6) NOT NULL DEFAULT 1,
  `instance` varchar(255) DEFAULT '',
  `invited_by` varchar(31) DEFAULT NULL,
  `level` smallint(6) NOT NULL,
  `status` varchar(15) DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `cached_name` varchar(255) DEFAULT '',
  `cached_update` datetime DEFAULT NULL,
  `contact_id` varchar(127) DEFAULT NULL,
  `contact_meta` longtext DEFAULT NULL,
  `joined` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `circles_member_cisiuiutil` (`circle_id`,`single_id`,`user_id`,`user_type`,`instance`,`level`),
  KEY `circles_member_cisi` (`circle_id`,`single_id`),
  KEY `IDX_25C66A49E7A1254A` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_member`
--

LOCK TABLES `oc_circles_member` WRITE;
/*!40000 ALTER TABLE `oc_circles_member` DISABLE KEYS */;
INSERT INTO `oc_circles_member` VALUES
(1,'yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','circles',10000,'',NULL,9,'Member','[]','Circles','2026-11-19 14:42:02','',NULL,'2026-11-19 14:42:02'),
(2,'91Srey6Chgdpp3HOrex4oxgog5QDMZY','91Srey6Chgdpp3HOrex4oxgog5QDMZY','91Srey6Chgdpp3HOrex4oxgog5QDMZY','ncadmin',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',9,'Member','[]','ncadmin','2026-11-19 14:42:02','',NULL,'2026-11-19 14:42:02'),
(3,'yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','BseqGAMELmcHVevzcsWYqI8DWQcjypM','circles',10000,'',NULL,9,'Member','[]','Circles','2026-11-19 14:42:16','',NULL,'2026-11-19 14:42:16'),
(4,'sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','emily',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',9,'Member','[]','Emily Carter','2026-11-19 14:42:18','',NULL,'2026-11-19 14:42:18'),
(5,'sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','25ZT5Zj6unl48myosiWFhbGH9tvdH15','emily',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',1,'Member','{\"invitedBy\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"userId\":\"circles\",\"userType\":10000,\"displayName\":\"Circles\",\"instance\":\"localhost\",\"basedOn\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"name\":\"app:circles:yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"displayName\":\"Circles\",\"sanitizedName\":\"\",\"source\":10001,\"population\":0,\"populationInherited\":0,\"config\":8193,\"description\":\"\",\"url\":\"\",\"creation\":1795099322,\"initiator\":null}}}','Emily Carter','2026-11-19 14:42:18','',NULL,'2026-11-19 14:42:18'),
(6,'76Of87R9IhcsG13gWzckePLHHAgxVIE','76Of87R9IhcsG13gWzckePLHHAgxVIE','76Of87R9IhcsG13gWzckePLHHAgxVIE','james',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',9,'Member','[]','James Walker','2026-11-19 14:42:20','',NULL,'2026-11-19 14:42:19'),
(7,'76Of87R9IhcsG13gWzckePLHHAgxVIE','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','vFgOTAe1lV34tLmT3WVH42iLOQ1HukT','james',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',1,'Member','{\"invitedBy\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"userId\":\"circles\",\"userType\":10000,\"displayName\":\"Circles\",\"instance\":\"localhost\",\"basedOn\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"name\":\"app:circles:yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"displayName\":\"Circles\",\"sanitizedName\":\"\",\"source\":10001,\"population\":0,\"populationInherited\":0,\"config\":8193,\"description\":\"\",\"url\":\"\",\"creation\":1795099322,\"initiator\":null}}}','James Walker','2026-11-19 14:42:20','',NULL,'2026-11-19 14:42:20'),
(8,'iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','olivia',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',9,'Member','[]','Olivia Bennett','2026-11-19 14:42:21','',NULL,'2026-11-19 14:42:21'),
(9,'iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','EAYR37YDSbb6Fs5uaQQdNKnkcHfwMEf','olivia',1,'','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',1,'Member','{\"invitedBy\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"userId\":\"circles\",\"userType\":10000,\"displayName\":\"Circles\",\"instance\":\"localhost\",\"basedOn\":{\"id\":\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"name\":\"app:circles:yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\",\"displayName\":\"Circles\",\"sanitizedName\":\"\",\"source\":10001,\"population\":0,\"populationInherited\":0,\"config\":8193,\"description\":\"\",\"url\":\"\",\"creation\":1795099322,\"initiator\":null}}}','Olivia Bennett','2026-11-19 14:42:21','',NULL,'2026-11-19 14:42:21');
/*!40000 ALTER TABLE `oc_circles_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_membership`
--

DROP TABLE IF EXISTS `oc_circles_membership`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_membership` (
  `circle_id` varchar(31) NOT NULL,
  `single_id` varchar(31) NOT NULL,
  `level` int(10) unsigned NOT NULL,
  `inheritance_first` varchar(31) NOT NULL,
  `inheritance_last` varchar(31) NOT NULL,
  `inheritance_depth` int(10) unsigned NOT NULL,
  `inheritance_path` longtext NOT NULL,
  PRIMARY KEY (`single_id`,`circle_id`),
  KEY `IDX_8FC816EAE7C1D92B` (`single_id`),
  KEY `circles_membership_ifilci` (`inheritance_first`,`inheritance_last`,`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_membership`
--

LOCK TABLES `oc_circles_membership` WRITE;
/*!40000 ALTER TABLE `oc_circles_membership` DISABLE KEYS */;
INSERT INTO `oc_circles_membership` VALUES
('76Of87R9IhcsG13gWzckePLHHAgxVIE','76Of87R9IhcsG13gWzckePLHHAgxVIE',9,'76Of87R9IhcsG13gWzckePLHHAgxVIE','76Of87R9IhcsG13gWzckePLHHAgxVIE',1,'[\"76Of87R9IhcsG13gWzckePLHHAgxVIE\"]'),
('CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','76Of87R9IhcsG13gWzckePLHHAgxVIE',1,'76Of87R9IhcsG13gWzckePLHHAgxVIE','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb',1,'[\"76Of87R9IhcsG13gWzckePLHHAgxVIE\"]'),
('91Srey6Chgdpp3HOrex4oxgog5QDMZY','91Srey6Chgdpp3HOrex4oxgog5QDMZY',9,'91Srey6Chgdpp3HOrex4oxgog5QDMZY','91Srey6Chgdpp3HOrex4oxgog5QDMZY',1,'[\"91Srey6Chgdpp3HOrex4oxgog5QDMZY\"]'),
('CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','iaJVh25bFYXnLMlQfglWEjUvhRGGP1s',1,'iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb',1,'[\"iaJVh25bFYXnLMlQfglWEjUvhRGGP1s\"]'),
('iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','iaJVh25bFYXnLMlQfglWEjUvhRGGP1s',9,'iaJVh25bFYXnLMlQfglWEjUvhRGGP1s','iaJVh25bFYXnLMlQfglWEjUvhRGGP1s',1,'[\"iaJVh25bFYXnLMlQfglWEjUvhRGGP1s\"]'),
('CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb','sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2',1,'sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','CdIYMKTXZHlrmk2XOrWdKS9lHr4dFTb',1,'[\"sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2\"]'),
('sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2',9,'sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2','sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2',1,'[\"sB3TXyIbv5khtXhbxxfEiSYMR3hEIG2\"]'),
('yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',9,'yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ','yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ',1,'[\"yFhRYjvnEi4xGqUb7odL4P8YpqzlphZ\"]');
/*!40000 ALTER TABLE `oc_circles_membership` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_mount`
--

DROP TABLE IF EXISTS `oc_circles_mount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_mount` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mount_id` varchar(31) NOT NULL,
  `circle_id` varchar(31) NOT NULL,
  `single_id` varchar(31) NOT NULL,
  `token` varchar(63) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL,
  `mountpoint` longtext DEFAULT NULL,
  `mountpoint_hash` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `circles_mount_cimipt` (`circle_id`,`mount_id`,`parent`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_mount`
--

LOCK TABLES `oc_circles_mount` WRITE;
/*!40000 ALTER TABLE `oc_circles_mount` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_mount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_mountpoint`
--

DROP TABLE IF EXISTS `oc_circles_mountpoint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_mountpoint` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mount_id` varchar(31) NOT NULL,
  `single_id` varchar(31) NOT NULL,
  `mountpoint` longtext DEFAULT NULL,
  `mountpoint_hash` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mp_sid_hash` (`single_id`,`mountpoint_hash`),
  KEY `circles_mountpoint_ms` (`mount_id`,`single_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_mountpoint`
--

LOCK TABLES `oc_circles_mountpoint` WRITE;
/*!40000 ALTER TABLE `oc_circles_mountpoint` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_mountpoint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_remote`
--

DROP TABLE IF EXISTS `oc_circles_remote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_remote` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) NOT NULL DEFAULT 'Unknown',
  `interface` int(11) NOT NULL DEFAULT 0,
  `uid` varchar(20) DEFAULT NULL,
  `instance` varchar(127) DEFAULT NULL,
  `href` varchar(254) DEFAULT NULL,
  `item` longtext DEFAULT NULL,
  `creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_F94EF834230B1DE` (`instance`),
  KEY `IDX_F94EF83539B0606` (`uid`),
  KEY `IDX_F94EF8334F8E741` (`href`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_remote`
--

LOCK TABLES `oc_circles_remote` WRITE;
/*!40000 ALTER TABLE `oc_circles_remote` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_remote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_share_lock`
--

DROP TABLE IF EXISTS `oc_circles_share_lock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_share_lock` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(31) NOT NULL,
  `circle_id` varchar(31) NOT NULL,
  `instance` varchar(127) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_337F52F8126F525E70EE2FF6` (`item_id`,`circle_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_share_lock`
--

LOCK TABLES `oc_circles_share_lock` WRITE;
/*!40000 ALTER TABLE `oc_circles_share_lock` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_share_lock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_circles_token`
--

DROP TABLE IF EXISTS `oc_circles_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_circles_token` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `share_id` int(11) DEFAULT NULL,
  `circle_id` varchar(31) DEFAULT NULL,
  `single_id` varchar(31) DEFAULT NULL,
  `member_id` varchar(31) DEFAULT NULL,
  `token` varchar(31) DEFAULT NULL,
  `password` varchar(127) DEFAULT NULL,
  `accepted` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sicisimit` (`share_id`,`circle_id`,`single_id`,`member_id`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_circles_token`
--

LOCK TABLES `oc_circles_token` WRITE;
/*!40000 ALTER TABLE `oc_circles_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_circles_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_accesscache`
--

DROP TABLE IF EXISTS `oc_collres_accesscache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_accesscache` (
  `user_id` varchar(64) NOT NULL,
  `collection_id` bigint(20) NOT NULL DEFAULT 0,
  `resource_type` varchar(64) NOT NULL DEFAULT '',
  `resource_id` varchar(64) NOT NULL DEFAULT '',
  `access` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`user_id`,`collection_id`,`resource_type`,`resource_id`),
  KEY `collres_user_res` (`user_id`,`resource_type`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_accesscache`
--

LOCK TABLES `oc_collres_accesscache` WRITE;
/*!40000 ALTER TABLE `oc_collres_accesscache` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_accesscache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_collections`
--

DROP TABLE IF EXISTS `oc_collres_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_collections` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_collections`
--

LOCK TABLES `oc_collres_collections` WRITE;
/*!40000 ALTER TABLE `oc_collres_collections` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_collections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_collres_resources`
--

DROP TABLE IF EXISTS `oc_collres_resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_collres_resources` (
  `collection_id` bigint(20) NOT NULL,
  `resource_type` varchar(64) NOT NULL,
  `resource_id` varchar(64) NOT NULL,
  PRIMARY KEY (`collection_id`,`resource_type`,`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_collres_resources`
--

LOCK TABLES `oc_collres_resources` WRITE;
/*!40000 ALTER TABLE `oc_collres_resources` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_collres_resources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments`
--

DROP TABLE IF EXISTS `oc_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `topmost_parent_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `children_count` int(10) unsigned NOT NULL DEFAULT 0,
  `actor_type` varchar(64) NOT NULL DEFAULT '',
  `actor_id` varchar(64) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `verb` varchar(64) DEFAULT NULL,
  `creation_timestamp` datetime DEFAULT NULL,
  `latest_child_timestamp` datetime DEFAULT NULL,
  `object_type` varchar(64) NOT NULL DEFAULT '',
  `object_id` varchar(64) NOT NULL DEFAULT '',
  `reference_id` varchar(64) DEFAULT NULL,
  `reactions` varchar(4000) DEFAULT NULL,
  `expire_date` datetime DEFAULT NULL,
  `meta_data` longtext DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `comments_parent_id_index` (`parent_id`),
  KEY `comments_topmost_parent_id_idx` (`topmost_parent_id`),
  KEY `comments_object_index` (`object_type`,`object_id`,`creation_timestamp`),
  KEY `comments_actor_index` (`actor_type`,`actor_id`),
  KEY `expire_date` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments`
--

LOCK TABLES `oc_comments` WRITE;
/*!40000 ALTER TABLE `oc_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_comments_read_markers`
--

DROP TABLE IF EXISTS `oc_comments_read_markers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_comments_read_markers` (
  `user_id` varchar(64) NOT NULL DEFAULT '',
  `object_type` varchar(64) NOT NULL DEFAULT '',
  `object_id` varchar(64) NOT NULL DEFAULT '',
  `marker_datetime` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`object_type`,`object_id`),
  KEY `comments_marker_object_index` (`object_type`,`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_comments_read_markers`
--

LOCK TABLES `oc_comments_read_markers` WRITE;
/*!40000 ALTER TABLE `oc_comments_read_markers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_comments_read_markers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_absence`
--

DROP TABLE IF EXISTS `oc_dav_absence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_dav_absence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `first_day` varchar(10) NOT NULL,
  `last_day` varchar(10) NOT NULL,
  `status` varchar(100) NOT NULL,
  `message` longtext NOT NULL,
  `replacement_user_id` varchar(64) DEFAULT '',
  `replacement_user_display_name` varchar(64) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_absence_uid_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_absence`
--

LOCK TABLES `oc_dav_absence` WRITE;
/*!40000 ALTER TABLE `oc_dav_absence` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_absence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_cal_proxy`
--

DROP TABLE IF EXISTS `oc_dav_cal_proxy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_dav_cal_proxy` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` varchar(64) NOT NULL,
  `proxy_id` varchar(64) NOT NULL,
  `permissions` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_cal_proxy_uidx` (`owner_id`,`proxy_id`,`permissions`),
  KEY `dav_cal_proxy_ipid` (`proxy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_cal_proxy`
--

LOCK TABLES `oc_dav_cal_proxy` WRITE;
/*!40000 ALTER TABLE `oc_dav_cal_proxy` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_cal_proxy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_dav_shares`
--

DROP TABLE IF EXISTS `oc_dav_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_dav_shares` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `access` smallint(6) DEFAULT NULL,
  `resourceid` bigint(20) unsigned NOT NULL,
  `publicuri` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dav_shares_index` (`principaluri`,`resourceid`,`type`,`publicuri`),
  KEY `dav_shares_resourceid_type` (`resourceid`,`type`),
  KEY `dav_shares_resourceid_access` (`resourceid`,`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_dav_shares`
--

LOCK TABLES `oc_dav_shares` WRITE;
/*!40000 ALTER TABLE `oc_dav_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_dav_shares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_direct_edit`
--

DROP TABLE IF EXISTS `oc_direct_edit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_direct_edit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `editor_id` varchar(64) NOT NULL,
  `token` varchar(64) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `share_id` bigint(20) DEFAULT NULL,
  `timestamp` bigint(20) unsigned NOT NULL,
  `accessed` tinyint(1) DEFAULT 0,
  `file_path` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4D5AFECA5F37A13B` (`token`),
  KEY `direct_edit_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_direct_edit`
--

LOCK TABLES `oc_direct_edit` WRITE;
/*!40000 ALTER TABLE `oc_direct_edit` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_direct_edit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_directlink`
--

DROP TABLE IF EXISTS `oc_directlink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_directlink` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) DEFAULT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  `token` varchar(60) DEFAULT NULL,
  `expiration` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `directlink_token_idx` (`token`),
  KEY `directlink_expiration_idx` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_directlink`
--

LOCK TABLES `oc_directlink` WRITE;
/*!40000 ALTER TABLE `oc_directlink` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_directlink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_apps`
--

DROP TABLE IF EXISTS `oc_ex_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_apps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `version` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `daemon_config_name` varchar(64) NOT NULL DEFAULT '0',
  `port` smallint(5) unsigned NOT NULL,
  `secret` varchar(256) NOT NULL,
  `status` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`status`)),
  `enabled` smallint(6) NOT NULL DEFAULT 0,
  `created_time` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_apps__appid` (`appid`),
  UNIQUE KEY `ex_apps_c_port__idx` (`daemon_config_name`,`port`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_apps`
--

LOCK TABLES `oc_ex_apps` WRITE;
/*!40000 ALTER TABLE `oc_ex_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_apps_daemons`
--

DROP TABLE IF EXISTS `oc_ex_apps_daemons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_apps_daemons` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `accepts_deploy_id` varchar(64) NOT NULL,
  `protocol` varchar(32) NOT NULL,
  `host` varchar(255) NOT NULL,
  `deploy_config` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`deploy_config`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_apps_daemons__name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_apps_daemons`
--

LOCK TABLES `oc_ex_apps_daemons` WRITE;
/*!40000 ALTER TABLE `oc_ex_apps_daemons` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_apps_daemons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_apps_routes`
--

DROP TABLE IF EXISTS `oc_ex_apps_routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_apps_routes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `url` varchar(512) NOT NULL,
  `verb` varchar(64) NOT NULL,
  `access_level` int(11) NOT NULL DEFAULT 0,
  `headers_to_exclude` varchar(512) DEFAULT NULL,
  `bruteforce_protection` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ex_apps_routes_appid` (`appid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_apps_routes`
--

LOCK TABLES `oc_ex_apps_routes` WRITE;
/*!40000 ALTER TABLE `oc_ex_apps_routes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_apps_routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_deploy_options`
--

DROP TABLE IF EXISTS `oc_ex_deploy_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_deploy_options` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `type` varchar(32) NOT NULL,
  `value` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`value`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `deploy_options__idx` (`appid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_deploy_options`
--

LOCK TABLES `oc_ex_deploy_options` WRITE;
/*!40000 ALTER TABLE `oc_ex_deploy_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_deploy_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_event_handlers`
--

DROP TABLE IF EXISTS `oc_ex_event_handlers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_event_handlers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `event_type` varchar(32) NOT NULL,
  `event_subtypes` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`event_subtypes`)),
  `action_handler` varchar(410) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_event_handlers__idx` (`appid`,`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_event_handlers`
--

LOCK TABLES `oc_ex_event_handlers` WRITE;
/*!40000 ALTER TABLE `oc_ex_event_handlers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_event_handlers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_occ_commands`
--

DROP TABLE IF EXISTS `oc_ex_occ_commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_occ_commands` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `arguments` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`arguments`)),
  `options` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`options`)),
  `usages` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`usages`)),
  `execute_handler` varchar(410) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_occ_commands__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_occ_commands`
--

LOCK TABLES `oc_ex_occ_commands` WRITE;
/*!40000 ALTER TABLE `oc_ex_occ_commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_occ_commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_settings_forms`
--

DROP TABLE IF EXISTS `oc_ex_settings_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_settings_forms` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `formid` varchar(64) NOT NULL,
  `scheme` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`scheme`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_settings_forms__idx` (`appid`,`formid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_settings_forms`
--

LOCK TABLES `oc_ex_settings_forms` WRITE;
/*!40000 ALTER TABLE `oc_ex_settings_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_settings_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_speech_to_text`
--

DROP TABLE IF EXISTS `oc_ex_speech_to_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_speech_to_text` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `action_handler` varchar(410) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `speech_to_text__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_speech_to_text`
--

LOCK TABLES `oc_ex_speech_to_text` WRITE;
/*!40000 ALTER TABLE `oc_ex_speech_to_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_speech_to_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_speech_to_text_q`
--

DROP TABLE IF EXISTS `oc_ex_speech_to_text_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_speech_to_text_q` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `result` longtext NOT NULL DEFAULT '',
  `error` varchar(1024) NOT NULL DEFAULT '',
  `finished` smallint(6) NOT NULL DEFAULT 0,
  `created_time` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C1E06C58A64FAB3C` (`finished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_speech_to_text_q`
--

LOCK TABLES `oc_ex_speech_to_text_q` WRITE;
/*!40000 ALTER TABLE `oc_ex_speech_to_text_q` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_speech_to_text_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_task_processing`
--

DROP TABLE IF EXISTS `oc_ex_task_processing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_task_processing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` varchar(32) NOT NULL,
  `name` varchar(255) NOT NULL,
  `display_name` varchar(255) NOT NULL,
  `task_type` varchar(255) NOT NULL,
  `custom_task_type` longtext DEFAULT NULL,
  `provider` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_processing_idx` (`app_id`,`name`,`task_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_task_processing`
--

LOCK TABLES `oc_ex_task_processing` WRITE;
/*!40000 ALTER TABLE `oc_ex_task_processing` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_task_processing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_text_processing`
--

DROP TABLE IF EXISTS `oc_ex_text_processing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_text_processing` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `action_handler` varchar(410) NOT NULL,
  `task_type` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `text_processing__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_text_processing`
--

LOCK TABLES `oc_ex_text_processing` WRITE;
/*!40000 ALTER TABLE `oc_ex_text_processing` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_text_processing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_text_processing_q`
--

DROP TABLE IF EXISTS `oc_ex_text_processing_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_text_processing_q` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `result` longtext NOT NULL DEFAULT '',
  `error` varchar(1024) NOT NULL DEFAULT '',
  `finished` smallint(6) NOT NULL DEFAULT 0,
  `created_time` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CB97986AA64FAB3C` (`finished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_text_processing_q`
--

LOCK TABLES `oc_ex_text_processing_q` WRITE;
/*!40000 ALTER TABLE `oc_ex_text_processing_q` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_text_processing_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_translation`
--

DROP TABLE IF EXISTS `oc_ex_translation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_translation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `from_languages` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`from_languages`)),
  `to_languages` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`to_languages`)),
  `action_handler` varchar(410) NOT NULL,
  `action_detect_lang` varchar(410) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_translation__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_translation`
--

LOCK TABLES `oc_ex_translation` WRITE;
/*!40000 ALTER TABLE `oc_ex_translation` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_translation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_translation_q`
--

DROP TABLE IF EXISTS `oc_ex_translation_q`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_translation_q` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `result` longtext NOT NULL DEFAULT '',
  `error` varchar(1024) NOT NULL DEFAULT '',
  `finished` smallint(6) NOT NULL DEFAULT 0,
  `created_time` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_38CE0470A64FAB3C` (`finished`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_translation_q`
--

LOCK TABLES `oc_ex_translation_q` WRITE;
/*!40000 ALTER TABLE `oc_ex_translation_q` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_translation_q` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_ui_files_actions`
--

DROP TABLE IF EXISTS `oc_ex_ui_files_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_ui_files_actions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `mime` longtext NOT NULL DEFAULT 'file',
  `permissions` varchar(255) NOT NULL,
  `order` bigint(20) NOT NULL DEFAULT 0,
  `icon` varchar(255) DEFAULT '',
  `action_handler` varchar(64) NOT NULL,
  `version` varchar(64) NOT NULL DEFAULT '1.0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ex_ui_files_actions__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_ui_files_actions`
--

LOCK TABLES `oc_ex_ui_files_actions` WRITE;
/*!40000 ALTER TABLE `oc_ex_ui_files_actions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_ui_files_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_ui_scripts`
--

DROP TABLE IF EXISTS `oc_ex_ui_scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_ui_scripts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `name` varchar(32) NOT NULL,
  `path` varchar(410) NOT NULL,
  `after_app_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_script__idx` (`appid`,`type`,`name`,`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_ui_scripts`
--

LOCK TABLES `oc_ex_ui_scripts` WRITE;
/*!40000 ALTER TABLE `oc_ex_ui_scripts` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_ui_scripts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_ui_states`
--

DROP TABLE IF EXISTS `oc_ex_ui_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_ui_states` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `name` varchar(32) NOT NULL,
  `key` varchar(64) NOT NULL,
  `value` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`value`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_state__idx` (`appid`,`type`,`name`,`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_ui_states`
--

LOCK TABLES `oc_ex_ui_states` WRITE;
/*!40000 ALTER TABLE `oc_ex_ui_states` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_ui_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_ui_styles`
--

DROP TABLE IF EXISTS `oc_ex_ui_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_ui_styles` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `name` varchar(32) NOT NULL,
  `path` varchar(410) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_style__idx` (`appid`,`type`,`name`,`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_ui_styles`
--

LOCK TABLES `oc_ex_ui_styles` WRITE;
/*!40000 ALTER TABLE `oc_ex_ui_styles` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_ui_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ex_ui_top_menu`
--

DROP TABLE IF EXISTS `oc_ex_ui_top_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ex_ui_top_menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appid` varchar(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `display_name` varchar(32) NOT NULL,
  `icon` varchar(255) DEFAULT '',
  `admin_required` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ui_top_menu__idx` (`appid`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ex_ui_top_menu`
--

LOCK TABLES `oc_ex_ui_top_menu` WRITE;
/*!40000 ALTER TABLE `oc_ex_ui_top_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_ex_ui_top_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_federated_reshares`
--

DROP TABLE IF EXISTS `oc_federated_reshares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_federated_reshares` (
  `share_id` bigint(20) NOT NULL,
  `remote_id` varchar(255) DEFAULT '',
  PRIMARY KEY (`share_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_federated_reshares`
--

LOCK TABLES `oc_federated_reshares` WRITE;
/*!40000 ALTER TABLE `oc_federated_reshares` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_federated_reshares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_file_locks`
--

DROP TABLE IF EXISTS `oc_file_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_file_locks` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lock` int(11) NOT NULL DEFAULT 0,
  `key` varchar(64) NOT NULL,
  `ttl` int(11) NOT NULL DEFAULT -1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lock_key_index` (`key`),
  KEY `lock_ttl_index` (`ttl`)
) ENGINE=InnoDB AUTO_INCREMENT=179 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_file_locks`
--

LOCK TABLES `oc_file_locks` WRITE;
/*!40000 ALTER TABLE `oc_file_locks` DISABLE KEYS */;
INSERT INTO `oc_file_locks` VALUES
(1,0,'files/38d3fc13a505a341da34815c5ccc8b3d',1795102962),
(2,0,'files/b2ce679c35b2a1b1ef1cc7549ff2995d',1795102952),
(3,0,'files/a9c73329a2d52c0274b441586cb76567',1795102962),
(5,0,'files/43053125d329a0dfbcc71cd2d4ba6d6a',1795102952),
(6,0,'files/dd98a2c9fa2cfbc37a35600e6c73b051',1795102952),
(8,0,'files/544b5c841a575a95b3792d3ec6c8ce8f',1795102952),
(9,0,'files/c6c036b8bf200f72e77212b429488a94',1795102952),
(14,0,'files/72244a325545c6c43c2c46af92336b1d',1795102952),
(15,0,'files/8c8da64f8c34c8bf3afe4ce8278ff879',1795102962),
(16,0,'files/bfb529cf6f4763b84e960e1986166da6',1795102952),
(17,0,'files/c49a7560b6c252334ff1a6a78dd52cf0',1795102962),
(21,0,'files/5319eaef9ffd8f021abde5dd7b19c8e1',1795102952),
(22,0,'files/84052fe9e5732e5671d3e3b06242c7f1',1795102952),
(23,0,'files/aad38c8200ad572fc57fbaa87406da4b',1795102952),
(24,0,'files/e96d854ef555768905b664ff6d182a47',1795102952),
(25,0,'files/1fa11ae82c8d6edad0e6abbb52d7b6b6',1795102981),
(26,0,'files/9264b64496e01437e2e3e42b459ac0cd',1795102981),
(28,0,'files/d3d5bfa19c55417cbe30229229a6cd31',1795102981),
(29,0,'files/f1b3694a070e03ae840ed2aecd81bb68',1795102952),
(30,0,'files/02eb08e7ed924347b1d4d6bca6cf12a2',1795102952),
(31,0,'files/8886736293d0817c744869cebc27b308',1795102952),
(32,0,'files/40edc141f766f2a99ee35549d282e380',1795102952),
(33,0,'files/2b0ca9e0d47d92d1ade03d0c132040ba',1795102952),
(34,0,'files/7f50d50149c550686084d92461291aed',1795102952),
(35,0,'files/f3add36a7b828061d28e43b2c364ef2e',1795102952),
(36,0,'files/9857d7f17b48f114f5d0e668b94fc139',1795102952),
(37,0,'files/474dc451475ca206ea9e466a523c3572',1795102952),
(38,0,'files/e31af95ae2927d6945bdcd3430c89966',1795102952),
(39,0,'files/d510e53f48c64e68b7f2d80a6a4d2225',1795102952),
(40,0,'files/89cf9155fd3c0d31e5c0382ee45b65bd',1795102952),
(41,0,'files/e23d9c347f1e95f9f9bb23ec6c25a03c',1795102952),
(42,0,'files/30cdf7fa39585b36bdbfcc2cdb8a75a5',1795102952),
(43,0,'files/b1c834faa75ab5d5b2fc5257452ddcdb',1795102952),
(44,0,'files/dea2041d91dbca5f2a638548465e0303',1795102952),
(45,0,'files/618ce147c5ce5c9de29411bb6df1c454',1795102952),
(46,0,'files/2390960348be4d9da01ee89d00cf3d80',1795102952),
(47,0,'files/919416ff8baab643836141852d53e94e',1795102952),
(48,0,'files/9f0e55e290f73b16a2a1b007b53f287f',1795102952),
(49,0,'files/f7369cf6a59af6753c64ffe47830948b',1795102952),
(50,0,'files/38d3e192389cf238c3f6b30844d74c2d',1795102952),
(51,0,'files/ea4b2fa84ca3beced5ba1a5e6cfb2e59',1795102952),
(52,0,'files/abf2c200df47fd2d5d6c0c0a96769405',1795102952),
(53,0,'files/fe0276944dacb1723ada65e0a7723917',1795102952),
(54,0,'files/045304497500a1dd65cb32b50c48c9bf',1795102952),
(55,0,'files/5d898abc37c68c548a3ea6f0938fb3a8',1795102952),
(56,0,'files/eb9c44e4132a28a3341061481c06b2df',1795102952),
(57,0,'files/0533365371ab6782fc8e6b3f9921a423',1795102952),
(58,0,'files/bd617594f160bfed830bdc9dae18e489',1795102952),
(59,0,'files/5633e82f066d51b535c0f939a8d03c95',1795102952),
(60,0,'files/1b3783d893104761d345e8e74faa4964',1795102952),
(61,0,'files/f1225a8404535e884307e08a747bc17b',1795102952),
(62,0,'files/d240c50150bc5e90f48f8a80b5e108b4',1795102952),
(63,0,'files/92cc9d0962942c8721e3b433baa54ae0',1795102952),
(64,0,'files/e52fc8e7095e4dd757b15eb86211c729',1795102952),
(65,0,'files/a74fc930fe1b849c2bbda8bdf7cfeb55',1795102952),
(66,0,'files/d1c59fed38aa81fa5c68d55e36f3adbf',1795102952),
(67,0,'files/94f9725ff5d5ac29638fae3b1b8d610c',1795102952),
(68,0,'files/0671fd1da74c73e6cb288ab5c3c5fcbe',1795102952),
(69,0,'files/7cb6c1061ec015077f6242be48796da4',1795102952),
(70,0,'files/5bfcbeeee8724724670508859d470092',1795102952),
(71,0,'files/c87d3b492e1489d2add569bc2bd11e02',1795102952),
(72,0,'files/ada7c6d95051d46e063282382b236fce',1795102952),
(73,0,'files/1871bfff36e7b7a79f4b1963ee238b1f',1795102952),
(74,0,'files/1d46d3a5a5a311ce943fa3488da8f676',1795102952),
(75,0,'files/1f6d61654ff250ab7018a1aaa05f3869',1795102952),
(76,0,'files/a30c8c8cde46c33fbc12f0fae67761f3',1795102952),
(77,0,'files/7634ea25bd0835a5a7d2ac26cbe1bbe5',1795102952),
(78,0,'files/cec9451deb1c11c68a073d587602cf97',1795102952),
(79,0,'files/425192028f196bf252ed30b06e1b87ce',1795102952),
(80,0,'files/6c0051b81c85a3ee614aa0a5ffdf9bcd',1795102952),
(81,0,'files/7ac582b6ceb519a730ab11690acf93dc',1795102952),
(82,0,'files/f889165d891f060abccf1b5f14a31366',1795102952),
(83,0,'files/27c43fa531fbcd85ed98267b2d4c9002',1795102952),
(87,0,'files/b94fdee2fe5f70f7644a38f786a12fe7',1795102952),
(88,0,'files/80fb9b349d10524c4914d5d162dc59bb',1795102952),
(89,0,'files/91aec194810fef331ee3705fdf5bacd8',1795102952),
(90,0,'files/d9ec8d2f0f55990e9fb1dcad8a324aa7',1795102952);
/*!40000 ALTER TABLE `oc_file_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache`
--

DROP TABLE IF EXISTS `oc_filecache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_filecache` (
  `fileid` bigint(20) NOT NULL AUTO_INCREMENT,
  `storage` bigint(20) NOT NULL DEFAULT 0,
  `path` varchar(4000) DEFAULT NULL,
  `path_hash` varchar(32) NOT NULL DEFAULT '',
  `parent` bigint(20) NOT NULL DEFAULT 0,
  `name` varchar(250) DEFAULT NULL,
  `mimetype` bigint(20) NOT NULL DEFAULT 0,
  `mimepart` bigint(20) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `mtime` bigint(20) NOT NULL DEFAULT 0,
  `storage_mtime` bigint(20) NOT NULL DEFAULT 0,
  `encrypted` int(11) NOT NULL DEFAULT 0,
  `unencrypted_size` bigint(20) NOT NULL DEFAULT 0,
  `etag` varchar(40) DEFAULT NULL,
  `permissions` int(11) DEFAULT 0,
  `checksum` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fileid`),
  UNIQUE KEY `fs_storage_path_hash` (`storage`,`path_hash`),
  KEY `fs_parent_name_hash` (`parent`,`name`),
  KEY `fs_storage_mimetype` (`storage`,`mimetype`),
  KEY `fs_storage_mimepart` (`storage`,`mimepart`),
  KEY `fs_storage_size` (`storage`,`size`,`fileid`),
  KEY `fs_parent` (`parent`),
  KEY `fs_name_hash` (`name`),
  KEY `fs_mtime` (`mtime`),
  KEY `fs_size` (`size`),
  KEY `fs_storage_path_prefix` (`storage`,`path`(64))
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache`
--

LOCK TABLES `oc_filecache` WRITE;
/*!40000 ALTER TABLE `oc_filecache` DISABLE KEYS */;
INSERT INTO `oc_filecache` VALUES
(1,1,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,0,1795099381,1795099322,0,0,'6aff0af554858',23,''),
(2,1,'files','45b963397aa40d4a0063e0d85e4fe7a1',1,'files',2,1,0,1795099381,1795099381,0,0,'6aff0af554858',31,''),
(58,2,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,-1,1795099338,1795099338,0,0,'6aff0aca0fafb',23,''),
(59,2,'appdata_oc0r9vyjyfuq','dd1a5704179e5e6eb0601fb02c478545',58,'appdata_oc0r9vyjyfuq',2,1,0,1795099362,1795099362,0,0,'6aff0aca0fa31',31,''),
(60,2,'appdata_oc0r9vyjyfuq/avatar','3656a00345f681a754e9259c4c0423cd',59,'avatar',2,1,0,1795099341,1795099341,0,0,'6aff0aca101e0',31,''),
(61,2,'appdata_oc0r9vyjyfuq/avatar/emily','c1f70b6f8c6893ad6a952c3845bc0409',60,'emily',2,1,0,1795099338,1795099338,0,0,'6aff0aca105dd',31,''),
(65,2,'appdata_oc0r9vyjyfuq/avatar/emily/avatar.png','fcf7aea91a4e86b6f37255a682c8b8d8',61,'avatar.png',17,15,18433,1795099338,1795099338,0,0,'2817a72553951f1f063f7daa6fa9d148',27,''),
(66,2,'appdata_oc0r9vyjyfuq/avatar/emily/generated','9b7e55b22531114c1982bd1281ed5e14',61,'generated',18,5,0,1795099338,1795099338,0,0,'2af8edf805af53ab11beeef744132f32',27,''),
(67,2,'appdata_oc0r9vyjyfuq/avatar/emily/avatar.512.png','5f78d77da8ae96f390b060a79bca0751',61,'avatar.512.png',17,15,8215,1795099338,1795099338,0,0,'e51664c1386236a2031942b0bc449d46',27,''),
(68,3,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,102,1795099362,1795099362,0,0,'6aff0ae2dd6f9',23,''),
(69,2,'appdata_oc0r9vyjyfuq/avatar/james','d5dc3719513917927606da686a08d83d',60,'james',2,1,0,1795099339,1795099339,0,0,'6aff0acba729a',31,''),
(73,2,'appdata_oc0r9vyjyfuq/avatar/james/avatar.png','8655665e5357ad9fd9eae77a6374cfd5',69,'avatar.png',17,15,26723,1795099339,1795099339,0,0,'0b6d7a849324eeea3083bbb15fe17443',27,''),
(74,2,'appdata_oc0r9vyjyfuq/avatar/james/generated','12def6f2fe75cc7d513f5e7b879f8e65',69,'generated',18,5,0,1795099339,1795099339,0,0,'928cca43823791b2fcb057e5587df861',27,''),
(75,2,'appdata_oc0r9vyjyfuq/avatar/james/avatar.512.png','085d14490494ad28e019e410eebeab5f',69,'avatar.512.png',17,15,11517,1795099339,1795099339,0,0,'1cc0a18752c635d0546cb726548314e3',27,''),
(76,4,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,68,1795099342,1795099341,0,0,'6aff0ace2385b',23,''),
(77,2,'appdata_oc0r9vyjyfuq/avatar/olivia','02e3bf466e43649e75e410c7cbb91578',60,'olivia',2,1,0,1795099341,1795099341,0,0,'6aff0acd299b5',31,''),
(81,2,'appdata_oc0r9vyjyfuq/avatar/olivia/avatar.png','aad79ac37a58de836842756ddb9d87e9',77,'avatar.png',17,15,31373,1795099341,1795099341,0,0,'5dcac417c0c227fd71ed882f3948d41e',27,''),
(82,2,'appdata_oc0r9vyjyfuq/avatar/olivia/generated','04c7234759b9aef71a8aec54e0d03e36',77,'generated',18,5,0,1795099341,1795099341,0,0,'3e802e6c85c455ec809d8f2f2684b55c',27,''),
(83,2,'appdata_oc0r9vyjyfuq/avatar/olivia/avatar.512.png','5e30d7979ba1217229b5dd3bb4180b08',77,'avatar.512.png',17,15,14079,1795099341,1795099341,0,0,'35e9fbf915b1730698a33030eb6c6c19',27,''),
(84,5,'','d41d8cd98f00b204e9800998ecf8427e',-1,'',2,1,65,1795099342,1795099341,0,0,'6aff0ace2abb3',23,''),
(85,3,'files','45b963397aa40d4a0063e0d85e4fe7a1',68,'files',2,1,102,1795099342,1795099341,0,0,'6aff0ace211d2',31,''),
(86,3,'files/Campaigns','63a9f4236b7035bd45c6e6af8c06449c',85,'Campaigns',2,1,60,1795099342,1795099341,0,0,'6aff0ace211d2',31,''),
(87,3,'files/Launch-checklist.txt','fe2e137208398e97e641aab888332119',85,'Launch-checklist.txt',19,3,42,1795099341,1795099341,0,0,'2e781e83b9fe4f29f05f50ba816753d9',27,''),
(88,3,'files/Campaigns/Marketing-plan.txt','be8f37b51914a43997288bd69d792deb',86,'Marketing-plan.txt',19,3,60,1795099341,1795099341,0,0,'9a880e23198c9e4b7ca2e4cfb14730fe',27,''),
(89,4,'files','45b963397aa40d4a0063e0d85e4fe7a1',76,'files',2,1,68,1795099342,1795099341,0,0,'6aff0ace2385b',31,''),
(90,4,'files/Reports','59a19f88347db89790f22a634a62162b',89,'Reports',2,1,30,1795099342,1795099341,0,0,'6aff0ace2385b',31,''),
(91,4,'files/Meeting-notes.txt','eaafdb0f9471ae74f25c68f7e0bc4a22',89,'Meeting-notes.txt',19,3,38,1795099341,1795099341,0,0,'12458fb3af1417684a6331cb2f49e766',27,''),
(92,4,'files/Reports/Sales-report.txt','88a5822d3dcf17a20061c460b82e57a4',90,'Sales-report.txt',19,3,30,1795099341,1795099341,0,0,'7ed8a57350e45756badc7118fe80b3ee',27,''),
(93,5,'files','45b963397aa40d4a0063e0d85e4fe7a1',84,'files',2,1,65,1795099342,1795099341,0,0,'6aff0ace2abb3',31,''),
(94,5,'files/Design','c56349c82d46e489d5af1a4a0c441cb3',93,'Design',2,1,33,1795099342,1795099341,0,0,'6aff0ace2abb3',31,''),
(95,5,'files/Landing-ideas.txt','1a31a547961586a41a11091145e6022d',93,'Landing-ideas.txt',19,3,32,1795099341,1795099341,0,0,'3945806145f8a139b3c006d9b1932f5a',27,''),
(96,5,'files/Design/Brand-guide.txt','f09589f89f611b72dfaadc42e769027e',94,'Brand-guide.txt',19,3,33,1795099341,1795099341,0,0,'91305ed4e52e413cf5b88ae22b513f97',27,''),
(97,3,'cache','0fea6a13c52b4d4725368f24b045ca84',68,'cache',2,1,0,1795099362,1795099362,0,0,'6aff0ae2dc969',31,''),
(98,2,'appdata_oc0r9vyjyfuq/theming','69feb20c9212b34f39b0b4f603a3b2dd',59,'theming',2,1,0,1795099362,1795099362,0,0,'6aff0ae2f01aa',31,''),
(99,2,'appdata_oc0r9vyjyfuq/theming/global','f09097ebae6784bf01e2b3b3f81ed420',98,'global',2,1,0,1795099362,1795099362,0,0,'6aff0ae2f0b83',31,'');
/*!40000 ALTER TABLE `oc_filecache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_filecache_extended`
--

DROP TABLE IF EXISTS `oc_filecache_extended`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_filecache_extended` (
  `fileid` bigint(20) unsigned NOT NULL,
  `metadata_etag` varchar(40) DEFAULT NULL,
  `creation_time` bigint(20) NOT NULL DEFAULT 0,
  `upload_time` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fileid`),
  KEY `fce_ctime_idx` (`creation_time`),
  KEY `fce_utime_idx` (`upload_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_filecache_extended`
--

LOCK TABLES `oc_filecache_extended` WRITE;
/*!40000 ALTER TABLE `oc_filecache_extended` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_filecache_extended` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_metadata`
--

DROP TABLE IF EXISTS `oc_files_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_metadata` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL,
  `json` longtext NOT NULL,
  `sync_token` varchar(15) NOT NULL,
  `last_update` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `files_meta_fileid` (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_metadata`
--

LOCK TABLES `oc_files_metadata` WRITE;
/*!40000 ALTER TABLE `oc_files_metadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_metadata_index`
--

DROP TABLE IF EXISTS `oc_files_metadata_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_metadata_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL,
  `meta_key` varchar(31) DEFAULT NULL,
  `meta_value_string` varchar(63) DEFAULT NULL,
  `meta_value_int` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `f_meta_index` (`file_id`,`meta_key`,`meta_value_string`),
  KEY `f_meta_index_i` (`file_id`,`meta_key`,`meta_value_int`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_metadata_index`
--

LOCK TABLES `oc_files_metadata_index` WRITE;
/*!40000 ALTER TABLE `oc_files_metadata_index` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_metadata_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_reminders`
--

DROP TABLE IF EXISTS `oc_files_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_reminders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `file_id` bigint(20) unsigned NOT NULL,
  `due_date` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `notified` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reminders_uniq_idx` (`user_id`,`file_id`,`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_reminders`
--

LOCK TABLES `oc_files_reminders` WRITE;
/*!40000 ALTER TABLE `oc_files_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_trash`
--

DROP TABLE IF EXISTS `oc_files_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_trash` (
  `auto_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` varchar(250) NOT NULL DEFAULT '',
  `user` varchar(64) NOT NULL DEFAULT '',
  `timestamp` varchar(12) NOT NULL DEFAULT '',
  `location` varchar(512) NOT NULL DEFAULT '',
  `type` varchar(4) DEFAULT NULL,
  `mime` varchar(255) DEFAULT NULL,
  `deleted_by` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`auto_id`),
  KEY `id_index` (`id`),
  KEY `timestamp_index` (`timestamp`),
  KEY `user_index` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_trash`
--

LOCK TABLES `oc_files_trash` WRITE;
/*!40000 ALTER TABLE `oc_files_trash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_files_trash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_files_versions`
--

DROP TABLE IF EXISTS `oc_files_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_files_versions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `file_id` bigint(20) NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `size` bigint(20) NOT NULL,
  `mimetype` bigint(20) NOT NULL,
  `metadata` longtext NOT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`metadata`)),
  PRIMARY KEY (`id`),
  UNIQUE KEY `files_versions_uniq_index` (`file_id`,`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_files_versions`
--

LOCK TABLES `oc_files_versions` WRITE;
/*!40000 ALTER TABLE `oc_files_versions` DISABLE KEYS */;
INSERT INTO `oc_files_versions` VALUES
(1,3,1795099322,2403,4,'{\"author\":\"ncadmin\"}'),
(2,5,1795099322,1095,4,'{\"author\":\"ncadmin\"}'),
(3,6,1795099322,1083339,6,'{\"author\":\"ncadmin\"}'),
(4,7,1795099322,23876,7,'{\"author\":\"ncadmin\"}'),
(5,8,1795099322,136,4,'{\"author\":\"ncadmin\"}'),
(6,9,1795099322,3963036,9,'{\"author\":\"ncadmin\"}'),
(7,11,1795099322,30780,10,'{\"author\":\"ncadmin\"}'),
(8,12,1795099322,35657,10,'{\"author\":\"ncadmin\"}'),
(9,13,1795099322,31132,10,'{\"author\":\"ncadmin\"}'),
(10,14,1795099322,317015,11,'{\"author\":\"ncadmin\"}'),
(11,15,1795099322,88394,12,'{\"author\":\"ncadmin\"}'),
(12,16,1795099322,340061,13,'{\"author\":\"ncadmin\"}'),
(13,17,1795099322,30290,10,'{\"author\":\"ncadmin\"}'),
(14,18,1795099322,15961,13,'{\"author\":\"ncadmin\"}'),
(15,19,1795099322,52843,12,'{\"author\":\"ncadmin\"}'),
(16,20,1795099322,3509628,11,'{\"author\":\"ncadmin\"}'),
(17,21,1795099322,16988,14,'{\"author\":\"ncadmin\"}'),
(18,22,1795099322,5155877,13,'{\"author\":\"ncadmin\"}'),
(19,23,1795099322,27629,10,'{\"author\":\"ncadmin\"}'),
(20,24,1795099322,13878,14,'{\"author\":\"ncadmin\"}'),
(21,25,1795099322,39404,13,'{\"author\":\"ncadmin\"}'),
(22,26,1795099322,13653,14,'{\"author\":\"ncadmin\"}'),
(23,27,1795099322,30354,13,'{\"author\":\"ncadmin\"}'),
(24,28,1795099323,11836,14,'{\"author\":\"ncadmin\"}'),
(25,29,1795099323,30671,10,'{\"author\":\"ncadmin\"}'),
(26,30,1795099323,573,4,'{\"author\":\"ncadmin\"}'),
(27,31,1795099323,31325,10,'{\"author\":\"ncadmin\"}'),
(28,32,1795099323,868111,13,'{\"author\":\"ncadmin\"}'),
(29,33,1795099323,81196,11,'{\"author\":\"ncadmin\"}'),
(30,34,1795099323,13378,12,'{\"author\":\"ncadmin\"}'),
(31,35,1795099323,23359,10,'{\"author\":\"ncadmin\"}'),
(32,36,1795099323,14316,11,'{\"author\":\"ncadmin\"}'),
(33,37,1795099323,14810,11,'{\"author\":\"ncadmin\"}'),
(34,38,1795099323,45778,10,'{\"author\":\"ncadmin\"}'),
(35,39,1795099323,25621,10,'{\"author\":\"ncadmin\"}'),
(36,40,1795099323,13441,12,'{\"author\":\"ncadmin\"}'),
(37,41,1795099323,554,4,'{\"author\":\"ncadmin\"}'),
(38,42,1795099323,326,4,'{\"author\":\"ncadmin\"}'),
(39,43,1795099323,17276,13,'{\"author\":\"ncadmin\"}'),
(40,44,1795099323,15839120,6,'{\"author\":\"ncadmin\"}'),
(41,45,1795099323,976625,6,'{\"author\":\"ncadmin\"}'),
(42,47,1795099323,593508,16,'{\"author\":\"ncadmin\"}'),
(43,48,1795099323,797325,16,'{\"author\":\"ncadmin\"}'),
(44,49,1795099323,427030,16,'{\"author\":\"ncadmin\"}'),
(45,50,1795099323,567689,16,'{\"author\":\"ncadmin\"}'),
(46,51,1795099323,2170375,16,'{\"author\":\"ncadmin\"}'),
(47,52,1795099323,457744,16,'{\"author\":\"ncadmin\"}'),
(48,53,1795099323,167989,16,'{\"author\":\"ncadmin\"}'),
(49,54,1795099323,474653,16,'{\"author\":\"ncadmin\"}'),
(50,55,1795099323,150,4,'{\"author\":\"ncadmin\"}'),
(51,56,1795099323,197,4,'{\"author\":\"ncadmin\"}'),
(52,57,1795099323,50598,17,'{\"author\":\"ncadmin\"}');
/*!40000 ALTER TABLE `oc_files_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_checks`
--

DROP TABLE IF EXISTS `oc_flow_checks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(256) NOT NULL DEFAULT '',
  `operator` varchar(16) NOT NULL DEFAULT '',
  `value` longtext DEFAULT NULL,
  `hash` varchar(32) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flow_unique_hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_checks`
--

LOCK TABLES `oc_flow_checks` WRITE;
/*!40000 ALTER TABLE `oc_flow_checks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_checks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_operations`
--

DROP TABLE IF EXISTS `oc_flow_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_operations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class` varchar(256) NOT NULL DEFAULT '',
  `name` varchar(256) DEFAULT '',
  `checks` longtext DEFAULT NULL,
  `operation` longtext DEFAULT NULL,
  `entity` varchar(256) NOT NULL DEFAULT 'OCA\\WorkflowEngine\\Entity\\File',
  `events` longtext NOT NULL DEFAULT '[]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_operations`
--

LOCK TABLES `oc_flow_operations` WRITE;
/*!40000 ALTER TABLE `oc_flow_operations` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_flow_operations_scope`
--

DROP TABLE IF EXISTS `oc_flow_operations_scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_flow_operations_scope` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `operation_id` int(11) NOT NULL DEFAULT 0,
  `type` int(11) NOT NULL DEFAULT 0,
  `value` varchar(64) DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `flow_unique_scope` (`operation_id`,`type`,`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_flow_operations_scope`
--

LOCK TABLES `oc_flow_operations_scope` WRITE;
/*!40000 ALTER TABLE `oc_flow_operations_scope` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_flow_operations_scope` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_admin`
--

DROP TABLE IF EXISTS `oc_group_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_group_admin` (
  `gid` varchar(64) NOT NULL DEFAULT '',
  `uid` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `group_admin_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_admin`
--

LOCK TABLES `oc_group_admin` WRITE;
/*!40000 ALTER TABLE `oc_group_admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_group_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_group_user`
--

DROP TABLE IF EXISTS `oc_group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_group_user` (
  `gid` varchar(64) NOT NULL DEFAULT '',
  `uid` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`gid`,`uid`),
  KEY `gu_uid_index` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_group_user`
--

LOCK TABLES `oc_group_user` WRITE;
/*!40000 ALTER TABLE `oc_group_user` DISABLE KEYS */;
INSERT INTO `oc_group_user` VALUES
('Marketing Team','emily'),
('Marketing Team','james'),
('Marketing Team','olivia'),
('admin','ncadmin');
/*!40000 ALTER TABLE `oc_group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_groups`
--

DROP TABLE IF EXISTS `oc_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_groups` (
  `gid` varchar(64) NOT NULL DEFAULT '',
  `displayname` varchar(255) NOT NULL DEFAULT 'name',
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_groups`
--

LOCK TABLES `oc_groups` WRITE;
/*!40000 ALTER TABLE `oc_groups` DISABLE KEYS */;
INSERT INTO `oc_groups` VALUES
('Marketing Team','Marketing Team'),
('admin','admin');
/*!40000 ALTER TABLE `oc_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_jobs`
--

DROP TABLE IF EXISTS `oc_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(255) NOT NULL DEFAULT '',
  `argument` varchar(4000) NOT NULL DEFAULT '',
  `last_run` int(11) DEFAULT 0,
  `last_checked` int(11) DEFAULT 0,
  `reserved_at` int(11) DEFAULT 0,
  `execution_duration` int(11) DEFAULT 0,
  `argument_hash` varchar(64) DEFAULT NULL,
  `time_sensitive` smallint(6) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `job_class_index` (`class`),
  KEY `job_lastcheck_reserved` (`last_checked`,`reserved_at`),
  KEY `job_argument_hash` (`class`,`argument_hash`),
  KEY `jobs_time_sensitive` (`time_sensitive`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_jobs`
--

LOCK TABLES `oc_jobs` WRITE;
/*!40000 ALTER TABLE `oc_jobs` DISABLE KEYS */;
INSERT INTO `oc_jobs` VALUES
(1,'OCA\\Files_Trashbin\\BackgroundJob\\ExpireTrash','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(2,'OCA\\Files_Versions\\BackgroundJob\\ExpireVersions','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(3,'OCA\\NextcloudAnnouncements\\Cron\\Crawler','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(4,'OCA\\Notifications\\BackgroundJob\\GenerateUserSettings','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(5,'OCA\\Notifications\\BackgroundJob\\SendNotificationMails','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(6,'OCA\\WorkflowEngine\\BackgroundJobs\\Rotate','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(7,'OCA\\Support\\BackgroundJobs\\CheckSubscription','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(8,'OCA\\FilesReminders\\BackgroundJob\\CleanUpReminders','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(9,'OCA\\FilesReminders\\BackgroundJob\\ScheduledNotifications','null',0,1795099320,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(10,'OCA\\ContactsInteraction\\BackgroundJob\\CleanupJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(11,'OCA\\ServerInfo\\Jobs\\UpdateStorageStats','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(12,'OCA\\Files\\BackgroundJob\\ScanFiles','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(13,'OCA\\Files\\BackgroundJob\\DeleteOrphanedItems','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(14,'OCA\\Files\\BackgroundJob\\CleanupFileLocks','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(15,'OCA\\Files\\BackgroundJob\\CleanupDirectEditingTokens','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(16,'OCA\\Files\\BackgroundJob\\DeleteExpiredOpenLocalEditor','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(17,'OCA\\Circles\\Cron\\Maintenance','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(18,'OCA\\UpdateNotification\\BackgroundJob\\UpdateAvailableNotifications','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(19,'OCA\\Activity\\BackgroundJob\\EmailNotification','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(20,'OCA\\Activity\\BackgroundJob\\ExpireActivities','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(21,'OCA\\Activity\\BackgroundJob\\DigestMail','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(22,'OCA\\Activity\\BackgroundJob\\RemoveFormerActivitySettings','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(23,'OCA\\DAV\\BackgroundJob\\CleanupDirectLinksJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(24,'OCA\\DAV\\BackgroundJob\\UpdateCalendarResourcesRoomsBackgroundJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(25,'OCA\\DAV\\BackgroundJob\\CleanupInvitationTokenJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(26,'OCA\\DAV\\BackgroundJob\\EventReminderJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(27,'OCA\\DAV\\BackgroundJob\\CalendarRetentionJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(28,'OCA\\DAV\\BackgroundJob\\PruneOutdatedSyncTokensJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(29,'OCA\\OAuth2\\BackgroundJob\\CleanupExpiredAuthorizationCode','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(30,'OCA\\Federation\\SyncJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(31,'OCA\\AppAPI\\BackgroundJob\\ExAppInitStatusCheckJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(32,'OCA\\AppAPI\\BackgroundJob\\ProvidersAICleanUpJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(33,'OCA\\Files_Sharing\\DeleteOrphanedSharesJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(34,'OCA\\Files_Sharing\\ExpireSharesJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(35,'OCA\\Files_Sharing\\SharesReminderJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(36,'OCA\\Files_Sharing\\BackgroundJob\\FederatedSharesDiscoverJob','null',0,1795099321,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(37,'OCA\\UserStatus\\BackgroundJob\\ClearOldStatusesBackgroundJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(38,'OCA\\Photos\\Jobs\\AutomaticPlaceMapperJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(39,'OCA\\Text\\Cron\\Cleanup','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(40,'OC\\Authentication\\Token\\TokenCleanupJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(41,'OC\\Log\\Rotate','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(42,'OC\\Preview\\BackgroundCleanupJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(43,'OC\\TextProcessing\\RemoveOldTasksBackgroundJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(44,'OC\\User\\BackgroundJobs\\CleanupDeletedUsers','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(45,'OC\\Core\\BackgroundJobs\\GenerateMetadataJob','null',0,1795099322,0,0,'74234e98afe7498fb5daf1f36ac2d78acc339464f950703b8c019892f982b90b',1),
(46,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",3]',0,1795099322,0,0,'5a31a27579635b3246b1c7f560d5b5771a1b5e2a08a6b0f1a40f331f95b2b19a',1),
(47,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",5]',0,1795099322,0,0,'efbf0b6dd84c62727f3edb367833cf08b0bfce4739d9eae3d1aa3142da010952',1),
(48,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",6]',0,1795099322,0,0,'2142f6b985da484b78065cbcbc0a02608c6f543ff6d9a65ea620d1cb7c8a25fc',1),
(49,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",7]',0,1795099322,0,0,'7114160f6b389ff02ce7932950da7941510d58f99091fa66ce754801b7db7b6a',1),
(50,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",8]',0,1795099322,0,0,'f31cc64be5aa4c3353a0be2456bd44ab58f2b60002ceddbe8880c0039c11171b',1),
(51,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",9]',0,1795099322,0,0,'d62a7b6f8cb1ac0a1d557fe26ea0624f2edcf99c324e770619dd4b10a9bf1fcc',1),
(52,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",11]',0,1795099322,0,0,'205577aae3c59c01f3adf48dd1469def7cf4d1fe7c0f7b2082539a234ef91dfa',1),
(53,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",12]',0,1795099322,0,0,'33128336c9c114402e002b6020c4800d2f71b5a4280ec89a22a05361b5124cc5',1),
(54,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",13]',0,1795099322,0,0,'b0367b9d6abe9e4d384ae3da8347c19ef8d36fa1a24c5040fd687d06aa3303da',1),
(55,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",14]',0,1795099322,0,0,'9a7ff1f57171a6b2508ff5f85eead8056db1edb3324f01f15bcc41793e7fa1d7',1),
(56,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",15]',0,1795099322,0,0,'c02ca465e66e7550ea11d0ee8ce4a71971123a589fb6380a95ecb2d0bdb4ebde',1),
(57,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",16]',0,1795099322,0,0,'17c14b516266bddec8aec589499d4b2c3ccffbee69a23134547cc3055e1772d6',1),
(58,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",17]',0,1795099322,0,0,'c3134fe6e395ada3b28b00deb33c2e462a15340a06e46cf4b2daff8eb455c24f',1),
(59,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",18]',0,1795099322,0,0,'c45f8e738df9aace1f973efb51bb65d3178e429528fa60af6b966371e6ebb899',1),
(60,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",19]',0,1795099322,0,0,'b57baa920173b81e96951e985047ac63c885e5519b9bc17d5290a8e9e53bd44b',1),
(61,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",20]',0,1795099322,0,0,'fdad5c61ebc97829d3acc2022b8f83e2421c01b1da59fc1b838a4cae88fc679a',1),
(62,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",21]',0,1795099322,0,0,'d2230c9615c1881170f2cfaa3123d93bc816d1798533df109b705590861e3044',1),
(63,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",22]',0,1795099322,0,0,'ab51eccb79b14ec3105adb0139622e3a3c6877089d7614dbc47394f9558c7009',1),
(64,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",23]',0,1795099322,0,0,'51f387d9f7e42070e394a566cfa4ae0a539b134f6204d251c86952789732258c',1),
(65,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",24]',0,1795099322,0,0,'6b577296f89dda2179942500644cb0c1566c2e720bd4a62253dc4c6649a2b19c',1),
(66,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",25]',0,1795099322,0,0,'276fd514d3590bf8ca452f7ca7e2a6cce07f816c18e7f65b19ffe4ff68177681',1),
(67,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",26]',0,1795099322,0,0,'5289ce0830227f1b3b2ec9f3ab0b923dcf2010e14170caeb2fdbf1baa4134905',1),
(68,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",27]',0,1795099322,0,0,'f1252d7cb03f33c2c867c7cbbd668ae7e23a7af1dfb6377aa0e5c89577fb5149',1),
(69,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",28]',0,1795099323,0,0,'6e20a03f23f099ba08e18347ab8b4f134f86022aee7cbf7d09a91b86a9e7d7f9',1),
(70,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",29]',0,1795099323,0,0,'a7b747cfe5675d6aee5c2e88a6e2f9d6bf4611a8ec941f39b0798b3474ec4a06',1),
(71,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",30]',0,1795099323,0,0,'fdc465a4ec9b26c4f35a6c0f06a1b5caeca7fe165d3915016b12a30ead07c9fa',1),
(72,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",31]',0,1795099323,0,0,'72f3d68d9dcc76817675c4c4c9bfdfc33145307e33ab69c32fa585db14c63c1c',1),
(73,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",32]',0,1795099323,0,0,'e0c6fc1fa4361eccc18b8171adefd311c24405227fbacfe2ee5f213d05be6223',1),
(74,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",33]',0,1795099323,0,0,'2cdeff29370bd4bca8106e3252f546571b6e9c163548bfdcc29f289a42dff841',1),
(75,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",34]',0,1795099323,0,0,'665436061b00762ead31c61438ad620802848a9a87fa96cb52b4f093a75599ab',1),
(76,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",35]',0,1795099323,0,0,'aa7bf8f6f1aff76738d3a316bed4079193f9a3651b10c7328203937c2b8b5b97',1),
(77,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",36]',0,1795099323,0,0,'133a4e9b62196a9068f4dc39a01f17d51e3d73fa488439ade2c53cf5c5108356',1),
(78,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",37]',0,1795099323,0,0,'102c679756c34cefd1952b2d86b47fa71d758bc0a8f8b5535c708ed6493ff573',1),
(79,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",38]',0,1795099323,0,0,'efe549bd6c5bb42de3b31b64d0d33f661c883c39d1ffbaed0172cb932da6666f',1),
(80,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",39]',0,1795099323,0,0,'949aa477c12599b9750806ebc60daba1370e109aa1a95eb4c7fd230de83b38c0',1),
(81,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",40]',0,1795099323,0,0,'07e0c8e4682f803146a570f22acb92b003f67e316423c259b8470598e733e0e2',1),
(82,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",41]',0,1795099323,0,0,'a909cb51ee34e1eb03f718398486dedbc140bb90508fc8acd8e5ef117b639f23',1),
(83,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",42]',0,1795099323,0,0,'66d3d2b28a4307c5b40857fe26df537efbeab62b28078792a514e22793683f1a',1),
(84,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",43]',0,1795099323,0,0,'03f93a7a849a1333b310bd065b6187d64b34b4a0e099030c5f2651ba28f6a995',1),
(85,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",44]',0,1795099323,0,0,'c002bae963e7dad8b7213a3b89af2143924b3824e469ee8e31fbf2cae6f7c45a',1),
(86,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",45]',0,1795099323,0,0,'a0e70bb4ea30aad91b8103f62a6e9c252c3b5a7ab5811e0a59cb4e5e2af4179b',1),
(87,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",47]',0,1795099323,0,0,'6709168789f0e9b2b998e445277503f820bc50c946d204eaa57fc233d5971499',1),
(88,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",48]',0,1795099323,0,0,'dbc38bd8f594e8bba97c792b26be3753531c60b85ae5b354c29bbe876566f7ca',1),
(89,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",49]',0,1795099323,0,0,'a86b936d56cbd826643ec5b75fcb80795885fb2f6fec09b50ed5dce556b2b2a2',1),
(90,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",50]',0,1795099323,0,0,'c6e82971403db7e07b361743f94b58c2c371324902a10ce82e1bc9ef1b893abe',1),
(91,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",51]',0,1795099323,0,0,'b80c9a10c4821fa0ec54b927fc43d2113452e3e127107532bb086649bfd91efe',1),
(92,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",52]',0,1795099323,0,0,'ae1f38e4416845df1be3c290b8c7cb4f841d99fd7c7aec98f7d37b64436d2e55',1),
(93,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",53]',0,1795099323,0,0,'d9df096902d65ebb7905a779334d1c7b510221d45373b7d5e44b346e12a3ece8',1),
(94,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",54]',0,1795099323,0,0,'c32c7031c152857fdc905ba4aea7bd96b9442e24b8fa3dd78cc7804c0f609e13',1),
(95,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",55]',0,1795099323,0,0,'7e278379ddd77e4d68399abf7f66ebec3319dc29210ee6986f4bbcb7ae445d67',1),
(96,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",56]',0,1795099323,0,0,'fcbc5032781239f3af6c784b9956e4a06929022e24290c59f27012ea298a1ab2',1),
(97,'OC\\FilesMetadata\\Job\\UpdateSingleMetadata','[\"ncadmin\",57]',0,1795099323,0,0,'fa3a035dff0a6a88351a66de0ba9fc36858ae5b60d65a1076ba77454b2ed50d2',1),
(98,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"\",\"type\":\"email\",\"uid\":\"emily\",\"try\":0,\"lastRun\":1795099338}',0,1795099338,0,0,'d908da2d40ea84316ba170b853cd6ac0d3071ad70ac8b599a9fc004e88f14133',1),
(99,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"emily.carter@example.com\",\"type\":\"email\",\"uid\":\"emily\",\"try\":0,\"lastRun\":1795099338}',0,1795099338,0,0,'a52e50287b2a4120ce6c1001161b76236eaaacbcc0d1af6ba00fd49d02c78dfd',1),
(100,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"\",\"type\":\"email\",\"uid\":\"james\",\"try\":0,\"lastRun\":1795099340}',0,1795099340,0,0,'9f7bb7e806801ce340fefe1a0cb15d51aa919a7040381022c46e73ab358e6f20',1),
(101,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"james.walker@example.com\",\"type\":\"email\",\"uid\":\"james\",\"try\":0,\"lastRun\":1795099340}',0,1795099340,0,0,'5f381dac510007d48af65afa5f87217fdde20c2bc5da7f6109d51ac3faed888e',1),
(102,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"\",\"type\":\"email\",\"uid\":\"olivia\",\"try\":0,\"lastRun\":1795099341}',0,1795099341,0,0,'37a6c4a51df8e0cea34ff4ccf154557ff62bb491f96d802a7012ff21967e37a6',1),
(103,'OCA\\Settings\\BackgroundJobs\\VerifyUserData','{\"verificationCode\":\"\",\"data\":\"olivia.bennett@example.com\",\"type\":\"email\",\"uid\":\"olivia\",\"try\":0,\"lastRun\":1795099341}',0,1795099341,0,0,'141260e04d49dd021ffcf84dbfa3369dcb164e940faf7bf1dc75882b69ff14cf',1);
/*!40000 ALTER TABLE `oc_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_known_users`
--

DROP TABLE IF EXISTS `oc_known_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_known_users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `known_to` varchar(255) NOT NULL,
  `known_user` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ku_known_to` (`known_to`),
  KEY `ku_known_user` (`known_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_known_users`
--

LOCK TABLES `oc_known_users` WRITE;
/*!40000 ALTER TABLE `oc_known_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_known_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_login_flow_v2`
--

DROP TABLE IF EXISTS `oc_login_flow_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_login_flow_v2` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` bigint(20) unsigned NOT NULL,
  `started` smallint(5) unsigned NOT NULL DEFAULT 0,
  `poll_token` varchar(255) NOT NULL,
  `login_token` varchar(255) NOT NULL,
  `public_key` text NOT NULL,
  `private_key` text NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `login_name` varchar(255) DEFAULT NULL,
  `server` varchar(255) DEFAULT NULL,
  `app_password` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `poll_token` (`poll_token`),
  UNIQUE KEY `login_token` (`login_token`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_login_flow_v2`
--

LOCK TABLES `oc_login_flow_v2` WRITE;
/*!40000 ALTER TABLE `oc_login_flow_v2` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_login_flow_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_migrations`
--

DROP TABLE IF EXISTS `oc_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_migrations` (
  `app` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  PRIMARY KEY (`app`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_migrations`
--

LOCK TABLES `oc_migrations` WRITE;
/*!40000 ALTER TABLE `oc_migrations` DISABLE KEYS */;
INSERT INTO `oc_migrations` VALUES
('activity','2006Date20170808154933'),
('activity','2006Date20170808155040'),
('activity','2006Date20170919095939'),
('activity','2007Date20181107114613'),
('activity','2008Date20181011095117'),
('activity','2010Date20190416112817'),
('activity','2011Date20201006132544'),
('activity','2011Date20201006132545'),
('activity','2011Date20201006132546'),
('activity','2011Date20201006132547'),
('activity','2011Date20201207091915'),
('app_api','032001Date20250115164140'),
('app_api','1000Date202305221555'),
('app_api','1004Date202311061844'),
('app_api','1005Date202312271744'),
('app_api','1006Date202401011308'),
('app_api','1007Date202401111030'),
('app_api','1008Date202401121205'),
('app_api','2000Date20240120094952'),
('app_api','2005Date20240209094951'),
('app_api','2200Date20240216164351'),
('app_api','2201Date20240221124152'),
('app_api','2203Date20240325124149'),
('app_api','2204Date20240401104001'),
('app_api','2204Date20240403125002'),
('app_api','2205Date20240411124836'),
('app_api','2206Date20240502145029'),
('app_api','2207Date20240502145029'),
('app_api','2700Date20240515092246'),
('app_api','2800Date20240710220000'),
('app_api','2800Date20240711080316'),
('app_api','3000Date20240715170800'),
('app_api','3000Date20240807085759'),
('app_api','3100Date20240822080316'),
('app_api','3200Date20240905080316'),
('app_api','5000Date20241120135411'),
('app_api','5000Date20250109163201'),
('circles','0022Date20220526111723'),
('circles','0022Date20220526113601'),
('circles','0022Date20220703115023'),
('circles','0023Date20211216113101'),
('circles','0024Date20220203123901'),
('circles','0024Date20220203123902'),
('circles','0024Date20220317190331'),
('circles','0028Date20230705222601'),
('circles','0031Date20241105133904'),
('contactsinteraction','010000Date20200304152605'),
('core','13000Date20170705121758'),
('core','13000Date20170718121200'),
('core','13000Date20170814074715'),
('core','13000Date20170919121250'),
('core','13000Date20170926101637'),
('core','14000Date20180129121024'),
('core','14000Date20180404140050'),
('core','14000Date20180516101403'),
('core','14000Date20180518120534'),
('core','14000Date20180522074438'),
('core','14000Date20180626223656'),
('core','14000Date20180710092004'),
('core','14000Date20180712153140'),
('core','15000Date20180926101451'),
('core','15000Date20181015062942'),
('core','15000Date20181029084625'),
('core','16000Date20190207141427'),
('core','16000Date20190212081545'),
('core','16000Date20190427105638'),
('core','16000Date20190428150708'),
('core','17000Date20190514105811'),
('core','18000Date20190920085628'),
('core','18000Date20191014105105'),
('core','18000Date20191204114856'),
('core','19000Date20200211083441'),
('core','20000Date20201109081915'),
('core','20000Date20201109081918'),
('core','20000Date20201109081919'),
('core','20000Date20201111081915'),
('core','21000Date20201120141228'),
('core','21000Date20201202095923'),
('core','21000Date20210119195004'),
('core','21000Date20210309185126'),
('core','21000Date20210309185127'),
('core','22000Date20210216080825'),
('core','23000Date20210721100600'),
('core','23000Date20210906132259'),
('core','23000Date20210930122352'),
('core','23000Date20211203110726'),
('core','23000Date20211213203940'),
('core','24000Date20211210141942'),
('core','24000Date20211213081506'),
('core','24000Date20211213081604'),
('core','24000Date20211222112246'),
('core','24000Date20211230140012'),
('core','24000Date20220131153041'),
('core','24000Date20220202150027'),
('core','24000Date20220404230027'),
('core','24000Date20220425072957'),
('core','25000Date20220515204012'),
('core','25000Date20220602190540'),
('core','25000Date20220905140840'),
('core','25000Date20221007010957'),
('core','27000Date20220613163520'),
('core','27000Date20230309104325'),
('core','27000Date20230309104802'),
('core','28000Date20230616104802'),
('core','28000Date20230728104802'),
('core','28000Date20230803221055'),
('core','28000Date20230906104802'),
('core','28000Date20231004103301'),
('core','28000Date20231103104802'),
('core','28000Date20231126110901'),
('core','28000Date20240828142927'),
('core','29000Date20231126110901'),
('core','29000Date20231213104850'),
('core','29000Date20240124132201'),
('core','29000Date20240124132202'),
('core','29000Date20240131122720'),
('core','30000Date20240429122720'),
('core','30000Date20240708160048'),
('core','30000Date20240717111406'),
('core','30000Date20240814180800'),
('core','30000Date20240815080800'),
('core','30000Date20240906095113'),
('core','31000Date20240101084401'),
('core','31000Date20240814184402'),
('core','31000Date20250213102442'),
('core','31000Date20250731062008'),
('core','32000Date20250620081925'),
('core','33000Date20251209123503'),
('dav','1004Date20170825134824'),
('dav','1004Date20170919104507'),
('dav','1004Date20170924124212'),
('dav','1004Date20170926103422'),
('dav','1005Date20180413093149'),
('dav','1005Date20180530124431'),
('dav','1006Date20180619154313'),
('dav','1006Date20180628111625'),
('dav','1008Date20181030113700'),
('dav','1008Date20181105104826'),
('dav','1008Date20181105104833'),
('dav','1008Date20181105110300'),
('dav','1008Date20181105112049'),
('dav','1008Date20181114084440'),
('dav','1011Date20190725113607'),
('dav','1011Date20190806104428'),
('dav','1012Date20190808122342'),
('dav','1016Date20201109085907'),
('dav','1017Date20210216083742'),
('dav','1018Date20210312100735'),
('dav','1024Date20211221144219'),
('dav','1025Date20240308063933'),
('dav','1027Date20230504122946'),
('dav','1029Date20221114151721'),
('dav','1029Date20231004091403'),
('dav','1030Date20240205103243'),
('dav','1031Date20240610134258'),
('federatedfilesharing','1010Date20200630191755'),
('federatedfilesharing','1011Date20201120125158'),
('federation','1010Date20200630191302'),
('files','11301Date20191205150729'),
('files','12101Date20221011153334'),
('files','2003Date20241021095629'),
('files_downloadlimit','000000Date20210910094923'),
('files_reminders','10000Date20230725162149'),
('files_sharing','11300Date20201120141438'),
('files_sharing','21000Date20201223143245'),
('files_sharing','22000Date20210216084241'),
('files_sharing','24000Date20220208195521'),
('files_sharing','24000Date20220404142216'),
('files_sharing','31000Date20240821142813'),
('files_sharing','32000Date20251017081948'),
('files_trashbin','1010Date20200630192639'),
('files_trashbin','1020Date20240403003535'),
('files_versions','1020Date20221114144058'),
('notifications','2004Date20190107135757'),
('notifications','2010Date20210218082811'),
('notifications','2010Date20210218082855'),
('notifications','2011Date20210930134607'),
('notifications','2011Date20220826074907'),
('oauth2','010401Date20181207190718'),
('oauth2','010402Date20190107124745'),
('oauth2','011601Date20230522143227'),
('oauth2','011602Date20230613160650'),
('oauth2','011603Date20230620111039'),
('oauth2','011901Date20240829164356'),
('photos','20000Date20220727125801'),
('photos','20001Date20220830131446'),
('photos','20003Date20221102170153'),
('photos','20003Date20221103094628'),
('photos','30000Date20240417075405'),
('photos','40000Date20250624085327'),
('privacy','100Date20190217131943'),
('systemtags','31000Date20241018063111'),
('systemtags','31000Date20241114171300'),
('text','010000Date20190617184535'),
('text','030001Date20200402075029'),
('text','030201Date20201116110353'),
('text','030201Date20201116123153'),
('text','030501Date20220202101853'),
('text','030701Date20230207131313'),
('text','030901Date20231114150437'),
('text','040100Date20240611165300'),
('text','070000Date20250925110024'),
('theming','2006Date20240905111627'),
('twofactor_backupcodes','1002Date20170607104347'),
('twofactor_backupcodes','1002Date20170607113030'),
('twofactor_backupcodes','1002Date20170919123342'),
('twofactor_backupcodes','1002Date20170926101419'),
('twofactor_backupcodes','1002Date20180821043638'),
('updatenotification','011901Date20240305120000'),
('user_status','0001Date20200602134824'),
('user_status','0002Date20200902144824'),
('user_status','1000Date20201111130204'),
('user_status','1003Date20210809144824'),
('user_status','1008Date20230921144701'),
('webhook_listeners','1000Date20240527153425'),
('webhook_listeners','1001Date20240716184935'),
('workflowengine','2000Date20190808074233'),
('workflowengine','2200Date20210805101925');
/*!40000 ALTER TABLE `oc_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mimetypes`
--

DROP TABLE IF EXISTS `oc_mimetypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_mimetypes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `mimetype` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `mimetype_id_index` (`mimetype`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mimetypes`
--

LOCK TABLES `oc_mimetypes` WRITE;
/*!40000 ALTER TABLE `oc_mimetypes` DISABLE KEYS */;
INSERT INTO `oc_mimetypes` VALUES
(5,'application'),
(18,'application/octet-stream'),
(6,'application/pdf'),
(10,'application/vnd.excalidraw+json'),
(14,'application/vnd.oasis.opendocument.graphics'),
(11,'application/vnd.oasis.opendocument.presentation'),
(12,'application/vnd.oasis.opendocument.spreadsheet'),
(13,'application/vnd.oasis.opendocument.text'),
(7,'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
(1,'httpd'),
(2,'httpd/unix-directory'),
(15,'image'),
(16,'image/jpeg'),
(17,'image/png'),
(3,'text'),
(4,'text/markdown'),
(19,'text/plain'),
(8,'video'),
(9,'video/mp4');
/*!40000 ALTER TABLE `oc_mimetypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_mounts`
--

DROP TABLE IF EXISTS `oc_mounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_mounts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `storage_id` bigint(20) NOT NULL,
  `root_id` bigint(20) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `mount_point` varchar(4000) NOT NULL,
  `mount_id` bigint(20) DEFAULT NULL,
  `mount_provider_class` varchar(128) DEFAULT NULL,
  `mount_point_hash` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mounts_user_root_path_index` (`user_id`,`root_id`,`mount_point_hash`),
  KEY `mounts_storage_index` (`storage_id`),
  KEY `mounts_root_index` (`root_id`),
  KEY `mounts_mount_id_index` (`mount_id`),
  KEY `mounts_class_index` (`mount_provider_class`),
  KEY `mount_user_storage` (`storage_id`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_mounts`
--

LOCK TABLES `oc_mounts` WRITE;
/*!40000 ALTER TABLE `oc_mounts` DISABLE KEYS */;
INSERT INTO `oc_mounts` VALUES
(1,1,1,'ncadmin','/ncadmin/',NULL,'OC\\Files\\Mount\\LocalHomeMountProvider','4c7d9f5d1bc6630df5026e947343d00e'),
(2,3,68,'emily','/emily/',NULL,'OC\\Files\\Mount\\LocalHomeMountProvider','3c7c3d339d12ba35ee280ba19c03594c'),
(3,4,76,'james','/james/',NULL,'OC\\Files\\Mount\\LocalHomeMountProvider','a65263109963701dc44ed54f705fba1a'),
(4,5,84,'olivia','/olivia/',NULL,'OC\\Files\\Mount\\LocalHomeMountProvider','cf555b1c1986298e4ece12a3aaa33a98');
/*!40000 ALTER TABLE `oc_mounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications`
--

DROP TABLE IF EXISTS `oc_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(32) NOT NULL,
  `user` varchar(64) NOT NULL,
  `timestamp` int(11) NOT NULL DEFAULT 0,
  `object_type` varchar(64) NOT NULL,
  `object_id` varchar(64) NOT NULL,
  `subject` varchar(64) NOT NULL,
  `subject_parameters` longtext DEFAULT NULL,
  `message` varchar(64) DEFAULT NULL,
  `message_parameters` longtext DEFAULT NULL,
  `link` varchar(4000) DEFAULT NULL,
  `icon` varchar(4000) DEFAULT NULL,
  `actions` longtext DEFAULT NULL,
  PRIMARY KEY (`notification_id`),
  KEY `oc_notifications_app` (`app`),
  KEY `oc_notifications_user` (`user`),
  KEY `oc_notifications_timestamp` (`timestamp`),
  KEY `oc_notifications_object` (`object_type`,`object_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications`
--

LOCK TABLES `oc_notifications` WRITE;
/*!40000 ALTER TABLE `oc_notifications` DISABLE KEYS */;
INSERT INTO `oc_notifications` VALUES
(1,'files_sharing','james',1795099362,'share','ocinternal:1','incoming_user_share','[]','','[]','','','[]');
/*!40000 ALTER TABLE `oc_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications_pushhash`
--

DROP TABLE IF EXISTS `oc_notifications_pushhash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications_pushhash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `token` int(11) NOT NULL DEFAULT 0,
  `deviceidentifier` varchar(128) NOT NULL,
  `devicepublickey` varchar(512) NOT NULL,
  `devicepublickeyhash` varchar(128) NOT NULL,
  `pushtokenhash` varchar(128) NOT NULL,
  `proxyserver` varchar(256) NOT NULL,
  `apptype` varchar(32) NOT NULL DEFAULT 'unknown',
  PRIMARY KEY (`id`),
  UNIQUE KEY `oc_npushhash_uid` (`uid`,`token`),
  KEY `oc_npushhash_di` (`deviceidentifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications_pushhash`
--

LOCK TABLES `oc_notifications_pushhash` WRITE;
/*!40000 ALTER TABLE `oc_notifications_pushhash` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_notifications_pushhash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_notifications_settings`
--

DROP TABLE IF EXISTS `oc_notifications_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_notifications_settings` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `batch_time` int(11) NOT NULL DEFAULT 0,
  `last_send_id` bigint(20) NOT NULL DEFAULT 0,
  `next_send_time` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `notset_user` (`user_id`),
  KEY `notset_nextsend` (`next_send_time`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_notifications_settings`
--

LOCK TABLES `oc_notifications_settings` WRITE;
/*!40000 ALTER TABLE `oc_notifications_settings` DISABLE KEYS */;
INSERT INTO `oc_notifications_settings` VALUES
(1,'ncadmin',0,0,0),
(2,'emily',0,0,0),
(3,'james',0,0,0),
(4,'olivia',0,0,0);
/*!40000 ALTER TABLE `oc_notifications_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_oauth2_access_tokens`
--

DROP TABLE IF EXISTS `oc_oauth2_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_oauth2_access_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `hashed_code` varchar(128) NOT NULL,
  `encrypted_token` varchar(786) NOT NULL,
  `code_created_at` bigint(20) unsigned NOT NULL DEFAULT 0,
  `token_count` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth2_access_hash_idx` (`hashed_code`),
  KEY `oauth2_access_client_id_idx` (`client_id`),
  KEY `oauth2_tk_c_created_idx` (`token_count`,`code_created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_oauth2_access_tokens`
--

LOCK TABLES `oc_oauth2_access_tokens` WRITE;
/*!40000 ALTER TABLE `oc_oauth2_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_oauth2_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_oauth2_clients`
--

DROP TABLE IF EXISTS `oc_oauth2_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_oauth2_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `redirect_uri` varchar(2000) NOT NULL,
  `client_identifier` varchar(64) NOT NULL,
  `secret` varchar(512) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `oauth2_client_id_idx` (`client_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_oauth2_clients`
--

LOCK TABLES `oc_oauth2_clients` WRITE;
/*!40000 ALTER TABLE `oc_oauth2_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_oauth2_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_open_local_editor`
--

DROP TABLE IF EXISTS `oc_open_local_editor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_open_local_editor` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `path_hash` varchar(64) NOT NULL,
  `expiration_time` bigint(20) unsigned NOT NULL,
  `token` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `openlocal_user_path_token` (`user_id`,`path_hash`,`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_open_local_editor`
--

LOCK TABLES `oc_open_local_editor` WRITE;
/*!40000 ALTER TABLE `oc_open_local_editor` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_open_local_editor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_photos_albums`
--

DROP TABLE IF EXISTS `oc_photos_albums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_photos_albums` (
  `album_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `created` bigint(20) NOT NULL,
  `location` varchar(255) NOT NULL,
  `last_added_photo` bigint(20) NOT NULL,
  PRIMARY KEY (`album_id`),
  KEY `pa_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_photos_albums`
--

LOCK TABLES `oc_photos_albums` WRITE;
/*!40000 ALTER TABLE `oc_photos_albums` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_photos_albums` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_photos_albums_collabs`
--

DROP TABLE IF EXISTS `oc_photos_albums_collabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_photos_albums_collabs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) NOT NULL,
  `collaborator_id` varchar(64) NOT NULL,
  `collaborator_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `album_collabs_uniq_collab` (`album_id`,`collaborator_id`,`collaborator_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_photos_albums_collabs`
--

LOCK TABLES `oc_photos_albums_collabs` WRITE;
/*!40000 ALTER TABLE `oc_photos_albums_collabs` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_photos_albums_collabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_photos_albums_files`
--

DROP TABLE IF EXISTS `oc_photos_albums_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_photos_albums_files` (
  `album_file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `added` bigint(20) NOT NULL,
  `owner` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`album_file_id`),
  UNIQUE KEY `paf_album_file` (`album_id`,`file_id`),
  KEY `paf_folder` (`album_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_photos_albums_files`
--

LOCK TABLES `oc_photos_albums_files` WRITE;
/*!40000 ALTER TABLE `oc_photos_albums_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_photos_albums_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_preferences`
--

DROP TABLE IF EXISTS `oc_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_preferences` (
  `userid` varchar(64) NOT NULL DEFAULT '',
  `appid` varchar(32) NOT NULL DEFAULT '',
  `configkey` varchar(64) NOT NULL DEFAULT '',
  `configvalue` longtext DEFAULT NULL,
  `lazy` smallint(5) unsigned NOT NULL DEFAULT 0,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `flags` int(10) unsigned NOT NULL DEFAULT 0,
  `indexed` varchar(64) DEFAULT '',
  PRIMARY KEY (`userid`,`appid`,`configkey`),
  KEY `prefs_uid_lazy_i` (`userid`,`lazy`),
  KEY `prefs_app_key_ind_fl_i` (`appid`,`configkey`,`indexed`,`flags`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_preferences`
--

LOCK TABLES `oc_preferences` WRITE;
/*!40000 ALTER TABLE `oc_preferences` DISABLE KEYS */;
INSERT INTO `oc_preferences` VALUES
('emily','activity','configured','yes',0,0,0,''),
('emily','avatar','generated','true',0,0,0,''),
('emily','avatar','version','1',0,0,0,''),
('emily','login','firstLogin','1795099362',0,0,0,''),
('emily','login','lastLogin','1795099362',0,0,0,''),
('emily','notifications','sound_notification','no',0,0,0,''),
('emily','notifications','sound_talk','no',0,0,0,''),
('emily','password_policy','failedLoginAttempts','0',0,0,0,''),
('emily','settings','email','emily.carter@example.com',0,0,0,''),
('james','avatar','generated','true',0,0,0,''),
('james','avatar','version','1',0,0,0,''),
('james','notifications','sound_notification','no',0,0,0,''),
('james','notifications','sound_talk','no',0,0,0,''),
('james','settings','email','james.walker@example.com',0,0,0,''),
('ncadmin','activity','configured','yes',0,0,0,''),
('ncadmin','core','templateDirectory','Templates/',0,0,0,''),
('ncadmin','login','firstLogin','1795099322',0,0,0,''),
('ncadmin','login','lastLogin','1795099322',0,0,0,''),
('ncadmin','notifications','sound_notification','no',0,0,0,''),
('ncadmin','notifications','sound_talk','no',0,0,0,''),
('ncadmin','password_policy','failedLoginAttempts','0',0,0,0,''),
('olivia','avatar','generated','true',0,0,0,''),
('olivia','avatar','version','1',0,0,0,''),
('olivia','notifications','sound_notification','no',0,0,0,''),
('olivia','notifications','sound_talk','no',0,0,0,''),
('olivia','settings','email','olivia.bennett@example.com',0,0,0,'');
/*!40000 ALTER TABLE `oc_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_preferences_ex`
--

DROP TABLE IF EXISTS `oc_preferences_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_preferences_ex` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` varchar(64) NOT NULL,
  `appid` varchar(32) NOT NULL,
  `configkey` varchar(64) NOT NULL,
  `configvalue` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `preferences_ex__idx` (`userid`,`appid`,`configkey`),
  KEY `preferences_ex__configkey` (`configkey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_preferences_ex`
--

LOCK TABLES `oc_preferences_ex` WRITE;
/*!40000 ALTER TABLE `oc_preferences_ex` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_preferences_ex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_privacy_admins`
--

DROP TABLE IF EXISTS `oc_privacy_admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_privacy_admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `displayname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_privacy_admins`
--

LOCK TABLES `oc_privacy_admins` WRITE;
/*!40000 ALTER TABLE `oc_privacy_admins` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_privacy_admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_profile_config`
--

DROP TABLE IF EXISTS `oc_profile_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_profile_config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL,
  `config` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `profile_config_user_id_idx` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_profile_config`
--

LOCK TABLES `oc_profile_config` WRITE;
/*!40000 ALTER TABLE `oc_profile_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_profile_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_properties`
--

DROP TABLE IF EXISTS `oc_properties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_properties` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `userid` varchar(64) NOT NULL DEFAULT '',
  `propertypath` varchar(255) NOT NULL DEFAULT '',
  `propertyname` varchar(255) NOT NULL DEFAULT '',
  `propertyvalue` longtext NOT NULL,
  `valuetype` smallint(6) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `properties_path_index` (`userid`,`propertypath`),
  KEY `properties_pathonly_index` (`propertypath`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_properties`
--

LOCK TABLES `oc_properties` WRITE;
/*!40000 ALTER TABLE `oc_properties` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_properties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_ratelimit_entries`
--

DROP TABLE IF EXISTS `oc_ratelimit_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_ratelimit_entries` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hash` varchar(128) NOT NULL,
  `delete_after` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ratelimit_hash` (`hash`),
  KEY `ratelimit_delete_after` (`delete_after`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_ratelimit_entries`
--

LOCK TABLES `oc_ratelimit_entries` WRITE;
/*!40000 ALTER TABLE `oc_ratelimit_entries` DISABLE KEYS */;
INSERT INTO `oc_ratelimit_entries` VALUES
(1,'c785ac685df6db4f117a0756a2b1434c38aaf1befa6b4058bcd82ffd85ff35049b0ecb9d4550e050e1505d4b5e57edb8eaaa4bae26c9075c0b6d24573079015b','2026-11-19 14:52:42');
/*!40000 ALTER TABLE `oc_ratelimit_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_reactions`
--

DROP TABLE IF EXISTS `oc_reactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_reactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned NOT NULL,
  `message_id` bigint(20) unsigned NOT NULL,
  `actor_type` varchar(64) NOT NULL DEFAULT '',
  `actor_id` varchar(64) NOT NULL DEFAULT '',
  `reaction` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_reaction_unique` (`parent_id`,`actor_type`,`actor_id`,`reaction`),
  KEY `comment_reaction` (`reaction`),
  KEY `comment_reaction_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_reactions`
--

LOCK TABLES `oc_reactions` WRITE;
/*!40000 ALTER TABLE `oc_reactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_reactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_recent_contact`
--

DROP TABLE IF EXISTS `oc_recent_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_recent_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actor_uid` varchar(64) NOT NULL,
  `uid` varchar(64) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `federated_cloud_id` varchar(255) DEFAULT NULL,
  `card` longblob NOT NULL,
  `last_contact` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recent_contact_actor_uid` (`actor_uid`),
  KEY `recent_contact_id_uid` (`id`,`actor_uid`),
  KEY `recent_contact_uid` (`uid`),
  KEY `recent_contact_email` (`email`),
  KEY `recent_contact_fed_id` (`federated_cloud_id`),
  KEY `recent_contact_last_contact` (`last_contact`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_recent_contact`
--

LOCK TABLES `oc_recent_contact` WRITE;
/*!40000 ALTER TABLE `oc_recent_contact` DISABLE KEYS */;
INSERT INTO `oc_recent_contact` VALUES
(1,'emily','james',NULL,'james@http://localhost','BEGIN:VCARD\r\nVERSION:4.0\r\nPRODID:-//Sabre//Sabre VObject 4.5.6//EN\r\nUID:sabre-vobject-0042831b-0872-4905-9ae1-6e33bc11316d\r\nURI:0ce2c34d-0910-4ca8-bc4f-b967c103e65f\r\nFN:James Walker\r\nCATEGORIES:Recently contacted\r\nCLOUD:james@http://localhost\r\nEND:VCARD\r\n',1795099362);
/*!40000 ALTER TABLE `oc_recent_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_schedulingobjects`
--

DROP TABLE IF EXISTS `oc_schedulingobjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_schedulingobjects` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `principaluri` varchar(255) DEFAULT NULL,
  `calendardata` longblob DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `lastmodified` int(10) unsigned DEFAULT NULL,
  `etag` varchar(32) DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schedulobj_principuri_index` (`principaluri`),
  KEY `schedulobj_lastmodified_idx` (`lastmodified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_schedulingobjects`
--

LOCK TABLES `oc_schedulingobjects` WRITE;
/*!40000 ALTER TABLE `oc_schedulingobjects` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_schedulingobjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_sec_signatory`
--

DROP TABLE IF EXISTS `oc_sec_signatory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_sec_signatory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key_id_sum` varchar(127) NOT NULL,
  `key_id` varchar(512) NOT NULL,
  `host` varchar(512) NOT NULL,
  `provider_id` varchar(31) NOT NULL,
  `account` varchar(127) DEFAULT '',
  `public_key` longtext NOT NULL DEFAULT '',
  `metadata` longtext NOT NULL DEFAULT '[]',
  `type` smallint(6) NOT NULL DEFAULT 9,
  `status` smallint(6) NOT NULL DEFAULT 0,
  `creation` int(10) unsigned DEFAULT 0,
  `last_updated` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sec_sig_unic` (`provider_id`,`host`,`account`),
  KEY `sec_sig_key` (`key_id_sum`,`provider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_sec_signatory`
--

LOCK TABLES `oc_sec_signatory` WRITE;
/*!40000 ALTER TABLE `oc_sec_signatory` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_sec_signatory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share`
--

DROP TABLE IF EXISTS `oc_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_share` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `share_type` smallint(6) NOT NULL DEFAULT 0,
  `share_with` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `uid_owner` varchar(64) NOT NULL DEFAULT '',
  `uid_initiator` varchar(64) DEFAULT NULL,
  `parent` bigint(20) DEFAULT NULL,
  `item_type` varchar(64) NOT NULL DEFAULT '',
  `item_source` varchar(255) DEFAULT NULL,
  `item_target` varchar(255) DEFAULT NULL,
  `file_source` bigint(20) DEFAULT NULL,
  `file_target` varchar(512) DEFAULT NULL,
  `permissions` smallint(6) NOT NULL DEFAULT 0,
  `stime` bigint(20) NOT NULL DEFAULT 0,
  `accepted` smallint(6) NOT NULL DEFAULT 0,
  `expiration` datetime DEFAULT NULL,
  `token` varchar(32) DEFAULT NULL,
  `mail_send` smallint(6) NOT NULL DEFAULT 0,
  `share_name` varchar(64) DEFAULT NULL,
  `password_by_talk` tinyint(1) DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `hide_download` smallint(6) DEFAULT 0,
  `label` varchar(255) DEFAULT NULL,
  `attributes` longtext DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`attributes`)),
  `password_expiration_time` datetime DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `item_share_type_index` (`item_type`,`share_type`),
  KEY `file_source_index` (`file_source`),
  KEY `token_index` (`token`),
  KEY `share_with_index` (`share_with`),
  KEY `parent_index` (`parent`),
  KEY `owner_index` (`uid_owner`),
  KEY `initiator_index` (`uid_initiator`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share`
--

LOCK TABLES `oc_share` WRITE;
/*!40000 ALTER TABLE `oc_share` DISABLE KEYS */;
INSERT INTO `oc_share` VALUES
(1,0,'james',NULL,'emily','emily',NULL,'file','88',NULL,88,'/Marketing-plan.txt',19,1795099362,1,NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `oc_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_share_external`
--

DROP TABLE IF EXISTS `oc_share_external`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_share_external` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent` bigint(20) DEFAULT -1,
  `share_type` int(11) DEFAULT NULL,
  `remote` varchar(512) NOT NULL,
  `remote_id` varchar(255) DEFAULT '',
  `share_token` varchar(64) NOT NULL,
  `password` varchar(64) DEFAULT NULL,
  `name` varchar(4000) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `user` varchar(64) NOT NULL,
  `mountpoint` varchar(4000) NOT NULL,
  `mountpoint_hash` varchar(32) NOT NULL,
  `accepted` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sh_external_mp` (`user`,`mountpoint_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_share_external`
--

LOCK TABLES `oc_share_external` WRITE;
/*!40000 ALTER TABLE `oc_share_external` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_share_external` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_shares_limits`
--

DROP TABLE IF EXISTS `oc_shares_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_shares_limits` (
  `id` varchar(32) NOT NULL,
  `limit` bigint(20) NOT NULL,
  `downloads` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_shares_limits`
--

LOCK TABLES `oc_shares_limits` WRITE;
/*!40000 ALTER TABLE `oc_shares_limits` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_shares_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages`
--

DROP TABLE IF EXISTS `oc_storages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_storages` (
  `numeric_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `id` varchar(64) DEFAULT NULL,
  `available` int(11) NOT NULL DEFAULT 1,
  `last_checked` int(11) DEFAULT NULL,
  PRIMARY KEY (`numeric_id`),
  UNIQUE KEY `storages_id_index` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages`
--

LOCK TABLES `oc_storages` WRITE;
/*!40000 ALTER TABLE `oc_storages` DISABLE KEYS */;
INSERT INTO `oc_storages` VALUES
(1,'home::ncadmin',1,NULL),
(2,'local::/var/www/html/data/',1,NULL),
(3,'home::emily',1,NULL),
(4,'home::james',1,NULL),
(5,'home::olivia',1,NULL);
/*!40000 ALTER TABLE `oc_storages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_storages_credentials`
--

DROP TABLE IF EXISTS `oc_storages_credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_storages_credentials` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user` varchar(64) DEFAULT NULL,
  `identifier` varchar(64) NOT NULL,
  `credentials` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stocred_ui` (`user`,`identifier`),
  KEY `stocred_user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_storages_credentials`
--

LOCK TABLES `oc_storages_credentials` WRITE;
/*!40000 ALTER TABLE `oc_storages_credentials` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_storages_credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag`
--

DROP TABLE IF EXISTS `oc_systemtag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '',
  `visibility` smallint(6) NOT NULL DEFAULT 1,
  `editable` smallint(6) NOT NULL DEFAULT 1,
  `etag` varchar(32) DEFAULT NULL,
  `color` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_ident` (`name`,`visibility`,`editable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag`
--

LOCK TABLES `oc_systemtag` WRITE;
/*!40000 ALTER TABLE `oc_systemtag` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_group`
--

DROP TABLE IF EXISTS `oc_systemtag_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag_group` (
  `systemtagid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `gid` varchar(255) NOT NULL,
  PRIMARY KEY (`gid`,`systemtagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_group`
--

LOCK TABLES `oc_systemtag_group` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_systemtag_object_mapping`
--

DROP TABLE IF EXISTS `oc_systemtag_object_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_systemtag_object_mapping` (
  `objectid` varchar(64) NOT NULL DEFAULT '',
  `objecttype` varchar(64) NOT NULL DEFAULT '',
  `systemtagid` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`objecttype`,`objectid`,`systemtagid`),
  KEY `systag_by_tagid` (`systemtagid`,`objecttype`),
  KEY `systag_by_objectid` (`objectid`),
  KEY `systag_objecttype` (`objecttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_systemtag_object_mapping`
--

LOCK TABLES `oc_systemtag_object_mapping` WRITE;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_systemtag_object_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_taskprocessing_tasks`
--

DROP TABLE IF EXISTS `oc_taskprocessing_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_taskprocessing_tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `input` longtext NOT NULL,
  `output` longtext DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `user_id` varchar(64) DEFAULT NULL,
  `app_id` varchar(32) NOT NULL DEFAULT '',
  `custom_id` varchar(255) DEFAULT '',
  `last_updated` int(10) unsigned DEFAULT 0,
  `completion_expected_at` datetime DEFAULT NULL,
  `progress` double DEFAULT 0,
  `error_message` varchar(4000) DEFAULT NULL,
  `scheduled_at` int(10) unsigned DEFAULT NULL,
  `started_at` int(10) unsigned DEFAULT NULL,
  `ended_at` int(10) unsigned DEFAULT NULL,
  `webhook_uri` varchar(4000) DEFAULT NULL,
  `webhook_method` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taskp_tasks_status_type` (`status`,`type`),
  KEY `taskp_tasks_updated` (`last_updated`),
  KEY `taskp_tasks_uid_appid_cid` (`user_id`,`app_id`,`custom_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_taskprocessing_tasks`
--

LOCK TABLES `oc_taskprocessing_tasks` WRITE;
/*!40000 ALTER TABLE `oc_taskprocessing_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_taskprocessing_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text2image_tasks`
--

DROP TABLE IF EXISTS `oc_text2image_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text2image_tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `input` longtext NOT NULL,
  `status` int(11) DEFAULT 0,
  `number_of_images` int(11) NOT NULL DEFAULT 1,
  `user_id` varchar(64) DEFAULT NULL,
  `app_id` varchar(32) NOT NULL DEFAULT '',
  `identifier` varchar(255) DEFAULT '',
  `last_updated` datetime DEFAULT NULL,
  `completion_expected_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `t2i_tasks_updated` (`last_updated`),
  KEY `t2i_tasks_status` (`status`),
  KEY `t2i_tasks_uid_appid_ident` (`user_id`,`app_id`,`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text2image_tasks`
--

LOCK TABLES `oc_text2image_tasks` WRITE;
/*!40000 ALTER TABLE `oc_text2image_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text2image_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_documents`
--

DROP TABLE IF EXISTS `oc_text_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_documents` (
  `id` bigint(20) unsigned NOT NULL,
  `current_version` bigint(20) unsigned DEFAULT 0,
  `last_saved_version` bigint(20) unsigned DEFAULT 0,
  `last_saved_version_time` bigint(20) unsigned NOT NULL,
  `last_saved_version_etag` varchar(64) DEFAULT '',
  `base_version_etag` varchar(64) DEFAULT '',
  `checksum` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_documents`
--

LOCK TABLES `oc_text_documents` WRITE;
/*!40000 ALTER TABLE `oc_text_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_sessions`
--

DROP TABLE IF EXISTS `oc_text_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_sessions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) DEFAULT NULL,
  `guest_name` varchar(64) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `token` varchar(64) NOT NULL,
  `document_id` bigint(20) NOT NULL,
  `last_contact` bigint(20) unsigned NOT NULL,
  `last_awareness_message` longtext DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `rd_session_token_idx` (`token`),
  KEY `ts_lastcontact` (`last_contact`),
  KEY `ts_docid_lastcontact` (`document_id`,`last_contact`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_sessions`
--

LOCK TABLES `oc_text_sessions` WRITE;
/*!40000 ALTER TABLE `oc_text_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_text_steps`
--

DROP TABLE IF EXISTS `oc_text_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_text_steps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` bigint(20) unsigned NOT NULL,
  `session_id` bigint(20) unsigned NOT NULL,
  `data` longtext NOT NULL,
  `version` bigint(20) unsigned DEFAULT 0,
  `timestamp` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `rd_steps_did_idx` (`document_id`),
  KEY `rd_steps_version_idx` (`version`),
  KEY `textstep_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_text_steps`
--

LOCK TABLES `oc_text_steps` WRITE;
/*!40000 ALTER TABLE `oc_text_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_text_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_textprocessing_tasks`
--

DROP TABLE IF EXISTS `oc_textprocessing_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_textprocessing_tasks` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `input` longtext NOT NULL,
  `output` longtext DEFAULT NULL,
  `status` int(11) DEFAULT 0,
  `user_id` varchar(64) DEFAULT NULL,
  `app_id` varchar(32) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `last_updated` int(10) unsigned DEFAULT 0,
  `completion_expected_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tp_tasks_updated` (`last_updated`),
  KEY `tp_tasks_status_type_nonunique` (`status`,`type`),
  KEY `tp_tasks_uid_appid_ident` (`user_id`,`app_id`,`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_textprocessing_tasks`
--

LOCK TABLES `oc_textprocessing_tasks` WRITE;
/*!40000 ALTER TABLE `oc_textprocessing_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_textprocessing_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_trusted_servers`
--

DROP TABLE IF EXISTS `oc_trusted_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_trusted_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(512) NOT NULL,
  `url_hash` varchar(255) NOT NULL DEFAULT '',
  `token` varchar(128) DEFAULT NULL,
  `shared_secret` varchar(256) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 2,
  `sync_token` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url_hash` (`url_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_trusted_servers`
--

LOCK TABLES `oc_trusted_servers` WRITE;
/*!40000 ALTER TABLE `oc_trusted_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_trusted_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_twofactor_backupcodes`
--

DROP TABLE IF EXISTS `oc_twofactor_backupcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_twofactor_backupcodes` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(64) NOT NULL DEFAULT '',
  `code` varchar(128) NOT NULL,
  `used` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `twofactor_backupcodes_uid` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_twofactor_backupcodes`
--

LOCK TABLES `oc_twofactor_backupcodes` WRITE;
/*!40000 ALTER TABLE `oc_twofactor_backupcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_twofactor_backupcodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_twofactor_providers`
--

DROP TABLE IF EXISTS `oc_twofactor_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_twofactor_providers` (
  `provider_id` varchar(32) NOT NULL,
  `uid` varchar(64) NOT NULL,
  `enabled` smallint(6) NOT NULL,
  PRIMARY KEY (`provider_id`,`uid`),
  KEY `twofactor_providers_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_twofactor_providers`
--

LOCK TABLES `oc_twofactor_providers` WRITE;
/*!40000 ALTER TABLE `oc_twofactor_providers` DISABLE KEYS */;
INSERT INTO `oc_twofactor_providers` VALUES
('backup_codes','emily',0);
/*!40000 ALTER TABLE `oc_twofactor_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_status`
--

DROP TABLE IF EXISTS `oc_user_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_user_status` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `status_timestamp` int(10) unsigned NOT NULL,
  `is_user_defined` tinyint(1) DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `custom_icon` varchar(255) DEFAULT NULL,
  `custom_message` longtext DEFAULT NULL,
  `clear_at` int(10) unsigned DEFAULT NULL,
  `is_backup` tinyint(1) DEFAULT 0,
  `status_message_timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_status_uid_ix` (`user_id`),
  KEY `user_status_clr_ix` (`clear_at`),
  KEY `user_status_tstmp_ix` (`status_timestamp`),
  KEY `user_status_iud_ix` (`is_user_defined`,`status`),
  KEY `user_status_mtstmp_ix` (`status_message_timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_status`
--

LOCK TABLES `oc_user_status` WRITE;
/*!40000 ALTER TABLE `oc_user_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_user_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_user_transfer_owner`
--

DROP TABLE IF EXISTS `oc_user_transfer_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_user_transfer_owner` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source_user` varchar(64) NOT NULL,
  `target_user` varchar(64) NOT NULL,
  `file_id` bigint(20) NOT NULL,
  `node_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_user_transfer_owner`
--

LOCK TABLES `oc_user_transfer_owner` WRITE;
/*!40000 ALTER TABLE `oc_user_transfer_owner` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_user_transfer_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_users`
--

DROP TABLE IF EXISTS `oc_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_users` (
  `uid` varchar(64) NOT NULL DEFAULT '',
  `displayname` varchar(64) DEFAULT NULL,
  `password` varchar(255) NOT NULL DEFAULT '',
  `uid_lower` varchar(64) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `user_uid_lower` (`uid_lower`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_users`
--

LOCK TABLES `oc_users` WRITE;
/*!40000 ALTER TABLE `oc_users` DISABLE KEYS */;
INSERT INTO `oc_users` VALUES
('emily','Emily Carter','3|$argon2id$v=19$m=65536,t=4,p=1$YnptUkU2dFNZblR5YWNMSA$zTILoi3iIjD+MO5J6kXR6Sf0z2Tdzf2Z7MVYSLQfKLw','emily'),
('james','James Walker','3|$argon2id$v=19$m=65536,t=4,p=1$SC5zUGw1SW4vTy9xamhEdg$KV17FBVLfleLau8ISBowuW8M9lZEwqqnwdRKSHUHKP8','james'),
('ncadmin',NULL,'3|$argon2id$v=19$m=65536,t=4,p=1$Q0M5a3RHL2RFT3daQVExWQ$i41tF2gfgSrhO74Hwqj6KqhdcrEe989VuB3u0oIougo','ncadmin'),
('olivia','Olivia Bennett','3|$argon2id$v=19$m=65536,t=4,p=1$TGtOcjYxZGdwR1V4ZEdRMQ$g2VrTqirRBN3we2rwonlMf/rZH3v0mVpIQIepB8CymA','olivia');
/*!40000 ALTER TABLE `oc_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory`
--

DROP TABLE IF EXISTS `oc_vcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_vcategory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL DEFAULT '',
  `type` varchar(64) NOT NULL DEFAULT '',
  `category` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_category_per_user` (`uid`,`type`,`category`),
  KEY `uid_index` (`uid`),
  KEY `type_index` (`type`),
  KEY `category_index` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory`
--

LOCK TABLES `oc_vcategory` WRITE;
/*!40000 ALTER TABLE `oc_vcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_vcategory_to_object`
--

DROP TABLE IF EXISTS `oc_vcategory_to_object`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_vcategory_to_object` (
  `objid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `categoryid` bigint(20) unsigned NOT NULL DEFAULT 0,
  `type` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`categoryid`,`objid`,`type`),
  KEY `vcategory_objectd_index` (`objid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_vcategory_to_object`
--

LOCK TABLES `oc_vcategory_to_object` WRITE;
/*!40000 ALTER TABLE `oc_vcategory_to_object` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_vcategory_to_object` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_webauthn`
--

DROP TABLE IF EXISTS `oc_webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_webauthn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `public_key_credential_id` varchar(512) NOT NULL,
  `data` longtext NOT NULL,
  `user_verification` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `webauthn_uid` (`uid`),
  KEY `webauthn_publicKeyCredentialId` (`public_key_credential_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_webauthn`
--

LOCK TABLES `oc_webauthn` WRITE;
/*!40000 ALTER TABLE `oc_webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_webhook_listeners`
--

DROP TABLE IF EXISTS `oc_webhook_listeners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_webhook_listeners` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app_id` varchar(64) DEFAULT NULL,
  `user_id` varchar(64) DEFAULT NULL,
  `http_method` varchar(32) NOT NULL,
  `uri` varchar(4000) NOT NULL,
  `event` varchar(4000) NOT NULL,
  `event_filter` longtext DEFAULT NULL,
  `user_id_filter` varchar(64) DEFAULT NULL,
  `headers` longtext DEFAULT NULL,
  `auth_method` varchar(16) NOT NULL DEFAULT '',
  `auth_data` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_webhook_listeners`
--

LOCK TABLES `oc_webhook_listeners` WRITE;
/*!40000 ALTER TABLE `oc_webhook_listeners` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_webhook_listeners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oc_whats_new`
--

DROP TABLE IF EXISTS `oc_whats_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `oc_whats_new` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(64) NOT NULL DEFAULT '11',
  `etag` varchar(64) NOT NULL DEFAULT '',
  `last_check` int(10) unsigned NOT NULL DEFAULT 0,
  `data` longtext NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `version` (`version`),
  KEY `version_etag_idx` (`version`,`etag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oc_whats_new`
--

LOCK TABLES `oc_whats_new` WRITE;
/*!40000 ALTER TABLE `oc_whats_new` DISABLE KEYS */;
/*!40000 ALTER TABLE `oc_whats_new` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-19 14:49:03
